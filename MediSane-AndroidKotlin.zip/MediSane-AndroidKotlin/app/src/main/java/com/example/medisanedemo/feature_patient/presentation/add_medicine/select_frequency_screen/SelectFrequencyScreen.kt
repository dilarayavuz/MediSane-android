package com.example.medisanedemo.feature_patient.presentation.add_medicine.select_frequency_screen

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.presentation.login.components.HeadlineTextComponent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.AddMedicineViewModel
import com.example.medisanedemo.feature_patient.presentation.add_medicine.components.ClickableColumnComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.TopAppBarComponent
import com.example.medisanedemo.ui.theme.MyTheme
import kotlinx.coroutines.flow.Flow

@Composable
fun SelectFrequencyScreen(
    responseEvents: Flow<AddMedicineViewModel.ResponseEvent>,
    onPressEverydayColumn: () -> Unit,
    onPressEveryXDayColumn: () -> Unit,
    onPressSpecificDaysOfWeekColumn: () -> Unit,
    onPressBackButton: () -> Unit,
    onPressLogoutButton: () -> Unit,
    onNavigateBackToAddMedicineScreen: () -> Unit,
    onNavigateBackToMedicineInfo: (String, Int, Int, String, Boolean, String) -> Unit,
    onNavigateToEverydayScreen: () -> Unit,
    onNavigateToEveryXDayScreen: () -> Unit,
    onNavigateToSpecificDaysOfWeekScreen: () -> Unit

) {

    val context = LocalContext.current
    //val TAG = "SelectFrequencyScreen"

    LaunchedEffect(key1 = context) {// LaunchedEffect(key = context) --> when context changes, this affect will be relaunched
        responseEvents.collect {event ->
            when (event) {
                is AddMedicineViewModel.ResponseEvent.GoToEverydayColumn -> {
                    onNavigateToEverydayScreen()
                }
                is AddMedicineViewModel.ResponseEvent.GoToEveryXDayColumn -> {
                    onNavigateToEveryXDayScreen()
                }
                is AddMedicineViewModel.ResponseEvent.GoToSpecificDaysOfWeekColumn -> {
                    onNavigateToSpecificDaysOfWeekScreen()
                }
                is AddMedicineViewModel.ResponseEvent.GoBackToAddMedicineScreen -> {
                    onNavigateBackToAddMedicineScreen()
                }
                is AddMedicineViewModel.ResponseEvent.GoBackToMedicineInfoScreen -> {
                    onNavigateBackToMedicineInfo(
                        event.token,
                        event.accountId,
                        event.profileId,
                        event.profileName,
                        event.isSupervisor,
                        event.medicineName
                    )
                }
                else -> {}
            }

        }
    }

    Scaffold(
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.select_frequency_option),
                isHomeScreen = false,
                isSelectProfileScreen = false,
                onBackButtonPressed = onPressBackButton,
                onLogoutButtonPressed = onPressLogoutButton,
                isSelectPatientScreen = false,
                hasNotification = false,
            )
        }
    ) {
        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
                .padding(paddingValues = it)
        ) {

            Column(
                modifier = Modifier
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {


                HeadlineTextComponent(
                    value = stringResource(id = R.string.select_frequency_type),
                    fontSize = 28
                )
                Spacer(modifier = Modifier.height(20.dp))


                ClickableColumnComponent(
                    onClick = onPressEverydayColumn,
                    textValue = stringResource(id = R.string.everyday)
                )
                ClickableColumnComponent(
                    onClick = onPressEveryXDayColumn,
                    textValue = stringResource(id = R.string.every_x_days)
                )
                ClickableColumnComponent(
                    onClick = onPressSpecificDaysOfWeekColumn,
                    textValue = stringResource(id = R.string.specific_days)
                )


            }


        }

    }

}