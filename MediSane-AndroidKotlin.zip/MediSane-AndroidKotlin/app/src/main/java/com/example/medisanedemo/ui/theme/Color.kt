package com.example.medisanedemo.ui.theme

import androidx.compose.material3.ColorScheme

import androidx.compose.ui.graphics.Color


/* this color is used in Theme.kt to override the surface color of both dark and light color schemes */
val VeryLightGray200 = Color(0x68DCDCDC)


/* to add extra colors to our materialTheme.colorscheme */
val LightGreen200 = Color(0x9932CD32)

val ColorScheme.LightGreen: Color  // now, in mainactivity we can call MaterialTheme.colorScheme.LightGreen
    get() = LightGreen200


val md_theme_light_primary = Color(0xFF4F41E7)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_primaryContainer = Color(0xFFE3DFFF)
val md_theme_light_onPrimaryContainer = Color(0xFF110068)
val md_theme_light_secondary = Color(0xFF725C00)
val md_theme_light_onSecondary = Color(0xFFFFFFFF)
val md_theme_light_secondaryContainer = Color(0xFFFFE07D)
val md_theme_light_onSecondaryContainer = Color(0xFF231B00)
val md_theme_light_tertiary = Color(0xFFA63C00)
val md_theme_light_onTertiary = Color(0xFFFFFFFF)
val md_theme_light_tertiaryContainer = Color(0xFFFFDBCE)
val md_theme_light_onTertiaryContainer = Color(0xFF370E00)
val md_theme_light_error = Color(0xFFB91C14)
val md_theme_light_errorContainer = Color(0xFFFFDAD5)
val md_theme_light_onError = Color(0xFFFFFFFF)
val md_theme_light_onErrorContainer = Color(0xFF410000)
val md_theme_light_background = Color(0xFFFDFBFF)
val md_theme_light_onBackground = Color(0xFF1A1C1E)
val md_theme_light_outline = Color(0xFF79757F)
val md_theme_light_inverseOnSurface = Color(0xFFF1F0F4)
val md_theme_light_inverseSurface = Color(0xFF2F3033)
val md_theme_light_inversePrimary = Color(0xFFC4C0FF)
val md_theme_light_surfaceTint = Color(0xFF4F41E7)
val md_theme_light_outlineVariant = Color(0xFFCAC4CF)
val md_theme_light_scrim = Color(0xFF000000)
val md_theme_light_surface = Color(0xFFFAF9FD)
val md_theme_light_onSurface = Color(0xFF1A1C1E)
val md_theme_light_surfaceVariant = Color(0xFFE6E0EC)
val md_theme_light_onSurfaceVariant = Color(0xFF48454E)

val md_theme_dark_primary = Color(0xFFC4C0FF)
val md_theme_dark_onPrimary = Color(0xFF2100A4)
val md_theme_dark_primaryContainer = Color(0xFF361ED0)
val md_theme_dark_onPrimaryContainer = Color(0xFFE3DFFF)
val md_theme_dark_secondary = Color(0xFFE8C33C)
val md_theme_dark_onSecondary = Color(0xFF3B2F00)
val md_theme_dark_secondaryContainer = Color(0xFF564500)
val md_theme_dark_onSecondaryContainer = Color(0xFFFFE07D)
val md_theme_dark_tertiary = Color(0xFFFFB598)
val md_theme_dark_onTertiary = Color(0xFF591C00)
val md_theme_dark_tertiaryContainer = Color(0xFF7E2C00)
val md_theme_dark_onTertiaryContainer = Color(0xFFFFDBCE)
val md_theme_dark_error = Color(0xFFFFB4A9)
val md_theme_dark_errorContainer = Color(0xFF930003)
val md_theme_dark_onError = Color(0xFF690001)
val md_theme_dark_onErrorContainer = Color(0xFFFFDAD5)
val md_theme_dark_background = Color(0xFF1A1C1E)
val md_theme_dark_onBackground = Color(0xFFE3E2E6)
val md_theme_dark_outline = Color(0xFF938F99)
val md_theme_dark_inverseOnSurface = Color(0xFF1A1C1E)
val md_theme_dark_inverseSurface = Color(0xFFE3E2E6)
val md_theme_dark_inversePrimary = Color(0xFF4F41E7)
val md_theme_dark_surfaceTint = Color(0xFFC4C0FF)
val md_theme_dark_outlineVariant = Color(0xFF48454E)
val md_theme_dark_scrim = Color(0xFF000000)
val md_theme_dark_surface = Color(0xFF121316)
val md_theme_dark_onSurface = Color(0xFFC7C6CA)
val md_theme_dark_surfaceVariant = Color(0xFF48454E)
val md_theme_dark_onSurfaceVariant = Color(0xFFCAC4CF)


val seed = Color(0xFF2A00C7)

val PrimaryNormal = Color(0xFF6E51FF)
val DarkNormal = Color(0xFF28223E)
val SecondaryNormal = Color(0xFFEFD118)

val light_PrimaryNormal = Color(0xFF5B3AEC)
val light_onPrimaryNormal = Color(0xFFFFFFFF)
val light_PrimaryNormalContainer = Color(0xFFE5DEFF)
val light_onPrimaryNormalContainer = Color(0xFF190064)
val dark_PrimaryNormal = Color(0xFFC8BFFF)
val dark_onPrimaryNormal = Color(0xFF2D009D)
val dark_PrimaryNormalContainer = Color(0xFF420DD5)
val dark_onPrimaryNormalContainer = Color(0xFFE5DEFF)
val light_Dark = Color(0xFF6351A5)
val light_onDark = Color(0xFFFFFFFF)
val light_DarkContainer = Color(0xFFE7DEFF)
val light_onDarkContainer = Color(0xFF1F005F)
val dark_Dark = Color(0xFFCCBDFF)
val dark_onDark = Color(0xFF341F74)
val dark_DarkContainer = Color(0xFF4B388C)
val dark_onDarkContainer = Color(0xFFE7DEFF)
val light_SecondaryNormal = Color(0xFF6D5E00)
val light_onSecondaryNormal = Color(0xFFFFFFFF)
val light_SecondaryNormalContainer = Color(0xFFFFE248)
val light_onSecondaryNormalContainer = Color(0xFF211B00)
val dark_SecondaryNormal = Color(0xFFE3C600)
val dark_onSecondaryNormal = Color(0xFF393000)
val dark_SecondaryNormalContainer = Color(0xFF524600)
val dark_onSecondaryNormalContainer = Color(0xFFFFE248)

val ColorScheme.Dark: Color
    get() = DarkNormal

val ColorScheme.SecondaryNContainer: Color
    get() = light_SecondaryNormalContainer

val ColorScheme.OnSecondaryNContainer: Color
    get() = light_onSecondaryNormalContainer