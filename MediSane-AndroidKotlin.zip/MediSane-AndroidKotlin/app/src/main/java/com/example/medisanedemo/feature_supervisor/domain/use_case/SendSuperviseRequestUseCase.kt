package com.example.medisanedemo.feature_supervisor.domain.use_case

import com.example.medisanedemo.feature_supervisor.domain.model.SuperviseRequestInfo
import com.example.medisanedemo.feature_supervisor.domain.repository_interface.ISupervisorRepository
import javax.inject.Inject

class SendSuperviseRequestUseCase @Inject constructor(
    private val repository: ISupervisorRepository
) {

    /*
  * allows us to call this class as a function
  * */
    suspend operator fun invoke(
        patientId: Int,
        supervisorId: Int,
        token: String,
        sentBy: Boolean
    ): Int {

        val response = repository.sendSuperviseRequest(
            SuperviseRequestInfo(
                token = token,
                patientId = patientId,
                supervisorId = supervisorId,
                sentBy = sentBy,
            )
        )

        return response
    }
}