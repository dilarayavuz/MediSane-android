package com.example.medisanedemo.feature_login.domain.model

data class LoginInfo(
    val username: String,
    val password: String
)
