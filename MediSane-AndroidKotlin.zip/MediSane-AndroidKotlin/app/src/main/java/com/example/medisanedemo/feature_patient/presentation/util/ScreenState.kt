package com.example.medisanedemo.feature_patient.presentation.util

sealed class ScreenState {

    data class Error(val message: String): ScreenState()

    object Loading: ScreenState()
    object Success: ScreenState()
}
