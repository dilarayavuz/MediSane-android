package com.example.medisanedemo.feature_login.presentation.login

import android.util.Log
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.medisanedemo.feature_login.domain.model.Account
import com.example.medisanedemo.feature_login.domain.model.InvalidUserException
import com.example.medisanedemo.feature_login.domain.use_case.LoginUseCases
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val loginUseCases: LoginUseCases
): ViewModel() {

    //val TAG = "LoginViewModel" //DEBUG

    private val _state = mutableStateOf(LoginState())
    val state: State<LoginState> = _state

    private val responseEventChannel = Channel<ResponseEvent>() // channel with only one observer
    val responseEvents = responseEventChannel.receiveAsFlow() // receiveAsFlow returns an immutable flow, will be observed by the ui



    fun onEvent(event: LoginUIEvent) {

        when (event) {
            is LoginUIEvent.SetUsername -> {
                _state.value = state.value.copy(
                    username = event.username
                )
            }
            is LoginUIEvent.SetPassword -> {
                _state.value = state.value.copy(
                    password = event.password
                )
            }
            is LoginUIEvent.TogglePasswordVisibility -> {

                _state.value = state.value.copy(
                    isPasswordVisible = !state.value.isPasswordVisible
                )
            }
            is LoginUIEvent.LoginButtonPressed -> {
                viewModelScope.launch {
                    try {

                        val accountInfo: Account = loginUseCases.logUserIn.invoke(
                            _state.value.password,
                            _state.value.username
                        )

                        responseEventChannel.send(ResponseEvent.GoToProfilesFromLogin(accountInfo))

                    } catch (e: InvalidUserException) {

                        _state.value = state.value.copy(
                            errorMessage = e.message ?: "Login Failed",
                            isError = true
                        )

                    } catch (e: IOException) {
                        _state.value = state.value.copy(
                            errorMessage = "Internet Connection Failed, Please Check Your Internet Connection",
                            isError = true
                        )

                    } catch(e: HttpException) {
                        _state.value = state.value.copy(
                            errorMessage = e.message(),
                            isError = true
                        )
                    }


                }


            }

            LoginUIEvent.SignupButtonPressed -> {
                viewModelScope.launch {
                    responseEventChannel.send(ResponseEvent.GoToSignupFromLogin)
                }


            }
        }

    }

    /* one time events that ViewModel sends, and the UI reads
    * we do not want to hold onto these events unlike states that are persistent
    */
    sealed class ResponseEvent {
        data class GoToProfilesFromLogin(val account: Account): ResponseEvent()
        object GoToSignupFromLogin: ResponseEvent()
    }
}

