package com.example.medisanedemo.feature_patient.domain.model

import com.google.gson.annotations.SerializedName
import java.time.LocalDateTime

/*
* data transfer object
* will be converted to a Medicine object
* */
data class MedicineDto(
    @SerializedName("medicine_name")
    val name: String,
    @SerializedName("frequency")
    val frequency: Int,
    @SerializedName("remaining_amount")
    val remainingAmount: Int?,
    @SerializedName("has_notif")
    val hasNotification: Int,
    @SerializedName("dose_amount")
    val doseAmount: Int?,
    @SerializedName("usage_description")
    val usageDescription: String?,
    @SerializedName("end_date")
    val endDate: String?,
    @SerializedName("start_date")
    val startDate: String
)

fun MedicineDto.toMedicine(): Medicine {
    return Medicine(
        name = this.name,
        frequency = this.frequency,
        startDate = LocalDateTime.parse(this.startDate),
        remainingAmount = this.remainingAmount ?: -1, // -1 means no user input
        hasNotification = this.hasNotification == 1,
        doseAmount = this.doseAmount ?: -1, // -1 means no user input
        usageDescription = this.usageDescription ?: "",
        endDate = if (this.endDate.isNullOrEmpty()) {
            LocalDateTime.parse(this.startDate).plusYears(1)
        } else {
            LocalDateTime.parse(this.endDate)
        },
        isEndDateNull = this.endDate.isNullOrEmpty()
    )
}
