package com.example.medisanedemo.feature_patient.presentation.add_medicine.additional_options_screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.presentation.login.components.HeadlineTextComponent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.AddMedicineState
import com.example.medisanedemo.feature_patient.presentation.add_medicine.AddMedicineViewModel
import com.example.medisanedemo.feature_patient.presentation.add_medicine.components.AlertDialogComponent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.components.ClickableColumnComponent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.components.IntegerTextFieldDialogueComponent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.components.SetNotificationDialog
import com.example.medisanedemo.feature_patient.presentation.add_medicine.components.SubmitButtonComponent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.components.TextFieldDialogueComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.DatePickerComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.TopAppBarComponent
import com.example.medisanedemo.ui.theme.MyTheme
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import java.time.LocalDateTime

@Composable
fun AdditionalOptionsScreen(
    state: AddMedicineState,
    responseEvents: Flow<AddMedicineViewModel.ResponseEvent>,
    onPressAddUsageDescription: () -> Unit,
    onPressSetRemindersDescription: () -> Unit,
    onPressSetEndDate: () -> Unit,
    onPressedBackButton: () -> Unit,
    onPressSubmitButton: () -> Unit,
    onPressLogoutButton: () -> Unit,
    onDismissUsageDescription: () -> Unit,
    onConfirmUsageDescription: () -> Unit,
    onUsageDescriptionChange: (String) -> Unit,
    onDismissEndDatePicker: () -> Unit,
    onConfirmEndDatePicker: (LocalDateTime) -> Unit,
    onPressSetRemainingAmount: () -> Unit,
    onDismissRemainingAmount: () -> Unit,
    onConfirmRemainingAmount: () -> Unit,
    onRemainingAmountValueChange: (String) -> Unit,
    onDismissAlertDialog: () -> Unit,
    onSubmitMedicine: (String, Int, Int, String, Boolean) -> Unit,
    onDismissSetNotification: () -> Unit,
    onNotificationValueChange: (Boolean) -> Unit,

) {

    val context = LocalContext.current

    LaunchedEffect(key1 = context) {// LaunchedEffect(key = context) --> when context changes, this affect will be relaunched
        responseEvents.collect { event ->
            when (event) {
                is AddMedicineViewModel.ResponseEvent.GoToHomeScreen -> {
                    onSubmitMedicine(state.token, state.accountId, state.profileId, state.profileName, state.isSupervisor)
                }

                else -> {}
            }

        }
    }

    Scaffold(
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.additional_options),
                isHomeScreen = false,
                isSelectProfileScreen = false,
                onBackButtonPressed = onPressedBackButton,
                onLogoutButtonPressed = onPressLogoutButton,
                isSelectPatientScreen = false,
                hasNotification = false,
            )
        }
    ) {
        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
                .padding(paddingValues = it)
        ) {

            Column(
                modifier = Modifier
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {


                HeadlineTextComponent(
                    value = stringResource(id = R.string.additional_options),
                    fontSize = 28
                )

                Spacer(modifier = Modifier.height(20.dp))


                ClickableColumnComponent(
                    onClick = onPressAddUsageDescription,
                    textValue = stringResource(id = R.string.add_usage_descriptions)
                )

                if (state.isUsageDescriptionVisible) {
                    TextFieldDialogueComponent(
                        onDismissRequest = onDismissUsageDescription,
                        onConfirmRequest = onConfirmUsageDescription,
                        onUsageDescriptionChange = onUsageDescriptionChange,
                        usageDescription = state.usageDescription
                    )
                }
                ClickableColumnComponent(
                    onClick = onPressSetRemindersDescription,
                    textValue = stringResource(id = R.string.set_reminders)
                )

                if (state.isSetNotificationVisible) {
                    SetNotificationDialog(
                        onDismissRequest = onDismissSetNotification,
                        onSetNotificationChange = onNotificationValueChange,
                        hasNotification = state.hasNotification,
                    )
                }
                ClickableColumnComponent(
                    onClick = onPressSetEndDate,
                    textValue = stringResource(id = R.string.set_end_date)
                )
                if (state.isSetEndDateVisible) {
                    DatePickerComponent(
                        modifier = Modifier,
                        selectedDate = state.endDate ?: LocalDateTime.now(),
                        onDismiss = onDismissEndDatePicker,
                        onConfirm = onConfirmEndDatePicker
                    )
                }

                ClickableColumnComponent(
                    onClick = onPressSetRemainingAmount,
                    textValue = stringResource(id = R.string.set_pills_remaining)
                )

                if (state.isRemainingAmountVisible) {

                    IntegerTextFieldDialogueComponent(
                        onDismissRequest = onDismissRemainingAmount,
                        onConfirmRequest = onConfirmRemainingAmount,
                        onValueChange = onRemainingAmountValueChange,
                        value = state.remainingAmountDisplay,
                        label = "Remaining Pill Amount"
                    )

                }


                Spacer(modifier = Modifier.height(40.dp))

                Column (
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ){
                    SubmitButtonComponent(
                        textValue = stringResource(id = R.string.add_medicine),
                        onButtonClick = onPressSubmitButton
                    )
                }

                if (state.isError) {
                    AlertDialogComponent(
                        onDismissRequest = onDismissAlertDialog,
                        dialogTitle = stringResource(id = R.string.error),
                        dialogText = state.errorMessage,
                        icon = Icons.Outlined.Warning
                    )
                }


            }


        }

    }


}


@Preview(showBackground = true)
@Composable
fun SubmitButtonPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){
            AdditionalOptionsScreen(
                state = AddMedicineState(),
                responseEvents = flowOf(),
                onPressAddUsageDescription = {},
                onPressSetRemindersDescription = {},
                onPressSetEndDate = {},
                onPressSubmitButton = {},
                onSubmitMedicine = {str1, int1, int2, str2, bool ->

                },
                onConfirmUsageDescription = {},
                onDismissUsageDescription = {},
                onUsageDescriptionChange = {},
                onConfirmEndDatePicker = {},
                onDismissEndDatePicker = {},
                onDismissAlertDialog = {},
                onPressedBackButton = {},
                onPressLogoutButton = {},
                onPressSetRemainingAmount = {},
                onConfirmRemainingAmount = {},
                onDismissRemainingAmount = {},
                onRemainingAmountValueChange = {},
                onNotificationValueChange = {},
                onDismissSetNotification = {},
            )
        }

    }
}
