package com.example.medisanedemo.feature_patient.presentation.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.presentation.select_profile.components.ErrorScreenComponent
import com.example.medisanedemo.feature_patient.domain.model.Medicine
import com.example.medisanedemo.feature_patient.domain.model.MedicineReport
import com.example.medisanedemo.feature_patient.presentation.home.components.BottomAppBarComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.CustomDatePickerComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.GroupedMedicineLazyListComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.Label
import com.example.medisanedemo.feature_patient.presentation.home.components.TopAppBarComponent
import com.example.medisanedemo.feature_patient.presentation.util.PatientUiUtils.getMedicinesOfDay
import com.example.medisanedemo.feature_patient.presentation.util.PatientUiUtils.groupMedicinesByPastOrFuture
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import java.time.LocalDateTime

@Composable
fun HomeScreen(
    onNavigateToProfiles: (String, Int) -> Unit,
    onNavigateToPatientsList: () -> Unit,
    onNavigateToMyMedicines: (String, Int, Int, String, Boolean) -> Unit,
    onNavigateToNotificationScreen: (String, Int) -> Unit,
    onProfileClick: (Int) -> Unit,
    onDayOfMonthSelected: (Int) -> Unit,
    onPreviousMonthSelected: () -> Unit,
    onRetry: () -> Unit,
    onPressBackButton: () -> Unit,
    onPressHelpButton: () -> Unit,
    onPressLogoutButton: () -> Unit,
    onPressNotificationButton: (Int) -> Unit,
    onNextMonthPressed: () -> Unit,
    onFloatingButtonPressed: (String, Int, Int, String, Boolean) -> Unit,
    onMedicationClick: (Int) -> Unit,
    onClickLabeledReport: (Medicine, LocalDateTime, Label) -> Unit,
    onClickUnlabeledReport: (MedicineReport) -> Unit,
    responseEvents: Flow<HomeViewModel.ResponseEvent>,
    state: HomeState
) {

    val TAG = "HomeScreen"
    val context = LocalContext.current

    LaunchedEffect(key1 = context) { // LaunchedEffect(key = context) --> when context changes, this affect will be relaunched
        responseEvents.collect { event ->
            when (event) {
                is HomeViewModel.ResponseEvent.GoToProfilesFromHome -> {
                    onNavigateToProfiles(state.token ,event.accountId)
                }

                is HomeViewModel.ResponseEvent.GoToMyMedicinesFromHome -> {
                    onNavigateToMyMedicines(state.token, state.accountId, event.profileId, state.profile.profileName, state.isSupervisor)
                }

                is HomeViewModel.ResponseEvent.GoToSelectPatientsFromHome -> {
                    onNavigateToPatientsList()
                }

                is HomeViewModel.ResponseEvent.GoToNoticationsFromHome -> {
                    onNavigateToNotificationScreen(state.token, event.profileId)
                }
            }

        }

    }

    when (state.screenState) {
        is ScreenState.Error -> {
            ErrorScreen(
                onRetry = onRetry,
                onPressBackButton = onPressBackButton,
                onPressLogoutButton = onPressLogoutButton,
                message = state.screenState.message

            )
        }
        is ScreenState.Loading -> {
            LoadingScreen(
                onPressBackButton = onPressBackButton,
                onPressLogoutButton = onPressLogoutButton
            )
        }
        is ScreenState.Success -> {

            SuccessScreen(
                onProfileClick = onProfileClick,
                onDayOfMonthSelected = onDayOfMonthSelected,
                onPreviousMonthSelected = onPreviousMonthSelected,
                onPressBackButton = onPressBackButton,
                onPressLogoutButton = onPressLogoutButton,
                onPressHelpButton = onPressHelpButton,
                onPressNotificationButton = onPressNotificationButton,
                onNextMonthPressed = onNextMonthPressed,
                onFloatingButtonPressed = onFloatingButtonPressed,
                onMedicationClick = onMedicationClick,
                onClickLabeledReport = onClickLabeledReport,
                onClickUnlabeledReport = onClickUnlabeledReport,
                state = state
            )

        }
    }

}

@Composable
fun SuccessScreen(
    onProfileClick: (Int) -> Unit,
    onDayOfMonthSelected: (Int) -> Unit,
    onPreviousMonthSelected: () -> Unit,
    onPressBackButton: () -> Unit,
    onPressHelpButton: () -> Unit,
    onPressLogoutButton: () -> Unit,
    onPressNotificationButton: (Int) -> Unit,
    onNextMonthPressed: () -> Unit,
    onFloatingButtonPressed: (String, Int, Int, String, Boolean) -> Unit,
    onMedicationClick: (Int) -> Unit,
    onClickLabeledReport: (Medicine, LocalDateTime, Label) -> Unit,
    onClickUnlabeledReport: (MedicineReport) -> Unit,
    state: HomeState
) {


    Scaffold (
        topBar = {
            TopAppBarComponent(
                title = state.profile.profileName + "'s Home",
                isHomeScreen = true,
                isSelectProfileScreen = false,
                onBackButtonPressed = onPressBackButton,
                onLogoutButtonPressed = onPressLogoutButton,
                onHelpButtonPressed = onPressHelpButton,
                onNotificationButtonPressed = {
                    onPressNotificationButton(state.profile.profileId)
                                              },
                isSelectPatientScreen = false,
                hasNotification = state.hasNotification,
                isSupervisor = state.isSupervisor,
            )
        },
        bottomBar = {
            BottomAppBarComponent(
                isHomeScreen = true,
                onProfileClick = {
                    onProfileClick(state.accountId)
                },
                onFloatingButtonPressed = {
                    onFloatingButtonPressed(state.token, state.accountId, state.profile.profileId, state.profile.profileName, state.isSupervisor)
                },
                onMedicationClick = {
                    onMedicationClick(state.profile.profileId)
                }
            )
        }
    ) {
        Surface(
            modifier = Modifier
                .padding(it)
        ) {
            Column {
                CustomDatePickerComponent(
                    selectedDate = state.selectedDate,
                    rowState = state.rowState,
                    onDayOfMonthSelected = onDayOfMonthSelected,
                    onPreviousMonthPressed = onPreviousMonthSelected,
                    onNextMonthPressed = onNextMonthPressed
                )

                Spacer(modifier = Modifier.height(40.dp))

                GroupedMedicineLazyListComponent(
                    groupedMedicineList = groupMedicinesByPastOrFuture(getMedicinesOfDay(state.medicineList, state.selectedDate), state.selectedDate),
                    medicineReportList = state.medicineReportList,
                    onClickLabeledReport = onClickLabeledReport,
                    onClickUnlabeledReport = onClickUnlabeledReport,
                    selectedDate = state.selectedDate,
                )

            }


        }

    }
}

@Composable
fun ErrorScreen(
    message: String,
    onRetry: () -> Unit,
    onPressBackButton: () -> Unit,
    onPressLogoutButton: () -> Unit,
) {

    Scaffold (
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.home),
                isHomeScreen = true,
                isSelectProfileScreen = false,
                onBackButtonPressed = onPressBackButton,
                onLogoutButtonPressed = onPressLogoutButton,
                isSelectPatientScreen = false,
                hasNotification = false,
            )
        },
        bottomBar = {
            BottomAppBarComponent(
                isHomeScreen = true,
                onProfileClick = {},
                onFloatingButtonPressed = {},
                onMedicationClick = {}
            )
        }
    ) {
        Surface(
            modifier = Modifier
                .padding(it)
        ) {

            ErrorScreenComponent (
                message = message,
                onRetry = onRetry
            )


        }

    }

}

@Composable
fun LoadingScreen(
    onPressBackButton: () -> Unit,
    onPressLogoutButton: () -> Unit,
) {

    Scaffold (
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.home),
                isHomeScreen = true,
                isSelectProfileScreen = false,
                onBackButtonPressed = onPressBackButton,
                onLogoutButtonPressed = onPressLogoutButton,
                isSelectPatientScreen = false,
                hasNotification = false,
            )
        },
        bottomBar = {
            BottomAppBarComponent(
                isHomeScreen = true,
                onProfileClick = {},
                onFloatingButtonPressed = {},
                onMedicationClick = {}
            )
        }
    ) {
        Surface(
            modifier = Modifier
                .padding(it)
        ) {

            Column (
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxSize()
            ){

                CircularProgressIndicator(
                    modifier = Modifier.width(64.dp),
                    color = MaterialTheme.colorScheme.secondary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )

            }


        }

    }

}

/*
@Preview(showBackground = true)
@Composable
fun HomeScreenSuccessPreview() {
    HomeScreen(
        onNavigateToProfiles = {str, int ->},
        onNavigateToMyMedicines = {str1, int1, int2, str2, bool ->},
        onProfileClick = {},
        onDayOfMonthSelected = {},
        onPreviousMonthSelected = {},
        onNextMonthPressed = { },
        onFloatingButtonPressed = {str1,int1, int2, str2, bool ->

        },
        onMedicationClick = {},
        responseEvents = flowOf(),
        state = HomeState(
            medicineList = listOf(
            ),
            screenState = ScreenState.Success,
        ),
        onPressBackButton = {},
        onPressLogoutButton = {},
        onPressHelpButton = {},
        onPressNotificationButton = {},
        onRetry = {},
        onNavigateToPatientsList = {},
        onClickLabeledReport = {med, ldt, label ->},
        onClickUnlabeledReport = {rep ->},
        onNavigateToNotificationScreen = {str1, int1 ->},
    )
}

 */



/*
@Preview(showBackground = true)
@Composable
fun HomeScreenErrorPreview() {
    HomeScreen(
        onNavigateToProfiles = {str, int ->},
        onNavigateToMyMedicines = {str1, int1, int2, str2, bool ->},
        onProfileClick = {},
        onDayOfMonthSelected = {},
        onPreviousMonthSelected = {  },
        onNextMonthPressed = {  },
        onFloatingButtonPressed = {str1,int1, int2, str2, bool ->

        },
        onMedicationClick = {},
        responseEvents = flowOf(),
        state = HomeState(
            medicineList = listOf(
            ),
            screenState = ScreenState.Error("cannot connect")
        ),
        onPressBackButton = {},
        onPressLogoutButton = {},
        onPressHelpButton = {},
        onRetry = {},
        onNavigateToPatientsList = {},
        onClickLabeledReport = {med, ldt, label ->},
        onClickUnlabeledReport = {rep ->},
    )
}
*/

/*
@Preview(showBackground = true)
@Composable
fun HomeScreenLoadingPreview() {
    HomeScreen(
        onNavigateToProfiles = {str, int ->},
        onNavigateToMyMedicines = {str1, int1, int2, str2, bool->},
        onProfileClick = {},
        onDayOfMonthSelected = {},
        onPreviousMonthSelected = {  },
        onNextMonthPressed = { },
        onFloatingButtonPressed = {str1,int1, int2, str2, bool->

        },
        onMedicationClick = {},
        responseEvents = flowOf(),
        state = HomeState(
            medicineList = listOf(
            ),
            screenState = HomeScreenState.Loading
        ),
        onPressBackButton = {},
        onPressLogoutButton = {},
        onPressHelpButton = {},
        onRetry = {},
        onNavigateToPatientsList = {},
        onClickLabeledReport = {med, ldt, label ->},
        onClickUnlabeledReport = {rep ->},
    )
}
*/



