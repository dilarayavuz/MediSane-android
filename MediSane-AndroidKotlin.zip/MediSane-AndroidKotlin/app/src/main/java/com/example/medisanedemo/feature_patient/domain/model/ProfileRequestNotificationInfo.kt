package com.example.medisanedemo.feature_patient.domain.model

data class ProfileRequestNotificationInfo(
    val profileId: Int,
    val token: String
)
