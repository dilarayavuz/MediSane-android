package com.example.medisanedemo.feature_login.presentation.login.components


import android.util.Log
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.example.medisanedemo.R


@Composable
fun PasswordTextFieldComponent(
    labelValue: String,
    imageVector: ImageVector,
    onValueChange: (String) -> Unit,
    onIconClick: () -> Unit,
    isError: Boolean = false,
    isPasswordVisible: Boolean,
    textValue: String
) {
    //val TAG = "PasswordTextFieldComponent"; // DEBUG


    val visibility_on_res = painterResource(id = R.drawable.visibility_on)
    val visibility_off_res = painterResource(id = R.drawable.visibility_off)

    OutlinedTextField(
        modifier = Modifier.fillMaxWidth()
            .onKeyEvent { event: KeyEvent ->
                if (event.key == Key.Enter){
                    /* do nothing */
                    true
                }
                false
            },
        value = textValue,
        isError = isError,
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            focusedLabelColor = MaterialTheme.colorScheme.primary,
            cursorColor = MaterialTheme.colorScheme.primary,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface
        ),
        onValueChange = {
            onValueChange(it)
                        },
        label = { Text(text = labelValue) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        leadingIcon = { Icon(imageVector = imageVector, contentDescription = "enter username")},
        trailingIcon = {
            val iconImage = if (isPasswordVisible) {
                Icon(painter = visibility_on_res, contentDescription = "hide password")
            }
            else {
                Icon(painter = visibility_off_res, contentDescription = "show password")
            }

            IconButton(
                onClick = onIconClick
            ) {

                iconImage
            }
                       },
        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation()
    )

}