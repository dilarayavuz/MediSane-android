package com.example.medisanedemo.feature_patient.domain.use_case

import com.example.medisanedemo.feature_patient.domain.model.Medicine
import com.example.medisanedemo.feature_patient.domain.model.MedicineInfo
import com.example.medisanedemo.feature_patient.domain.repository_interface.IMedicineRepository
import javax.inject.Inject

class AddMedicineUseCase @Inject constructor(
    private val repository: IMedicineRepository
) {
    /*
    * allows us to call this class as a function
    * */
    suspend operator fun invoke(
        medicineInfo: MedicineInfo
    ) {
         repository.addMedicine(medicineInfo)
    }
}