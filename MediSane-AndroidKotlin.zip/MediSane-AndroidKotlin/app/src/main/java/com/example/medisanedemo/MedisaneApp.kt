package com.example.medisanedemo

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MedisaneApp: Application() {
}