package com.example.medisanedemo.feature_patient.presentation.home.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.medisanedemo.R
import com.example.medisanedemo.ui.theme.MyTheme
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun PastMedicineColumnComponent(
    medicineName: String,
    medicineIconPainter: Painter,
    medicineStartDate: LocalDateTime,
    label: Label,
    onClickUnlabeledToTaken: () -> Unit,
    onClickUnlabeledToMissed: () -> Unit,
    onClickLabeledToUnlabeled: () -> Unit,
) {

    val containerColor: Color = if (label == Label.UNLABELED) {
        MaterialTheme.colorScheme.primaryContainer
    } else if (label == Label.MISSED) {
        MaterialTheme.colorScheme.errorContainer
    }
    else {
        MaterialTheme.colorScheme.secondaryContainer
    }

    Column(
        modifier = Modifier
            .padding(8.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(containerColor)
            .fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .padding(start = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Icon(
                painter = medicineIconPainter,
                contentDescription = medicineName,
                modifier = Modifier.size(36.dp)
            )

            Spacer(modifier = Modifier.width(20.dp))

            Column(
                modifier = Modifier
                    .padding(4.dp)
                    .size(width = 150.dp, height = 86.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = medicineName,
                    style = TextStyle(
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontStyle = FontStyle.Normal,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = medicineStartDate.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm")),
                    style = TextStyle(
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Normal,
                        fontStyle = FontStyle.Normal,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                )
            }

            Column (
                modifier = Modifier
                    .padding(4.dp)
            ){

                if (label == Label.UNLABELED) {
                    IconButton(
                        onClick = onClickUnlabeledToTaken,
                        modifier = Modifier
                            .size(54.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Label the medicine as taken",
                            modifier = Modifier
                                .size(32.dp)
                        )
                    }

                    IconButton(
                        onClick = onClickUnlabeledToMissed,
                        modifier = Modifier
                            .size(54.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Label the medicine as missed",
                            modifier = Modifier
                                .size(32.dp)
                        )
                    }

                }


                if (label == Label.TAKEN){
                    IconButton(
                        onClick = onClickLabeledToUnlabeled,
                        modifier = Modifier
                            .size(54.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Edit medicine label",
                            modifier = Modifier
                                .size(32.dp)
                        )
                    }
                }

                if (label == Label.MISSED) {

                    IconButton(
                        onClick = onClickLabeledToUnlabeled,
                        modifier = Modifier
                            .size(54.dp)
                    ) {
                        Icon(
                                imageVector = Icons.Default.Close,
                        contentDescription = "Label the medicine as missed",
                        modifier = Modifier
                            .size(32.dp)
                        )
                    }
                }

            }


        }

    }

}


enum class Label {

    TAKEN, MISSED, UNLABELED
}

@Preview
@Composable
fun PastMedicineColumnComponentPrev() {

    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){

            Column {

                PastMedicineColumnComponent(
                    medicineName = "Augmentin",
                    medicineIconPainter = painterResource(id = R.drawable.medication),
                    label = Label.TAKEN,
                    medicineStartDate = LocalDateTime.now(),
                    onClickUnlabeledToTaken = {},
                    onClickUnlabeledToMissed = {},
                    onClickLabeledToUnlabeled = {},
                )

                PastMedicineColumnComponent(
                    medicineName = "Bugumentin",
                    medicineIconPainter = painterResource(id = R.drawable.medication),
                    label = Label.MISSED,
                    medicineStartDate = LocalDateTime.now(),
                    onClickUnlabeledToTaken = {},
                    onClickUnlabeledToMissed = {},
                    onClickLabeledToUnlabeled = {},
                )

                PastMedicineColumnComponent(
                    medicineName = "Gugumentin",
                    medicineIconPainter = painterResource(id = R.drawable.medication),
                    label = Label.UNLABELED,
                    medicineStartDate = LocalDateTime.now(),
                    onClickUnlabeledToTaken = {},
                    onClickUnlabeledToMissed = {},
                    onClickLabeledToUnlabeled = {},
                )



            }


        }

    }

}