package com.example.medisanedemo.feature_patient.presentation.home

import com.example.medisanedemo.feature_patient.domain.model.Medicine
import com.example.medisanedemo.feature_patient.domain.model.MedicineReport
import com.example.medisanedemo.feature_patient.presentation.home.components.Label
import java.time.LocalDateTime

sealed class HomeUiEvent {
    data class GoToProfiles(val accountId: Int): HomeUiEvent()
    data class SetDayOfMonth(val dayOfMonth: Int): HomeUiEvent()
    data class GoToMyMedicines(val profileId: Int): HomeUiEvent()
    data class GoToNotifications(val profileId: Int): HomeUiEvent()
    data class SetMedicineReport(val medicine: Medicine, val hourOfDose: LocalDateTime, val label: Label): HomeUiEvent()
    data class ResetMedicineReport(val medicineReport: MedicineReport): HomeUiEvent()

    object SetPreviousMonth: HomeUiEvent()
    object SetNextMonth: HomeUiEvent()
    object Retry: HomeUiEvent()
}