package com.example.medisanedemo.feature_patient.domain.model

import com.google.gson.annotations.SerializedName

data class AwaitingRequestsDto(
    @SerializedName("awaiting_requests")
    val awaitingRequests: List<SuperviseRequestDto>
)
