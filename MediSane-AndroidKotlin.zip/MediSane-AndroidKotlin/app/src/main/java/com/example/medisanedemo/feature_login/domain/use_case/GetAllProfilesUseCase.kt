package com.example.medisanedemo.feature_login.domain.use_case

import com.example.medisanedemo.feature_login.domain.model.AccountInfo
import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_login.domain.model.ProfileDto
import com.example.medisanedemo.feature_login.domain.model.toProfile
import com.example.medisanedemo.feature_login.domain.repository_interface.ILoginRepository
import javax.inject.Inject

class GetAllProfilesUseCase @Inject constructor(
    private val repository: ILoginRepository
) {

    suspend operator fun invoke(token: String, accountId: Int): List<Profile> {
        val profileList = mutableListOf<Profile>()
        val profileDtoList = repository.getAllProfiles(
            AccountInfo(
                accountId = accountId,
                token = token
            )
        )

        profileDtoList.forEach { dto: ProfileDto ->

            profileList.add(dto.toProfile())
        }

        return profileList.toList()
    }
}