package com.example.medisanedemo.feature_supervisor.presentation.patient_list

import com.example.medisanedemo.feature_login.domain.model.Profile

sealed class SelectPatientUIEvent {

    data class GoToPatient(val profile: Profile): SelectPatientUIEvent()


    data class DeletePatient(val profileId: Int): SelectPatientUIEvent() //TODO
    data class ToggleAddPatientDialog(val isVisible: Boolean): SelectPatientUIEvent()
    data class SetPatientToAddName(val profileName: String): SelectPatientUIEvent()

    data class AddPatient(val patientId: Int): SelectPatientUIEvent()
    data class GoToNotifications(val profileId: Int): SelectPatientUIEvent()
    object GetPatientProfilesToAdd: SelectPatientUIEvent()
    object Retry: SelectPatientUIEvent()
    object UpdateContent: SelectPatientUIEvent()
}
