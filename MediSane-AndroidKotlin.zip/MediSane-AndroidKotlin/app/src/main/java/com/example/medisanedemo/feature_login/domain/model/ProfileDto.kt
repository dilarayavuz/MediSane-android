package com.example.medisanedemo.feature_login.domain.model

data class ProfileDto(
    val profileId: Int,
    val profileName: String,
    val type: String
)

fun ProfileDto.toProfile(): Profile {

    return Profile(
        profileId = profileId,
        profileName = profileName,
        type = if (type == "patient") {
            ProfileType.PATIENT
        } else {
            ProfileType.SUPERVISOR
        }
    )
}
