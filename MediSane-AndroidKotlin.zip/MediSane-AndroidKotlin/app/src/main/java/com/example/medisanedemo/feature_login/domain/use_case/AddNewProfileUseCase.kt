package com.example.medisanedemo.feature_login.domain.use_case

import android.util.Log
import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_login.domain.model.ProfileToAddInfo
import com.example.medisanedemo.feature_login.domain.repository_interface.ILoginRepository
import javax.inject.Inject

class AddNewProfileUseCase @Inject constructor(
    private val repository: ILoginRepository
) {
    val TAG = "AddNewProfileUseCase"

    suspend operator fun invoke(profileToAddInfo: ProfileToAddInfo): String {

        val new_token = repository.addNewProfile(profileToAddInfo)

        Log.d(TAG, "new token: $new_token")
        return new_token.token
    }

}