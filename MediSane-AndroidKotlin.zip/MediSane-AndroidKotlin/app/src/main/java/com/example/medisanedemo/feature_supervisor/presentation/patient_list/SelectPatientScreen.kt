package com.example.medisanedemo.feature_supervisor.presentation.patient_list

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavBackStackEntry
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_login.presentation.select_profile.components.ErrorScreenComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.BottomAppBarComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.TopAppBarComponent
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState
import com.example.medisanedemo.feature_supervisor.domain.model.ProfileToAddDto
import com.example.medisanedemo.feature_supervisor.presentation.patient_list.components.AddPatientDialog
import com.example.medisanedemo.feature_supervisor.presentation.patient_list.components.LazyPatientColumnComponent
import com.example.medisanedemo.navigation.util.Screen
import kotlinx.coroutines.flow.Flow


@Composable
fun SelectPatientScreen(
    state: SelectPatientState,
    responseEvents: Flow<SelectPatientViewModel.ResponseEvent>,
    onRetry: () -> Unit,
    onDismissAddPatient: () -> Unit,
    onConfirmGetPatients: () -> Unit,
    onPatientNameToAddChange: (String) -> Unit,
    onPressedAddPatient: () -> Unit,
    onNavigateToPatientProfile: (String, Int, Profile) -> Unit,
    onNavigateToNotificationScreen: (String, Int) -> Unit,
    onPatientClick: (Profile) -> Unit,
    onPressBackButton: () -> Unit,
    onPressLogoutButton: () -> Unit,
    onNavigateBack: () -> Unit,
    onPressNotificationButton: (Int) -> Unit,
    onPressedProfileToSupervise: (ProfileToAddDto) -> Unit,
    currentBackStackEntry: NavBackStackEntry?,
) {

    val context = LocalContext.current
    val TAG = "SelectPatientScreen"

    LaunchedEffect(key1 = context) {// LaunchedEffect(key = context) --> when context changes, this affect will be relaunched
        responseEvents.collect {event ->
            when (event) {
                is SelectPatientViewModel.ResponseEvent.PatientSelected -> {
                    onNavigateToPatientProfile(state.token, state.accountId, event.profile)

                }

                is SelectPatientViewModel.ResponseEvent.GoToNoticationsFromSelectPatient -> {
                    onNavigateToNotificationScreen(state.token, event.profileId)
                }
            }

        }
    }
    //Log.d(TAG, "The tag is working!")

    LaunchedEffect(currentBackStackEntry) {

        //Log.d(TAG, "LaunchedEffect called")
        if (currentBackStackEntry != null) {
            val destination = currentBackStackEntry.destination.route?.substringBefore("/")

            if (!state.isFirstCall
                && destination == Screen.SelectPatientScreen.route
            ) {

                //Log.d(TAG, "Updating content inside LaunchedEffect")

                onNavigateBack()
            }
        }
    }

    when (state.screenState) {
        is ScreenState.Error -> {
            ErrorScreen(
                onRetry = onRetry,
                message = state.screenState.message
            )
        }
        is ScreenState.Loading -> {
            LoadingScreen()
        }
        is ScreenState.Success -> {
            SuccessScreen(
                state = state,
                onPatientClick = onPatientClick,
                onPressedAddPatient = onPressedAddPatient,
                onConfirmGetPatients = onConfirmGetPatients,
                onDismissAddPatient = onDismissAddPatient,
                onPatientNameToAddChange = onPatientNameToAddChange,
                onPressBackButton = onPressBackButton,
                onPressNotificationButton = onPressNotificationButton,
                onPressedProfileToSupervise = onPressedProfileToSupervise,
                onPressLogoutButton = onPressLogoutButton,
            )
        }
    }
}

@Composable
fun SuccessScreen(
    state: SelectPatientState,
    onPatientClick: (Profile) -> Unit,
    onPressedAddPatient: () -> Unit,
    onDismissAddPatient: () -> Unit,
    onConfirmGetPatients: () -> Unit,
    onPressBackButton: () -> Unit,
    onPressLogoutButton: () -> Unit,
    onPressNotificationButton: (Int) -> Unit,
    onPressedProfileToSupervise: (ProfileToAddDto) -> Unit,
    onPatientNameToAddChange: (String) -> Unit,
) {

    Scaffold (
        snackbarHost = {
            SnackbarHost(hostState = state.snackbarHostState)
        },
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.select_patient),
                isHomeScreen = false,
                isSelectProfileScreen = false,
                onBackButtonPressed = onPressBackButton,
                onNotificationButtonPressed = {
                    onPressNotificationButton(state.profile.profileId)
                                              },
                onLogoutButtonPressed = onPressLogoutButton,
                isSelectPatientScreen = true,
                hasNotification = state.hasNotification,
                isSupervisor = true,
            )
        },
        bottomBar = {
            BottomAppBarComponent(
                isHomeScreen = false,
                onAddProfileButtonPressed = onPressedAddPatient,
            )
        }
    ){
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(it)
        ) {

            LazyPatientColumnComponent(
                patientList = state.patientProfileList,
                onPatientClick = onPatientClick,
                onPressDeletePatient = {/* TODO */}
            )


            if (state.isAddPatientDialogVisible) {

                AddPatientDialog(
                    onDismissRequest = onDismissAddPatient,
                    onConfirmRequest = onConfirmGetPatients,
                    onPatientNameChange = onPatientNameToAddChange,
                    onPressedProfileToSupervise = onPressedProfileToSupervise,
                    patientName = state.patientToAddName,
                    addPatientErrorMessage = state.addPatientErrorMessage,
                    isAddPatientError = state.isAddPatientError,
                    profilesToAddList = state.profilesToAddList,
                )
            }



        }
    }

}

@Composable
fun ErrorScreen(
    onRetry: () -> Unit,
    message: String
) {

    Scaffold (
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.select_patient),
                isHomeScreen = false,
                isSelectProfileScreen = true,
                isSelectPatientScreen = true,
                hasNotification = false,
                isSupervisor = true,
            )
        },
        bottomBar = {
            BottomAppBarComponent(
                isHomeScreen = false,
                onAddProfileButtonPressed = {  }
            )
        }
    ){
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(it)
        ) {

            ErrorScreenComponent (
                message = message,
                onRetry = onRetry
            )

        }
    }

}

@Composable
fun LoadingScreen() {

    Scaffold (
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.select_patient),
                isHomeScreen = false,
                isSelectProfileScreen = true,
                isSelectPatientScreen = true,
                hasNotification = false,
                isSupervisor = true,
            )
        },
        bottomBar = {
            BottomAppBarComponent(
                isHomeScreen = false,
                onAddProfileButtonPressed = {  }
            )
        }
    ){
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(it)
        ) {

            Column (
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ){

                CircularProgressIndicator(
                    modifier = Modifier.width(64.dp),
                    color = MaterialTheme.colorScheme.secondary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )

            }

        }
    }
}

/*
@Preview(showBackground = true)
@Composable
fun SelectPatientSuccessPrev() {
    SelectPatientScreen(
        state = SelectPatientState(
            patientProfileList = listOf(
                profileDefault()
            ),
            screenState = ScreenState.Success
        ),
        responseEvents = flowOf(),
        onDismissAddPatient = {  },
        onConfirmGetPatients = {  },
        onPatientNameToAddChange = {  },
        onPressedAddPatient = {  },
        onNavigateToPatientProfile = {str, int, profile ->  },
        onPatientClick = {  },
        onRetry = {  },
        onPressBackButton = {},
        onPressNotificationButton = {},
        onPressedProfileToSupervise = {},
        onNavigateToNotificationScreen = {str1, int1 ->},
        onPressLogoutButton = {},
    )
}

 */

