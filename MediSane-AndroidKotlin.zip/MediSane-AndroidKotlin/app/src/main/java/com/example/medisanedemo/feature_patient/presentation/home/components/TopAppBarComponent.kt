package com.example.medisanedemo.feature_patient.presentation.home.components

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarComponent(
    title: String,
    isHomeScreen: Boolean,
    isSelectProfileScreen: Boolean,
    /* if (isSupervisor == true && isSelectPatientScreen == true) show notif icon
    *  if (isSupervisor == false && isHomeScreen == true) show notif icon
    * */
    isSupervisor: Boolean = false,
    isSelectPatientScreen: Boolean,
    hasNotification: Boolean,
    onBackButtonPressed: () -> Unit = {},
    onLogoutButtonPressed: () -> Unit = {},
    onHelpButtonPressed: () -> Unit = {},
    onNotificationButtonPressed: () -> Unit = {}
) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.onPrimaryContainer,
            titleContentColor = MaterialTheme.colorScheme.onPrimary,
            navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
            actionIconContentColor = MaterialTheme.colorScheme.onSecondary
        ),
        title = {
            Text(title)
        },
        navigationIcon = {
            if (!isHomeScreen && !isSelectProfileScreen) {
                IconButton(
                    onClick = onBackButtonPressed,
                    modifier = Modifier
                        .size(70.dp)
                        .padding(horizontal = 6.dp)
                ) {
                    Icon(
                        imageVector= Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Go back",
                        modifier = Modifier
                            .size(48.dp)
                    )
                }

            }
        },
        actions = {

            if (
                (isSupervisor && isSelectPatientScreen)
                || (!isSupervisor && isHomeScreen)
                ) {

                if (hasNotification) {

                    IconButton(
                        onClick = onNotificationButtonPressed,
                        modifier = Modifier
                            .size(50.dp)
                            .padding(horizontal = 6.dp)

                    ) {

                        Icon(
                            painter = painterResource(id = R.drawable.notification_active),
                            contentDescription = "Notifications",
                            modifier = Modifier
                                .size(48.dp)
                        )
                    }
                }
                else {
                    IconButton(
                        onClick = onNotificationButtonPressed,
                        modifier = Modifier
                            .size(50.dp)
                            .padding(horizontal = 6.dp)
                    ) {

                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            modifier = Modifier
                                .size(48.dp)
                        )
                    }
                }
            }

            if (isHomeScreen) {

                IconButton(
                    onClick = onHelpButtonPressed,
                    modifier = Modifier
                        .size(50.dp)
                        .padding(horizontal = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Get help",
                        modifier = Modifier
                            .size(48.dp)
                    )

                }

                IconButton(
                    onClick = onLogoutButtonPressed,
                    modifier = Modifier
                        .size(50.dp)
                        .padding(horizontal = 6.dp)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.logout),
                        contentDescription = "Log out",
                        modifier = Modifier
                            .size(48.dp)
                    )

                }

            }

            if (isSelectPatientScreen) {
                IconButton(
                    onClick = onLogoutButtonPressed,
                    modifier = Modifier
                        .size(50.dp)
                        .padding(horizontal = 6.dp)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.logout),
                        contentDescription = "Log out",
                        modifier = Modifier
                            .size(48.dp)
                    )
                }

            }

        }
    )
}