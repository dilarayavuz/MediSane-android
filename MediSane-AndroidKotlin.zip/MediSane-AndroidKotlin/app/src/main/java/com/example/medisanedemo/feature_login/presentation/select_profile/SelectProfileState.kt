package com.example.medisanedemo.feature_login.presentation.select_profile

import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_login.domain.model.ProfileType
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState

data class SelectProfileState(
    val screenState: ScreenState = ScreenState.Loading,
    val accountId: Int = -1,
    val token: String = "",
    val isAddProfileDialogVisible: Boolean = false,
    val profileToAddName: String = "",
    val selectedIndex: Int = 0, // 0 is patient, 1 is supervisor
    val profileList: List<Profile> = listOf(),
    val groupedProfileList: Map<ProfileType, List<Profile>> = mapOf()
)

