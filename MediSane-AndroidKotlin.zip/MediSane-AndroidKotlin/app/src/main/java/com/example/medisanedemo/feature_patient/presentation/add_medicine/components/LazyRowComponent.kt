package com.example.medisanedemo.feature_patient.presentation.add_medicine.components

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_patient.presentation.add_medicine.AddMedicineState
import java.time.format.DateTimeFormatter

@Composable
fun LazyRowComponent(
    state: AddMedicineState,
    onTimeClick: (Int) -> Unit
) {
    val TAG = "LazyRowComponent"
    Log.d(TAG, "recomposed, hourList: " + state.hourOfDoseList)

    val iconPainter = painterResource(id = R.drawable.time)

    LazyRow(
        horizontalArrangement = Arrangement.Start
    ) {
        items(state.hourOfDoseList) {doseHour ->

            Log.d(TAG, "can see here, index: " + state.hourOfDoseList.indexOf(doseHour))
            val currentIndex = state.hourOfDoseList.indexOf(doseHour)
            Log.d(TAG, "might not see here")

            Column(
                modifier = Modifier
                    .padding(8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .clickable(
                        onClick = {
                            // state.pressedTimeIndex = currentIndex
                            // toggle TimePicker on
                            onTimeClick(currentIndex) }
                    )
            ) {
                Row(
                    modifier = Modifier
                        .padding(8.dp)
                        .padding(start = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        painter = iconPainter,
                        contentDescription = doseHour.format(DateTimeFormatter.ofPattern("HH:mm")))

                    Spacer(modifier = Modifier.width(20.dp))

                    Column(modifier = Modifier.padding(4.dp)) {
                        Text(
                            text = doseHour.format(DateTimeFormatter.ofPattern("HH:mm")),
                            style = TextStyle(
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                fontStyle = FontStyle.Normal,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    }

                }
            }


        }

    }
}