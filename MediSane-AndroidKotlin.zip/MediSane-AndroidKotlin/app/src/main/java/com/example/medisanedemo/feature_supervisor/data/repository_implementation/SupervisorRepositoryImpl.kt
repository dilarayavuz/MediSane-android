package com.example.medisanedemo.feature_supervisor.data.repository_implementation



import com.example.medisanedemo.feature_patient.domain.model.AwaitingRequestsDto
import com.example.medisanedemo.feature_patient.domain.model.ProfileRequestNotificationInfo
import com.example.medisanedemo.feature_supervisor.data.data_source.SupervisorApiService
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableProfilesToAddDto
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableSupervisionInfo
import com.example.medisanedemo.feature_supervisor.domain.model.PatientDto
import com.example.medisanedemo.feature_supervisor.domain.model.SuperviseRequestInfo
import com.example.medisanedemo.feature_supervisor.domain.model.SupervisorInfo
import com.example.medisanedemo.feature_supervisor.domain.repository_interface.ISupervisorRepository

class SupervisorRepositoryImpl (
    private val api: SupervisorApiService
): ISupervisorRepository {


    override suspend fun getPatients(supervisorInfo: SupervisorInfo): List<PatientDto> {

        val payload = api.getPatients(supervisorInfo)

        return payload
    }

    override suspend fun getPatientProfilesToAdd(availableSupervisionInfo: AvailableSupervisionInfo): AvailableProfilesToAddDto {
        val payload = api.getPatientProfilesToAdd(availableSupervisionInfo)

        return payload
    }

    override suspend fun sendSuperviseRequest(superviseRequestInfo: SuperviseRequestInfo): Int {
        val payload = api.sendSuperviseRequest(superviseRequestInfo)

        return payload
    }

    override suspend fun getSupervisionRequests(profileRequestNotificationInfo: ProfileRequestNotificationInfo): AwaitingRequestsDto {
        val payload = api.getSupervisionRequests(profileRequestNotificationInfo)

        return payload
    }
}