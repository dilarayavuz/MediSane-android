package com.example.medisanedemo.feature_patient.presentation.home

import android.util.Log
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_login.domain.model.ProfileType
import com.example.medisanedemo.feature_patient.domain.model.Medicine
import com.example.medisanedemo.feature_patient.domain.model.MedicineReport
import com.example.medisanedemo.feature_patient.domain.model.MedicineReportInfo
import com.example.medisanedemo.feature_patient.domain.model.SuperviseRequestDto
import com.example.medisanedemo.feature_patient.domain.use_case.PatientUseCases
import com.example.medisanedemo.feature_patient.presentation.home.components.Label
import com.example.medisanedemo.feature_patient.presentation.util.PatientUiUtils.convertMedicineDtoList
import com.example.medisanedemo.feature_patient.presentation.util.PatientUiUtils.convertMedicineReportDtoList
import com.example.medisanedemo.feature_patient.presentation.util.PatientUiUtils.getMedicinesOfDay
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException
import java.time.LocalDateTime
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val patientUseCases: PatientUseCases,
    savedStateHandle: SavedStateHandle
): ViewModel() {

    val TAG = "HomeViewModel"



    private val _state = mutableStateOf(HomeState())
    val state: State<HomeState> = _state

    private val responseEventChannel = Channel<ResponseEvent>() // channel with only one observer
    val responseEvents = responseEventChannel.receiveAsFlow() // receiveAsFlow returns an immutable flow, will be observed by the ui


    init {
        val accountId = savedStateHandle.get<Int>("accountId")!!
        val profileId = savedStateHandle.get<Int>("profileId")!!
        val profileName = savedStateHandle.get<String>("profileName")!!
        val token = savedStateHandle.get<String>("token")!!
        val isSupervisor = savedStateHandle.get<Boolean>("isSupervisor")!!

        _state.value = state.value.copy(
            profile = Profile(
                profileId = profileId,
                profileName = profileName,
                type = ProfileType.PATIENT
            ),
            accountId = accountId,
            isSupervisor = isSupervisor,
            token = token

        )

        setHomeContent()

        setSelectedDateTime()

    }

    private fun setSelectedDateTime() {
        val selectedTime = state.value.selectedDate


        val alteredSelectedDate = LocalDateTime.of(
            selectedTime.year,
            selectedTime.month,
            selectedTime.dayOfMonth,
            23,
            59
        )

        _state.value = state.value.copy(
            selectedDate = alteredSelectedDate
        )
    }

    private fun setHomeContent() {
        viewModelScope.launch {

            try {
                val medicineListPayload = patientUseCases.getAllMedicines.invoke(
                    token = state.value.token,
                    profileId = state.value.profile.profileId
                )
                val medicineList = convertMedicineDtoList(medicineListPayload.medicineList)


                val medicineReportPayload = patientUseCases.getMedicineReport.invoke(
                    token = state.value.token,
                    profileId = state.value.profile.profileId
                )

                val medicineReportList = convertMedicineReportDtoList(medicineReportPayload.medicineReportList, medicineList)

                val awaitingRequests: List<SuperviseRequestDto> =
                    if (state.value.isSupervisor) {
                        listOf()
                    } else {
                        patientUseCases.getSupervisionRequests.invoke(
                            token = state.value.token,
                            profileId = state.value.profile.profileId
                        ).awaitingRequests
                    }


                _state.value = state.value.copy(
                    medicineList = medicineList,
                    medicineReportList = medicineReportList,
                    medicinesOfDay = getMedicinesOfDay(medicineList, state.value.selectedDate),
                    screenState = ScreenState.Success,
                    hasNotification = awaitingRequests.isNotEmpty()
                )
            } catch (e: IOException) {

                _state.value = state.value.copy(
                    screenState = ScreenState.Error(message = "Internet Connection Failed")
                )

            } catch (e: HttpException) {

                _state.value = state.value.copy(
                    screenState = ScreenState.Error(message = e.message())
                )

            }
        }
    }

    fun onEvent(event: HomeUiEvent) {
        when (event) {
            is HomeUiEvent.GoToProfiles -> {

                viewModelScope.launch{


                    if (!state.value.isSupervisor){ // if not a supervisor, go to selectProfiles screen
                        responseEventChannel.send(
                            ResponseEvent.GoToProfilesFromHome(
                                accountId = state.value.accountId
                            )
                        )
                    }
                    else { // if a supervisor, go to selectPatients screen

                        responseEventChannel.send(
                            ResponseEvent.GoToProfilesFromHome(
                                accountId = state.value.accountId
                            )
                        )

                    }
                }

            }

            is HomeUiEvent.SetDayOfMonth -> {
                val selectedDate = LocalDateTime.of(
                    state.value.selectedDate.year,
                    state.value.selectedDate.month,
                    event.dayOfMonth,
                    state.value.selectedDate.hour,
                    state.value.selectedDate.minute
                )

                _state.value = state.value.copy(
                    selectedDate = selectedDate,
                    medicinesOfDay = getMedicinesOfDay(state.value.medicineList, selectedDate),
                )
            }

            is HomeUiEvent.GoToMyMedicines -> {

                viewModelScope.launch{
                    responseEventChannel.send(
                        ResponseEvent.GoToMyMedicinesFromHome(
                            profileId = event.profileId
                        )
                    )
                }
            }

            is HomeUiEvent.GoToNotifications -> {

                _state.value = state.value.copy(
                    hasNotification = false
                )

                viewModelScope.launch{
                    responseEventChannel.send(
                        ResponseEvent.GoToNoticationsFromHome(
                            profileId = event.profileId
                        )
                    )
                }
            }

            HomeUiEvent.SetPreviousMonth -> {

                val previousMonth = if (state.value.selectedDate.month.value > 1) {
                    state.value.selectedDate.month.value - 1
                } else {
                    12
                }
                val previousMonthYear = if (state.value.selectedDate.month.value > 1) {
                    state.value.selectedDate.year
                } else {
                    state.value.selectedDate.year - 1
                }

                val selectedDate = LocalDateTime.of(
                    previousMonthYear,
                    previousMonth,
                    1,
                    state.value.selectedDate.hour,
                    state.value.selectedDate.minute
                )

                _state.value = state.value.copy(
                    selectedDate = selectedDate,
                    medicinesOfDay = getMedicinesOfDay(state.value.medicineList, selectedDate),
                )

                viewModelScope.launch {
                    state.value.rowState.scrollToItem(state.value.selectedDate.dayOfMonth - 1)
                }
            }

            HomeUiEvent.SetNextMonth -> {

                val nextMonth = if (state.value.selectedDate.month.value < 12) {
                    state.value.selectedDate.month.value + 1
                } else {
                    1
                }
                val nextMonthYear = if (state.value.selectedDate.month.value < 12) {
                    state.value.selectedDate.year
                } else {
                    state.value.selectedDate.year + 1
                }

                val selectedDate = LocalDateTime.of(
                    nextMonthYear,
                    nextMonth,
                    1,
                    state.value.selectedDate.hour,
                    state.value.selectedDate.minute
                )

                _state.value = state.value.copy(
                    selectedDate = selectedDate,
                    medicinesOfDay = getMedicinesOfDay(state.value.medicineList, selectedDate),
                )

                viewModelScope.launch {
                    state.value.rowState.scrollToItem(state.value.selectedDate.dayOfMonth - 1)
                }


            }

            HomeUiEvent.Retry -> {
                _state.value = state.value.copy(
                    screenState = ScreenState.Loading
                )
                setHomeContent()
            }

            is HomeUiEvent.SetMedicineReport -> {
                /* 1. update medicineReportList:
                *       - if medicineReport exists, update it
                *       - else, add it
                * */
                var isUpdate = false
                var toBeUpdatedIndex = -1
                for ((index: Int, medicineReport: MedicineReport) in state.value.medicineReportList.withIndex()) {
                    if (
                        (medicineReport.medicine.name == event.medicine.name) &&
                        (medicineReport.hourOfDose.isEqual(event.hourOfDose))
                        ) {

                        isUpdate = true
                        toBeUpdatedIndex = index
                        break

                    }
                }

                if (isUpdate) {
                    updateMedicineReportList(toBeUpdatedIndex, event.label)
                }
                else {
                    addToMedicineReportList(event.medicine, event.hourOfDose, event.label)
                }

                /* 2. send query to backend
                * */
                viewModelScope.launch {

                    try {
                        val reportPayload = MedicineReportInfo(
                            token = state.value.token,
                            profileId = state.value.profile.profileId,
                            medicineName = event.medicine.name,
                            label = event.label == Label.TAKEN,
                            hourOfDose = event.hourOfDose.toString(),
                            isUpdate = isUpdate
                        )

                        Log.d(TAG, "medicineReport: $reportPayload")
                        patientUseCases.addMedicineReport.invoke(
                            reportPayload
                        )
                    } catch (e: IOException) {

                        _state.value = state.value.copy(
                            screenState = ScreenState.Error(message = "Internet Connection Failed")
                        )

                    } catch (e: HttpException) {

                        _state.value = state.value.copy(
                            screenState = ScreenState.Error(message = e.message())
                        )

                    }
                }


            }

            is HomeUiEvent.ResetMedicineReport -> {
                /* update medicineReportList:
                *       - if medicineReport exists, update it
                *       - else, add it
                *  do not update the backend
                * */
                var reportIndex = -1
                for ((index: Int, medicineReport: MedicineReport) in state.value.medicineReportList.withIndex()) {
                    if (
                        (medicineReport.medicine == event.medicineReport.medicine) &&
                        (medicineReport.hourOfDose == event.medicineReport.hourOfDose) &&
                        (medicineReport.label == event.medicineReport.label)
                        ) {

                        reportIndex = index
                    }
                }

                updateMedicineReportList(reportIndex, Label.UNLABELED)
            }
        }
    }

    private fun addToMedicineReportList(medicine: Medicine, hourOfDose: LocalDateTime, label: Label) {
        val newReportList = state.value.medicineReportList.toMutableList()
        newReportList.add(
            MedicineReport(
                profileId = state.value.profile.profileId,
                hourOfDose = hourOfDose,
                medicine = medicine,
                label = label
            )
        )

        _state.value = state.value.copy(
            medicineReportList = newReportList.toList()
        )
    }

    private fun updateMedicineReportList(toBeUpdatedIndex: Int, label: Label) {
        val newReportList = mutableListOf<MedicineReport>()

        state.value.medicineReportList.forEachIndexed { index: Int, medicineReport: MedicineReport ->
            if (index == toBeUpdatedIndex) {
                newReportList.add(
                    MedicineReport(
                        profileId = medicineReport.profileId,
                        hourOfDose = medicineReport.hourOfDose,
                        medicine = medicineReport.medicine,
                        label = label
                    )
                )
            } else {
                newReportList.add(medicineReport)
            }
        }

        _state.value = state.value.copy(
            medicineReportList = newReportList.toList()
        )
    }

    /* one time events that ViewModel sends, and the UI reads
    * we do not want to hold onto these events unlike states that are persistent
    */
    sealed class ResponseEvent {
        data class GoToProfilesFromHome(val accountId: Int): ResponseEvent()
        data class GoToMyMedicinesFromHome(val profileId: Int): ResponseEvent()
        data class GoToNoticationsFromHome(val profileId: Int): ResponseEvent()

        object GoToSelectPatientsFromHome: ResponseEvent()

    }
}