package com.example.medisanedemo.feature_login.presentation.select_profile

import com.example.medisanedemo.feature_login.domain.model.Profile

sealed class SelectProfileScreenUIEvent{

    data class GoToProfile(val profile: Profile): SelectProfileScreenUIEvent()

    data class DeleteProfile(val profile: Profile): SelectProfileScreenUIEvent()
    data class ToggleAddProfileDialog(val isVisible: Boolean): SelectProfileScreenUIEvent()
    data class SetProfileToAddName(val profileName: String): SelectProfileScreenUIEvent()
    data class PressedOnSegmentedButton(val index: Int): SelectProfileScreenUIEvent()
    data class NewTokenAcquired(val token: String): SelectProfileScreenUIEvent()

    object AddProfile: SelectProfileScreenUIEvent()
    object Retry: SelectProfileScreenUIEvent()

}
