package com.example.medisanedemo.feature_login.domain.use_case

import com.example.medisanedemo.feature_login.domain.model.ProfileToDeleteInfo
import com.example.medisanedemo.feature_login.domain.repository_interface.ILoginRepository
import javax.inject.Inject

class DeleteProfileUseCase @Inject constructor(
    private val repository: ILoginRepository
) {

    suspend operator fun invoke(profileToDeleteInfo: ProfileToDeleteInfo): String {
        val new_token = repository.removeProfile(profileToDeleteInfo)

        return new_token.token
    }
}