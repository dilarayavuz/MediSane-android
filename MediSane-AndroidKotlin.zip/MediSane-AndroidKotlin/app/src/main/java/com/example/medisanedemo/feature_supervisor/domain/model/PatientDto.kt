package com.example.medisanedemo.feature_supervisor.domain.model

import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_login.domain.model.ProfileType

data class PatientDto(
    val profileId: Int,
    val profileName: String
)

fun PatientDto.toProfile(): Profile {
    return Profile(
        profileId = this.profileId,
        profileName = this.profileName,
        type = ProfileType.PATIENT
    )
}
