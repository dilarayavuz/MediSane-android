package com.example.medisanedemo.feature_patient.presentation.my_medicines

import com.example.medisanedemo.feature_patient.domain.model.Medicine
import com.example.medisanedemo.feature_patient.domain.model.MedicineReport
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState

data class MyMedicinesState(
    val accountId: Int = 0,
    val profileName: String = "",

    val token: String = "",
    val screenState: ScreenState = ScreenState.Loading,
    val profileId: Int = 0,
    val isSupervisor: Boolean = false,
    val isMedicineInfoDialogVisible: Boolean = false,
    val medicineList: List<Medicine> = listOf(),
    val medicineInfoList: List<Medicine> = listOf(),
    val medicineReportList: List<MedicineReport> = listOf(),
    val clashList: List<Triple<Medicine, Medicine, String>> = listOf(),
    val selectedButtonIndex: Int = 0
)

