package com.example.medisanedemo.feature_patient.presentation.add_medicine.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.feature_patient.presentation.home.components.getWeekName
import com.example.medisanedemo.ui.theme.MyTheme

/*
* selectedWeekDaysList = weekdays as integer
* is pressed on not focused box, add it to selectedWeekDaysList
* if pressed on focused box, remove it from selectedWeekDaysList
*
* all selected week days are stored as integers until submission
* when user presses submit button, inside viewModel.onEvent()
*       - for all selected weekdays, find a LocalDateTime that is either equal to the startDateList[0], or comes after it. add that LocalDateTime to startDateList
*       - sort startDateList
*       - if startDateList[0] == startDateList[1], remove one of them. else, remove startDateList[0]. I.E. remove startDateList[0] regardless!
*       - submit startDateList[0]
*
* */
@Composable
fun SelectWeekDaysComponent(
    onDaySelect: (Int) -> Unit,
    selectedWeekDaysList: List<Int>
) {

    val weekDayList = (1..7).toList()

    LazyRow {

        items(weekDayList) {weekDay: Int ->

            DayOfWeekBox(
                weekDay = weekDay,
                isFocused = selectedWeekDaysList.contains(weekDay),
                onClick = { onDaySelect(weekDay) }
            )

        }

    }


}

@Composable
fun DayOfWeekBox(
    weekDay: Int,
    isFocused: Boolean,
    onClick: (Int) -> Unit
) {

    Card(
        modifier = Modifier
            .wrapContentSize()
            .padding(4.dp)
            .clip(RoundedCornerShape(8.dp))
            .fillMaxWidth()
            .clickable(
                onClick = {
                    onClick(weekDay.toInt())
                }
            ),
        colors = if (isFocused) {
            CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
            )
        } else {
            CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.background,
                contentColor = MaterialTheme.colorScheme.onBackground
            )
        },
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isFocused) {
                8.dp
            } else {
                0.dp
            }
        ),
        border = if (isFocused) {
            null
        } else {
            BorderStroke(1.dp, MaterialTheme.colorScheme.onBackground)
               },
    ) {

        Column(
            modifier = Modifier
                .width(60.dp)
                .height(60.dp)
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            Text(
                text = getWeekName(weekDay),
                modifier = Modifier.align(Alignment.CenterHorizontally),
                style = MaterialTheme.typography.bodyMedium,
            )

        }

    }

}


@Preview(showBackground = true)
@Composable
fun SelectDaysComponentPrev() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){

            SelectWeekDaysComponent(
                onDaySelect = {},
                selectedWeekDaysList = listOf()
            )

        }

    }
}
