package com.example.medisanedemo.feature_login.domain.use_case

import com.example.medisanedemo.feature_login.domain.model.Account
import com.example.medisanedemo.feature_login.domain.model.InvalidUserException
import com.example.medisanedemo.feature_login.domain.model.LoginInfo
import com.example.medisanedemo.feature_login.domain.repository_interface.ILoginRepository
import javax.inject.Inject

class SignUserUpUseCase @Inject constructor(
    private val repository: ILoginRepository
)  {

    /*
    * allows us to call this class as a function
    * */
    @Throws (InvalidUserException::class)
    suspend operator fun invoke(pwd: String, username: String): Int {

        if (pwd.isBlank()) {
            throw InvalidUserException(
                message = "The password cannot remain empty."
            )
        }
        if (username.isBlank()) {
            throw InvalidUserException(
                message = "The username cannot remain empty."
            )
        }

        val result = repository.signUp(
            LoginInfo(
                username = username,
                password = pwd
            )
        )

        if (result == -1) {
            throw InvalidUserException(
                message = "Invalid username/password combination, please try a different combination."
            )
        }

        return result


    }
}