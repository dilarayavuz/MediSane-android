package com.example.medisanedemo.feature_supervisor.presentation.patient_list

import androidx.compose.material3.SnackbarHostState
import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_login.domain.model.profileDefault
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState
import com.example.medisanedemo.feature_supervisor.domain.model.ProfileToAddDto

data class SelectPatientState(
    val screenState: ScreenState = ScreenState.Loading,
    val profile: Profile = profileDefault(),
    val token: String = "",
    val accountId: Int = -1,
    val patientProfileList: List<Profile> = listOf(), // list of patient profiles


    val isAddPatientDialogVisible: Boolean = false,
    val patientToAddName: String = "",

    val profilesToAddList: List<ProfileToAddDto> = listOf(),
    val isAddPatientError: Boolean = false,
    val addPatientErrorMessage: String = "",
    val snackbarHostState: SnackbarHostState = SnackbarHostState(),

    val hasNotification: Boolean = false,
    val isFirstCall: Boolean = true,
)
