package com.example.medisanedemo.feature_login.domain.model

data class UserAccount( //primary key accountId
    val accountId: Int,
    val isSupervisor: Boolean = false,
    val userProfiles: List<Profile>
)

/*
* thrown when user tries to login with invalid credentials
* */

class InvalidUserException(message: String): Exception(message)
