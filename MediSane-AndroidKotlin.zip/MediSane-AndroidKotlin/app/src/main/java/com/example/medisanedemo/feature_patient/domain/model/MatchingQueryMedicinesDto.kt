package com.example.medisanedemo.feature_patient.domain.model

import com.google.gson.annotations.SerializedName

data class MatchingQueryMedicinesDto(
    @SerializedName("medicine_list")
    val medList: List<String>
)
