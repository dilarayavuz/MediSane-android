package com.example.medisanedemo.feature_login.domain.model

import com.google.gson.annotations.SerializedName

data class AccountInfo(
    @SerializedName("account_id")
    val accountId: Int,
    val token: String
)
