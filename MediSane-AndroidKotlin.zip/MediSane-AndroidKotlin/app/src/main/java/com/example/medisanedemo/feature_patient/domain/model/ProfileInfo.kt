package com.example.medisanedemo.feature_patient.domain.model

import com.google.gson.annotations.SerializedName

data class ProfileInfo(
    @SerializedName("patient_id")
    val profileId: Int,
    val token: String
)
