package com.example.medisanedemo.feature_patient.presentation.add_medicine.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.presentation.login.components.TextFieldComponent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.AddMedicineState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExposedDropdownMenuComponent(
    isExpanded: Boolean,
    textFieldValue: String,
    placeHolderVal: String,
    onExpandedStateChange: (Boolean) -> Unit,
    onDismissRequest: () -> Unit,
    onSelectedValueChange: (Int) -> Unit
) {

    ExposedDropdownMenuBox(
        expanded = isExpanded,
        onExpandedChange = onExpandedStateChange
    ) {

        OutlinedTextField(
            value = textFieldValue,
            modifier = Modifier
                .menuAnchor()
                .padding(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                focusedLabelColor = MaterialTheme.colorScheme.primary,
                cursorColor = MaterialTheme.colorScheme.primary,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface
            ),
            readOnly = true,
            placeholder = {
                placeHolderVal //stringResource(id = R.string.select_dose_amount)

            },
            trailingIcon = {
                ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
            },
            onValueChange = {}
        )

        ExposedDropdownMenu(
            expanded = isExpanded,
            onDismissRequest = onDismissRequest
        ) {
            DropdownMenuItem(
                text = {
                       Text(text = "1")
                },
                onClick = {
                    onSelectedValueChange(1)
                }
            )
            DropdownMenuItem(
                text = {
                    Text(text = "2")
                },
                onClick = {
                    onSelectedValueChange(2)
                }
            )
            DropdownMenuItem(
                text = {
                    Text(text = "3")
                },
                onClick = {
                    onSelectedValueChange(3)
                }
            )
            DropdownMenuItem(
                text = {
                    Text(text = "4")
                },
                onClick = {
                    onSelectedValueChange(4)
                }
            )

        }

    }
}