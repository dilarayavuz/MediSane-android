package com.example.medisanedemo.feature_login.presentation.signup

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.medisanedemo.feature_login.domain.model.Account
import com.example.medisanedemo.feature_login.domain.model.InvalidUserException
import com.example.medisanedemo.feature_login.domain.use_case.LoginUseCases
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject

@HiltViewModel
class SignupViewModel @Inject constructor(
    private val loginUseCases: LoginUseCases
): ViewModel() {

    private val _state = mutableStateOf(SignupState())
    val state: State<SignupState> = _state

    private val responseEventChannel = Channel<ResponseEvent>() // channel with only one observer
    val responseEvents = responseEventChannel.receiveAsFlow() // receiveAsFlow returns an immutable flow, will be observed by the ui


    fun onEvent(event: SignupUIEvent) {
        when (event) {
            is SignupUIEvent.SetUsername -> {
                _state.value = state.value.copy(
                    username = event.username
                )
            }
            is SignupUIEvent.SetPassword -> {
                _state.value = state.value.copy(
                    password = event.password
                )
            }
            is SignupUIEvent.TogglePasswordVisibility -> {
                _state.value = state.value.copy(
                    isPasswordVisible = !state.value.isPasswordVisible
                )
            }
            is SignupUIEvent.SignupButtonPressed -> {

                viewModelScope.launch {
                    try {

                        val result = loginUseCases.signUserUp.invoke(
                            pwd = state.value.password,
                            username = state.value.username
                        )

                        if (result == 1) {
                            responseEventChannel.send(ResponseEvent.GoToLoginFromSignup)
                        }

                    } catch (e: InvalidUserException){

                        _state.value = state.value.copy(
                            errorMessage = e.message ?: "Signup Failed",
                            isError = true
                        )

                    } catch(e: IOException) {

                        _state.value = state.value.copy(
                            errorMessage = "Internet Connection Failed, Please Check Your Internet Connection",
                            isError = true
                        )

                    } catch (e: HttpException) {

                        _state.value = state.value.copy(
                            errorMessage = e.message(),
                            isError = true
                        )

                    }
                }
            }
        }

    }
}

/* one time events that ViewModel sends, and the UI reads
   * we do not want to hold onto these events unlike states that are persistent
   */
sealed class ResponseEvent {
    data class GoToProfilesFromSignup(val account: Account): ResponseEvent() // if we decide to go to log user in
    object GoToLoginFromSignup: ResponseEvent() // if we decide not to log user in
}