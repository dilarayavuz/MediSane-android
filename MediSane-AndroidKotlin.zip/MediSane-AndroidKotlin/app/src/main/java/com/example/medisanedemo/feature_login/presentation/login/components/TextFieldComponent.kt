package com.example.medisanedemo.feature_login.presentation.login.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent


@Composable
fun TextFieldComponent(labelValue: String,
                       imageVector: ImageVector,
                       onValueChange: (String) -> Unit,
                       isError: Boolean = false,
                       textValue: String,
                       contentDescription: String
) {

    OutlinedTextField(
        modifier = Modifier
            .fillMaxWidth()
            .onKeyEvent { event: KeyEvent ->
                if (event.key == Key.Enter){
                    /* do nothing */
                    true
                }
                false
            },
        value = textValue,
        isError = isError,
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            focusedLabelColor = MaterialTheme.colorScheme.primary,
            cursorColor = MaterialTheme.colorScheme.primary,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface
        ),
        onValueChange = {
            onValueChange(it)
                        },
        label = { Text(text = labelValue) },
        keyboardOptions = KeyboardOptions.Default,
        leadingIcon = { Icon(imageVector = imageVector, contentDescription = contentDescription)}
    )

}