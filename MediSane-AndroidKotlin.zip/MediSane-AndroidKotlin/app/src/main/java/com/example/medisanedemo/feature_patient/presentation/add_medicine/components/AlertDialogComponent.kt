package com.example.medisanedemo.feature_patient.presentation.add_medicine.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.presentation.login.components.HeadlineTextComponent
import com.example.medisanedemo.feature_login.presentation.login.components.NormalTextComponent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.AddMedicineState
import com.example.medisanedemo.feature_patient.presentation.add_medicine.additional_options_screen.AdditionalOptionsScreen
import com.example.medisanedemo.ui.theme.MyTheme
import kotlinx.coroutines.flow.flowOf

@Composable
fun AlertDialogComponent(
    onDismissRequest: () -> Unit,
    dialogTitle: String,
    dialogText: String,
    icon: ImageVector,
) {
    AlertDialog(
        icon = {
            Icon(icon, contentDescription = "Example Icon")
        },
        title = {
            HeadlineTextComponent(
                value = dialogTitle
            )
        },
        text = {
            NormalTextComponent(
                value = dialogText
            )
        },
        onDismissRequest = onDismissRequest,
        confirmButton = {
            TextButton(
                onClick = onDismissRequest
            ) {
                Text(stringResource(id = R.string.dismiss))
            }
        }
    )
}



@Preview(showBackground = true)
@Composable
fun AlertDialogPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){
            AlertDialogComponent(
                onDismissRequest = {},
                dialogTitle = "Alert alert!",
                dialogText = "DJ Crazy Times",
                icon = Icons.Outlined.Warning
            )
        }

    }
}