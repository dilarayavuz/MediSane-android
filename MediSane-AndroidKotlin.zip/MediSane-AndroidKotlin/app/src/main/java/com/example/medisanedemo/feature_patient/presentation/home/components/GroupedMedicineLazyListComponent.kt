package com.example.medisanedemo.feature_patient.presentation.home.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_patient.domain.model.Medicine
import com.example.medisanedemo.feature_patient.domain.model.MedicineReport
import java.time.LocalDateTime

@Composable
fun GroupedMedicineLazyListComponent(
    groupedMedicineList: Map<Boolean, List<Medicine>>,
    medicineReportList: List<MedicineReport>,
    onClickLabeledReport: (Medicine, LocalDateTime, Label) -> Unit,
    onClickUnlabeledReport: (MedicineReport) -> Unit,
    selectedDate: LocalDateTime
) {

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Top
    ) {


        if (groupedMedicineList.isNotEmpty()){
            if (groupedMedicineList.get(key = false) != null) {

                items(groupedMedicineList.get(key = false)!!) { medicine: Medicine ->

                    val medicineName = medicine.name
                    val medicineIconPainter = painterResource(id = R.drawable.medication)


                    var label = Label.UNLABELED
                    var selectedMedicineReport = if (medicineReportList.isNotEmpty()) {
                        medicineReportList[0]
                    } else {
                        null
                    }
                    /* doing a hour-by-hour and minute-by-minute comparison cuz in backend,
                     * medicineReport hourOfDose's post minute parts are truncated
                     * which might result in a potential error
                     * */
                    for (medicineReport in medicineReportList) {
                        if (
                            (medicineReport.medicine.name == medicineName) && // names hit
                            (!medicineReport.hourOfDose.isBefore(medicine.startDate)) && // at start date or after
                            (medicineReport.hourOfDose.year == selectedDate.year) && // at selected date
                            (medicineReport.hourOfDose.month == selectedDate.month) && // at selected date
                            (medicineReport.hourOfDose.dayOfMonth == selectedDate.dayOfMonth) && // at selected date
                            (medicineReport.hourOfDose.hour == medicine.startDate.hour) &&
                            (medicineReport.hourOfDose.minute == medicine.startDate.minute)
                        ) {
                            label = medicineReport.label
                            selectedMedicineReport = medicineReport
                            break
                        }
                    }
                    PastMedicineColumnComponent(
                        medicineName = medicineName,
                        medicineIconPainter = medicineIconPainter,
                        medicineStartDate = medicine.startDate,
                        label = label,
                        onClickUnlabeledToTaken = {
                            onClickLabeledReport(
                                medicine,
                                LocalDateTime.of(
                                    selectedDate.year,
                                    selectedDate.month,
                                    selectedDate.dayOfMonth,
                                    medicine.startDate.hour,
                                    medicine.startDate.minute
                                ),
                                Label.TAKEN
                            )
                        },
                        onClickUnlabeledToMissed = {
                            onClickLabeledReport(
                                medicine,
                                LocalDateTime.of(
                                    selectedDate.year,
                                    selectedDate.month,
                                    selectedDate.dayOfMonth,
                                    medicine.startDate.hour,
                                    medicine.startDate.minute
                                ),
                                Label.MISSED
                            )
                        },
                        onClickLabeledToUnlabeled = {
                            onClickUnlabeledReport(
                                selectedMedicineReport!!
                            )
                        }
                    )


                }
            }

            if (groupedMedicineList.isNotEmpty() && groupedMedicineList.get(key = true) != null) {

                items(groupedMedicineList.get(key = true)!!) { medicine: Medicine ->

                    val medicineName = medicine.name
                    val medicineIconPainter = painterResource(id = R.drawable.medication)

                    FutureMedicineColumnComponent(
                        medicineName = medicineName,
                        medicineIconPainter = medicineIconPainter,
                        medicineStartDate = medicine.startDate
                    )

                }
            }
        }
    }

}