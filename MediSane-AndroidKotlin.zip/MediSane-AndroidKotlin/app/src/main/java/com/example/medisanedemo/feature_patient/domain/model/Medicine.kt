package com.example.medisanedemo.feature_patient.domain.model

import java.time.LocalDateTime


/*
* class that represents medicines
* data came from the api should be converted to this
*
* */
data class Medicine( // primary key: name
    val name: String,
    val frequency: Int,
    val startDate: LocalDateTime,

    val remainingAmount: Int,
    val hasNotification: Boolean,
    val doseAmount: Int,
    val usageDescription: String,
    val endDate: LocalDateTime, // if endDate is null, endDate: LocalDateTime is startDate: LocalDateTime + 1 year
    val isEndDateNull: Boolean // if endDate is null, isEndDateNull: Boolean is true
)


