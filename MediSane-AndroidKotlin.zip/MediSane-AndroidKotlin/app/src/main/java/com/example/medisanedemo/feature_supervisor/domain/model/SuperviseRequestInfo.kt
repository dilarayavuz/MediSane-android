package com.example.medisanedemo.feature_supervisor.domain.model

import com.google.gson.annotations.SerializedName

data class SuperviseRequestInfo(
    val token: String,
    @SerializedName("supervisor_id")
    val supervisorId: Int,
    @SerializedName("patient_id")
    val patientId: Int,
    @SerializedName("sent_by")
    val sentBy: Boolean, // true --> supervisor
)
