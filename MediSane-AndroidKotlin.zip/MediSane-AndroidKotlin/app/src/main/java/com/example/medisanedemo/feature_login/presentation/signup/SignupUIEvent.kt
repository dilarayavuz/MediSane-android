package com.example.medisanedemo.feature_login.presentation.signup

sealed class SignupUIEvent {

    data class SetUsername(val username: String): SignupUIEvent()
    data class SetPassword(val password: String): SignupUIEvent()

    object TogglePasswordVisibility: SignupUIEvent()
    object SignupButtonPressed: SignupUIEvent()
}
