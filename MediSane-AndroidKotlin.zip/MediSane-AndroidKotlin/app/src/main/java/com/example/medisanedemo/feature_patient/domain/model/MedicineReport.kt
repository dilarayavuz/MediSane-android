package com.example.medisanedemo.feature_patient.domain.model

import com.example.medisanedemo.feature_patient.presentation.home.components.Label
import java.time.LocalDateTime

data class MedicineReport(
    val profileId: Int,
    val label: Label,
    val hourOfDose: LocalDateTime,
    val medicine: Medicine
)
