package com.example.medisanedemo.feature_patient.presentation.my_medicines.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_patient.domain.model.Medicine
import com.example.medisanedemo.feature_patient.domain.model.MedicineReport
import com.example.medisanedemo.feature_patient.presentation.home.components.Label
import com.example.medisanedemo.ui.theme.MyTheme
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun LazyMedicineReportColumnComponent(
    medicineReportList: List<MedicineReport>,
) {

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Top
    ) {
        items(medicineReportList) {medicineReport: MedicineReport ->


            val containerColor: Color = if (medicineReport.label == Label.TAKEN) {
                MaterialTheme.colorScheme.secondaryContainer
            } else {
                MaterialTheme.colorScheme.errorContainer
            }

            Column(
                modifier = Modifier
                    .padding(8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .fillMaxWidth()
            ) {

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .padding(start = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {

                    Icon(
                        painter = painterResource(id = R.drawable.report),
                        contentDescription = medicineReport.medicine.name + " report",
                        modifier = Modifier.size(36.dp)
                    )

                    Spacer(modifier = Modifier.width(20.dp))

                    Column(
                        modifier = Modifier
                            .padding(4.dp)
                            .size(width = 160.dp, height = 86.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = medicineReport.medicine.name,
                            style = TextStyle(
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                fontStyle = FontStyle.Normal,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = medicineReport.hourOfDose.toLocalDate().format(DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.ENGLISH)),
                            style = TextStyle(
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Normal,
                                fontStyle = FontStyle.Normal,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = medicineReport.hourOfDose.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm")),
                            style = TextStyle(
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Normal,
                                fontStyle = FontStyle.Normal,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )

                    }
                    Column (
                        modifier = Modifier
                            .padding(4.dp)
                    ) {
                        if (medicineReport.label == Label.TAKEN) {

                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Medicine Taken",
                                modifier = Modifier
                                    .size(32.dp)
                            )
                        }
                        else {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Medicine Missed",
                                modifier = Modifier
                                    .size(32.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}



@Preview
@Composable
fun LazyMedicineReportColumnPrev() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){

            LazyMedicineReportColumnComponent(
                medicineReportList = listOf(
                    MedicineReport(
                        medicine = Medicine(
                            name= "agubugu",
                            frequency = 1,
                            startDate = LocalDateTime.now(),
                            remainingAmount = 1,
                            doseAmount = 1,
                            endDate = LocalDateTime.now().plusYears(1),
                            hasNotification = false,
                            usageDescription = "",
                            isEndDateNull = true,
                        ),
                        profileId = 1,
                        label = Label.TAKEN,
                        hourOfDose = LocalDateTime.now(),
                    ),
                    MedicineReport(
                        medicine = Medicine(
                            name= "Ahumentin",
                            frequency = 2,
                            startDate = LocalDateTime.now(),
                            remainingAmount = 1,
                            doseAmount = 1,
                            endDate = LocalDateTime.now().plusYears(1),
                            hasNotification = false,
                            usageDescription = "",
                            isEndDateNull = true,
                        ),
                        profileId = 1,
                        label = Label.MISSED,
                        hourOfDose = LocalDateTime.now(),
                    )

                )
            )

        }
    }
}