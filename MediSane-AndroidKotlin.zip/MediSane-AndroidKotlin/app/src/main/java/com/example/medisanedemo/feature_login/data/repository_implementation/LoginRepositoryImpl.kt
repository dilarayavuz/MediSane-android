package com.example.medisanedemo.feature_login.data.repository_implementation

import com.example.medisanedemo.feature_login.data.data_source.LoginApiService
import com.example.medisanedemo.feature_login.domain.model.Account
import com.example.medisanedemo.feature_login.domain.model.AccountInfo
import com.example.medisanedemo.feature_login.domain.model.LoginInfo
import com.example.medisanedemo.feature_login.domain.model.ProfileDto
import com.example.medisanedemo.feature_login.domain.model.ProfileToAddInfo
import com.example.medisanedemo.feature_login.domain.model.ProfileToDeleteInfo
import com.example.medisanedemo.feature_login.domain.model.TokenDto
import com.example.medisanedemo.feature_login.domain.model.toAccount
import com.example.medisanedemo.feature_login.domain.repository_interface.ILoginRepository

class LoginRepositoryImpl(
    private val api: LoginApiService
): ILoginRepository {


    override suspend fun getUserAccount(pwd: String, username: String): Account {

        val loginInfo = LoginInfo(username=username, password=pwd)
        //val TAG = "LoginRepositoryImpl" //DEBUG
        val account = api.getUserAccount(loginInfo)


        return account.toAccount()
    }

    override suspend fun getAllProfiles(accountInfo: AccountInfo): List<ProfileDto> {

        val profileList = api.getAllProfiles(accountInfo)


        return profileList
    }

    override suspend fun signUp(loginInfo: LoginInfo): Int {

        return api.signUp(loginInfo)
    }

    override suspend fun addNewProfile(profileToAddInfo: ProfileToAddInfo): TokenDto {
        return api.addNewProfile(profileToAddInfo)
    }

    override suspend fun removeProfile(profileToDeleteInfo: ProfileToDeleteInfo): TokenDto {
        return api.removeProfile(profileToDeleteInfo)
    }

}