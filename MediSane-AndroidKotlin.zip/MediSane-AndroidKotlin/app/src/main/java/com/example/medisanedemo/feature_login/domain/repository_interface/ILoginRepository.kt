package com.example.medisanedemo.feature_login.domain.repository_interface

import com.example.medisanedemo.feature_login.domain.model.Account
import com.example.medisanedemo.feature_login.domain.model.AccountInfo
import com.example.medisanedemo.feature_login.domain.model.LoginInfo
import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_login.domain.model.ProfileDto
import com.example.medisanedemo.feature_login.domain.model.ProfileToAddInfo
import com.example.medisanedemo.feature_login.domain.model.ProfileToDeleteInfo
import com.example.medisanedemo.feature_login.domain.model.TokenDto

interface ILoginRepository {

    suspend fun getUserAccount(pwd: String, username: String): Account

    suspend fun getAllProfiles(accountInfo: AccountInfo): List<ProfileDto>
    suspend fun signUp(loginInfo: LoginInfo): Int

    suspend fun addNewProfile(profileToAddInfo: ProfileToAddInfo): TokenDto
    suspend fun removeProfile(profileToDeleteInfo: ProfileToDeleteInfo): TokenDto
}