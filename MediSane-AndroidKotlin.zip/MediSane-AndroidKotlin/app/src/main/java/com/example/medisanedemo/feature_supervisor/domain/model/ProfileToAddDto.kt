package com.example.medisanedemo.feature_supervisor.domain.model

import com.google.gson.annotations.SerializedName

data class ProfileToAddDto(
    @SerializedName("profile_name")
    val profileName: String,
    @SerializedName("profile_id")
    val profileId: Int,
)
