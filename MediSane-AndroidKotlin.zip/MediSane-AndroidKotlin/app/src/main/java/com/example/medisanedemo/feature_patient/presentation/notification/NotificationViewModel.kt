package com.example.medisanedemo.feature_patient.presentation.notification

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.medisanedemo.feature_patient.domain.model.SuperviseRequestDto
import com.example.medisanedemo.feature_patient.domain.use_case.PatientUseCases
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject

@HiltViewModel
class NotificationViewModel @Inject constructor(
    private val patientUseCases: PatientUseCases,
    savedStateHandle: SavedStateHandle
): ViewModel() {

    private val _state = mutableStateOf(NotificationState())
    val state: State<NotificationState> = _state

    private val responseEventChannel = Channel<ResponseEvent>() // channel with only one observer
    val responseEvents = responseEventChannel.receiveAsFlow() // receiveAsFlow returns an immutable flow, will be observed by the ui


    init {

        val token = savedStateHandle.get<String>("token")!!
        val profileId = savedStateHandle.get<Int>("profileId")!!
        val isSupervisor = savedStateHandle.get<Boolean>("isSupervisor")!!

        setContent(
            token = token,
            profileId = profileId,
            isSupervisor = isSupervisor,
        )


    }

    private fun setContent(
        token: String = state.value.token,
        profileId: Int = state.value.profileId,
        isSupervisor: Boolean = state.value.isSupervisor,
    ) {
        viewModelScope.launch {
            try {
                val awaitingRequestList: List<SuperviseRequestDto> =
                    patientUseCases.getSupervisionRequests.invoke(
                        token = token,
                        profileId = profileId
                    ).awaitingRequests

                _state.value = state.value.copy(
                    token = token,
                    profileId = profileId,
                    awaitingRequestList = awaitingRequestList,
                    screenState = ScreenState.Success,
                    isSupervisor = isSupervisor,
                )
            } catch (e: IOException) {

                _state.value = state.value.copy(
                    screenState = ScreenState.Error(message = "Internet Connection Failed"),
                    token = token,
                    profileId = profileId,
                    isSupervisor = isSupervisor,
                )

            } catch (e: HttpException) {

                _state.value = state.value.copy(
                    screenState = ScreenState.Error(message = e.message()),
                    token = token,
                    profileId = profileId,
                    isSupervisor = isSupervisor,
                )

            }
        }
    }

    fun onEvent(event: NotificationUIEvent) {

        when (event) {
            is NotificationUIEvent.AcceptRequest -> {

                viewModelScope.launch {

                    try {
                        val response = patientUseCases.supervisePatient.invoke(
                            token = state.value.token,
                            supervisorId = if (state.value.isSupervisor) {
                                state.value.profileId
                            } else {
                                event.acceptedRequest.profileId
                            },
                            patientId = if (state.value.isSupervisor) {
                                event.acceptedRequest.profileId
                            } else {
                                state.value.profileId
                                   },
                            isAccepted = true,
                        )

                        if (!response) { // error
                            _state.value = state.value.copy(
                                isError = true,
                                errorMessage = "Error when accepting request"
                            )
                        }
                        else { // success
                            val requestList = _state.value.awaitingRequestList.toMutableList()
                            requestList.remove(event.acceptedRequest)

                            _state.value = state.value.copy(
                                awaitingRequestList = requestList.toList(),
                                isError = false,
                                errorMessage = "",
                            )

                            state.value.snackbarHostState.showSnackbar(
                                message = "Request accepted successfully.",
                            )
                        }

                    } catch (e: IOException) {

                        _state.value = state.value.copy(
                            screenState = ScreenState.Error(message = "Internet Connection Failed"),
                        )

                    } catch (e: HttpException) {

                        _state.value = state.value.copy(
                            screenState = ScreenState.Error(message = e.message()),
                        )

                    }
                }
            }
            is NotificationUIEvent.Retry -> {

                _state.value = state.value.copy(
                    screenState = ScreenState.Loading
                )

                setContent()

            }
            is NotificationUIEvent.DenyRequest -> {

                viewModelScope.launch {

                    try {
                        val response = patientUseCases.supervisePatient.invoke(
                            token = state.value.token,
                            supervisorId = if (state.value.isSupervisor) {
                                state.value.profileId
                            } else {
                                event.deniedRequest.profileId
                            },
                            patientId = if (state.value.isSupervisor) {
                                event.deniedRequest.profileId
                            } else {
                                state.value.profileId
                            },
                            isAccepted = false,
                        )

                        if (!response) {
                            _state.value = state.value.copy(
                                isError = true,
                                errorMessage = "Error when removing request"
                            )
                        }
                        else {
                            val requestList = _state.value.awaitingRequestList.toMutableList()
                            requestList.remove(event.deniedRequest)

                            _state.value = state.value.copy(
                                awaitingRequestList = requestList.toList(),
                                isError = false,
                                errorMessage = "",
                            )

                            state.value.snackbarHostState.showSnackbar(
                                message = "Request removed successfully.",
                            )
                        }
                    } catch (e: IOException) {

                        _state.value = state.value.copy(
                            screenState = ScreenState.Error(message = "Internet Connection Failed"),
                        )

                    } catch (e: HttpException) {

                        _state.value = state.value.copy(
                            screenState = ScreenState.Error(message = e.message()),
                        )

                    }
                }

            }
            is NotificationUIEvent.ToggleAddSupervisionDialog -> {

                _state.value = state.value.copy(
                    isAddSupervisionDialogVisible = event.isVisible,
                    isAddSupervisionError = false,
                    addSupervisionErrorMessage = ""

                )

            }
            is NotificationUIEvent.GetSupervisionProfilesToAdd -> {
                viewModelScope.launch {

                    try {
                        val profilesToAddList =
                            patientUseCases.getAvailableSupervisorsToAdd.invoke(
                                ownProfileId = state.value.profileId,
                                token = state.value.token,
                                wantedUsername = state.value.supervisionToAddName,
                                ownProfileType = state.value.isSupervisor,
                            )

                        _state.value = state.value.copy(
                            profilesToAddList = profilesToAddList,
                            isAddSupervisionError = false,
                            addSupervisionErrorMessage = ""
                        )
                    } catch (e: IOException) {

                        _state.value = state.value.copy(
                            isAddSupervisionError = true,
                            addSupervisionErrorMessage = "Connection error."
                        )
                    } catch (e: HttpException) {

                        _state.value = state.value.copy(
                            isAddSupervisionError = true,
                            addSupervisionErrorMessage = e.message() ?: "Invalid name"
                        )
                    }
                }
            }
            is NotificationUIEvent.SetSupervisionToAddName -> {
                _state.value = state.value.copy(
                    supervisionToAddName = event.username
                )
            }

            is NotificationUIEvent.AddSupervision -> {
                try {
                    viewModelScope.launch {
                        val response = patientUseCases.sendSuperviseRequestFromPatient.invoke(
                            patientId = if (state.value.isSupervisor) {
                                event.supervisionId
                            } else {
                                state.value.profileId
                                   },
                            supervisorId = if (state.value.isSupervisor) {
                                state.value.profileId
                            } else {
                                event.supervisionId
                            },
                            sentBy = state.value.isSupervisor,
                            token = state.value.token,
                        )

                        _state.value = state.value.copy(
                            isAddSupervisionError = response != 1,
                            addSupervisionErrorMessage = if (response != 1) {
                                "Request could not be sent"
                            } else {
                                ""
                            },
                            isAddSupervisionDialogVisible = response != 1, // if no error, close the dialog
                        )

                        if (response == 1) {
                            state.value.snackbarHostState.showSnackbar(
                                message = "Request sent successfully.",
                            )
                        }
                    }
                } catch (e: IOException) {

                    _state.value = state.value.copy(
                        isAddSupervisionError = true,
                        addSupervisionErrorMessage = "Connection error."
                    )
                } catch (e: HttpException) {

                    _state.value = state.value.copy(
                        isAddSupervisionError = true,
                        addSupervisionErrorMessage = e.message() ?: "Http error."
                    )
                }
            }



        }
    }


    sealed class ResponseEvent {


    }
}