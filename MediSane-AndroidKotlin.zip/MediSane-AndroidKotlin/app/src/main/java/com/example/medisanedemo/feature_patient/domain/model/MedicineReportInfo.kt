package com.example.medisanedemo.feature_patient.domain.model

import com.google.gson.annotations.SerializedName
import java.time.LocalDateTime

data class MedicineReportInfo(
    val token: String,
    @SerializedName("patient_id")
    val profileId: Int,
    @SerializedName("medicine_name")
    val medicineName: String,
    val label: Boolean,
    @SerializedName("hour_of_dose")
    val hourOfDose: String,
    @SerializedName("is_update")
    val isUpdate: Boolean



)

/*
patient_id: int
medicine_name: str
label: bool
hour_of_dose: str
is_update: bool

token: str

 */

