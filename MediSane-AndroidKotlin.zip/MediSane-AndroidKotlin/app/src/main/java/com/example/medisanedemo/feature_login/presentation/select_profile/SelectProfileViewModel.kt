package com.example.medisanedemo.feature_login.presentation.select_profile

import android.util.Log
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_login.domain.model.ProfileToAddInfo
import com.example.medisanedemo.feature_login.domain.model.ProfileToDeleteInfo
import com.example.medisanedemo.feature_login.domain.use_case.LoginUseCases
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject


@HiltViewModel
class SelectProfileViewModel @Inject constructor(
    private val loginUseCases: LoginUseCases,
    savedStateHandle: SavedStateHandle
): ViewModel() {


    private val _state = mutableStateOf(SelectProfileState())
    val state: State<SelectProfileState> = _state

    private val responseEventChannel = Channel<ResponseEvent>() // channel with only one observer
    val responseEvents = responseEventChannel.receiveAsFlow() // receiveAsFlow returns an immutable flow, will be observed by the ui


    init {

        val accountId = savedStateHandle.get<Int>("accountId")!!
        val token = savedStateHandle.get<String>("token")!!

        _state.value = state.value.copy(
            token = token,
            accountId = accountId
        )

        setSelectProfileContent()

    }

    private fun setSelectProfileContent(
        token: String = state.value.token
    ) {
        viewModelScope.launch {

            try {
                val profileList = loginUseCases.getAllProfiles.invoke(token = token, accountId = state.value.accountId)

                _state.value = state.value.copy(
                    token = token,
                    profileList = profileList,
                    isAddProfileDialogVisible = false,
                    groupedProfileList = profileList.groupBy { profile: Profile ->
                        profile.type
                    },
                    screenState = ScreenState.Success,
                )
            } catch(e: IOException) {

                _state.value = state.value.copy(
                    token = token,
                    screenState = ScreenState.Error(
                        message = "Internet Connection Failed",
                    ),
                )

            } catch(e: HttpException) {

                _state.value = state.value.copy(
                    token = token,
                    screenState = ScreenState.Error(
                        message = "Http Error: " + e.message
                    ),
                )
            }
        }
    }

    fun onEvent(event: SelectProfileScreenUIEvent) {
        when (event) {
            is SelectProfileScreenUIEvent.GoToProfile -> {
                viewModelScope.launch{
                    responseEventChannel.send(ResponseEvent.ProfileSelected(event.profile))
                }
            }

            is SelectProfileScreenUIEvent.ToggleAddProfileDialog -> {
                _state.value = state.value.copy(
                    isAddProfileDialogVisible = event.isVisible
                )
            }

            is SelectProfileScreenUIEvent.SetProfileToAddName -> {
                _state.value = state.value.copy(
                    profileToAddName = event.profileName
                )
            }

            is SelectProfileScreenUIEvent.PressedOnSegmentedButton -> {
                _state.value = state.value.copy(
                    selectedIndex = event.index
                )
            }

            is SelectProfileScreenUIEvent.AddProfile -> {

                val profileType = state.value.selectedIndex == 1
                val payload = ProfileToAddInfo(
                    token = state.value.token,
                    profileName = state.value.profileToAddName,
                    type = profileType
                )
                val TAG = "SelectProfileViewModel"

                viewModelScope.launch {
                    try {
                        val newToken = loginUseCases.addNewProfile.invoke(
                            profileToAddInfo = payload
                        )

                        setSelectProfileContent(token = newToken)

                        //Log.d(TAG, "token after: $newToken")

                        responseEventChannel.send(ResponseEvent.TokenAcquired(newToken))

                    } catch(e: IOException) {

                        _state.value = state.value.copy(
                            screenState = ScreenState.Error(
                                message = "Internet Connection Failed",
                            ),
                        )

                    } catch(e: HttpException) {

                        _state.value = state.value.copy(
                            screenState = ScreenState.Error(
                                message = "Http Error: " + e.message
                            ),
                        )
                    }

                }
            }
            is SelectProfileScreenUIEvent.DeleteProfile -> {
                val payload = ProfileToDeleteInfo(
                    token = state.value.token,
                    profileId = event.profile.profileId
                )

                viewModelScope.launch {

                    try {
                        val newToken = loginUseCases.deleteProfile.invoke(payload)

                        setSelectProfileContent(token = newToken)

                        //Log.d(TAG, "token after: $newToken")

                        responseEventChannel.send(ResponseEvent.TokenAcquired(newToken))


                    } catch(e: IOException) {

                        _state.value = state.value.copy(
                            screenState = ScreenState.Error(
                                message = "Internet Connection Failed",
                            ),
                        )

                    } catch(e: HttpException) {

                        _state.value = state.value.copy(
                            screenState = ScreenState.Error(
                                message = "Http Error: " + e.message
                            ),
                        )
                    }
                }

                _state.value = state.value.copy(
                    isAddProfileDialogVisible = false
                )
            }

            is SelectProfileScreenUIEvent.Retry -> {

                _state.value = state.value.copy(
                    screenState = ScreenState.Loading
                )

                setSelectProfileContent()
            }

            is SelectProfileScreenUIEvent.NewTokenAcquired -> {
                _state.value = state.value.copy(
                    token = event.token
                )

            }
        }

    }

    /* one time events that ViewModel sends, and the UI reads
    * we do not want to hold onto these events unlike states that are persistent
    */
    sealed class ResponseEvent {
        data class ProfileSelected(val profile: Profile): ResponseEvent() // go to profile
        data class TokenAcquired(val token: String): ResponseEvent()
    }
}