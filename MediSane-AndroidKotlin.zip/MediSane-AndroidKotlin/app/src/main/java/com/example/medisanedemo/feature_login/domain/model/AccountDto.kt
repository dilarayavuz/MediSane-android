package com.example.medisanedemo.feature_login.domain.model

import com.google.gson.annotations.SerializedName

data class AccountDto(
    @SerializedName("account_id")
    val accountId :Int,
    @SerializedName("access_token")
    val token: String,
    @SerializedName("token_type")
    val tokenType: String
)


fun AccountDto.toAccount(): Account {
    return Account(
        id = accountId,
        token = token
    )
}