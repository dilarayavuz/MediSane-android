package com.example.medisanedemo.feature_supervisor.data.data_source



import com.example.medisanedemo.feature_patient.domain.model.AwaitingRequestsDto
import com.example.medisanedemo.feature_patient.domain.model.ProfileRequestNotificationInfo
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableProfilesToAddDto
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableSupervisionInfo
import com.example.medisanedemo.feature_supervisor.domain.model.PatientDto
import com.example.medisanedemo.feature_supervisor.domain.model.SuperviseRequestInfo
import com.example.medisanedemo.feature_supervisor.domain.model.SupervisorInfo
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.PUT

interface SupervisorApiService {

    @POST("/post/get-patients")
    suspend fun getPatients(@Body profileInfo: SupervisorInfo): List<PatientDto>

    @POST("/post/available-supervision-profiles")
    suspend fun getPatientProfilesToAdd(@Body availableSupervisionInfo: AvailableSupervisionInfo): AvailableProfilesToAddDto

    @PUT("/put/supervise-patient-request")
    suspend fun sendSuperviseRequest(@Body superviseRequestInfo: SuperviseRequestInfo): Int

    @POST("/post/get-supervision-requests")
    suspend fun getSupervisionRequests(@Body profileRequestNotificationInfo: ProfileRequestNotificationInfo): AwaitingRequestsDto

}