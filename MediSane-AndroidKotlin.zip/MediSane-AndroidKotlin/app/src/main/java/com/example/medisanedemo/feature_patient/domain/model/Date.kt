package com.example.medisanedemo.feature_patient.domain.model

import java.sql.Timestamp
import java.time.LocalDateTime

data class Date(
    val minutes: Int?,
    val hour: Int?,
    val day: Int,
    val month: Int,
    val year: Int
)
