package com.example.medisanedemo.feature_supervisor.domain.use_case

import com.example.medisanedemo.feature_login.presentation.signup.SignupUIEvent
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableProfilesToAddDto
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableSupervisionInfo
import com.example.medisanedemo.feature_supervisor.domain.model.ProfileToAddDto
import com.example.medisanedemo.feature_supervisor.domain.repository_interface.ISupervisorRepository
import javax.inject.Inject

class GetAvailablePatientsToAddUseCase @Inject constructor(
    private val repository: ISupervisorRepository
) {

    /*
   * allows us to call this class as a function
   * */
    suspend operator fun invoke(
        ownProfileId: Int,
        wantedUsername: String,

        token: String
    ): List<ProfileToAddDto> {

        val availableProfilesToAddDto = repository.getPatientProfilesToAdd(
            AvailableSupervisionInfo(
                token = token,
                wantedUsername = wantedUsername,
                ownProfileId = ownProfileId,
                ownProfileType = true,
            )
        )

        return availableProfilesToAddDto.availableProfiles

    }
}