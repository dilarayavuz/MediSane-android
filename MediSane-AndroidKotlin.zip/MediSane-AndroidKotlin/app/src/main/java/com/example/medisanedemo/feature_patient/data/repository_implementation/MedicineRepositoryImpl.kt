package com.example.medisanedemo.feature_patient.data.repository_implementation

import com.example.medisanedemo.feature_patient.data.data_source.PatientApiService
import com.example.medisanedemo.feature_patient.domain.model.AllMedicinesPayload
import com.example.medisanedemo.feature_patient.domain.model.MedicineInfo
import com.example.medisanedemo.feature_patient.domain.model.AllMedicineReportPayload
import com.example.medisanedemo.feature_patient.domain.model.MatchingQueryMedicinesDto
import com.example.medisanedemo.feature_patient.domain.model.MedicineReportInfo
import com.example.medisanedemo.feature_patient.domain.model.NotificationInfo
import com.example.medisanedemo.feature_patient.domain.model.ProfileInfo
import com.example.medisanedemo.feature_patient.domain.model.QueryMedicineNameInfo
import com.example.medisanedemo.feature_patient.domain.repository_interface.IMedicineRepository

class MedicineRepositoryImpl (
    private val api: PatientApiService
): IMedicineRepository {

    val TAG = "MedicineRepositoryImpl"

    override suspend fun getAllMedicines(profileInfo: ProfileInfo): AllMedicinesPayload {
        val payload = api.getAllMedicines(profileInfo)

        //Log.d(TAG, "payload: $payload")
        //Log.d(TAG, "medicineList: " + payload.medicineList)
        return payload
    }


    override suspend fun addMedicine(medicineInfo: MedicineInfo) {
        api.addMedicine(medicineInfo)
    }

    override suspend fun getMedicineReport(profileInfo: ProfileInfo): AllMedicineReportPayload {
        return api.getMedicineReport(profileInfo)
    }

    override suspend fun addMedicineReport(medicineReportInfo: MedicineReportInfo): Int {
        return api.addMedicineReport(medicineReportInfo)
    }

    override suspend fun getQueryMedicineName(queryMedicineNameInfo: QueryMedicineNameInfo): MatchingQueryMedicinesDto {
        val payload = api.getQueryMedicineName(queryMedicineNameInfo)

        return payload
    }

    override suspend fun sendPushNotification(notificationInfo: NotificationInfo) {
        api.sendPushNotification(notificationInfo)
    }
}