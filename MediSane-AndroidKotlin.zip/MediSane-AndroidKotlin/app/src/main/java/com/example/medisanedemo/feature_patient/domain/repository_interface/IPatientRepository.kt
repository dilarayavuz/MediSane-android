package com.example.medisanedemo.feature_patient.domain.repository_interface

import com.example.medisanedemo.feature_patient.domain.model.AwaitingRequestsDto
import com.example.medisanedemo.feature_patient.domain.model.ProfileRequestNotificationInfo
import com.example.medisanedemo.feature_patient.domain.model.SupervisePatientInfo
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableProfilesToAddDto
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableSupervisionInfo
import com.example.medisanedemo.feature_supervisor.domain.model.SuperviseRequestInfo


interface IPatientRepository {

    suspend fun getSupervisionRequests(profileRequestNotificationInfo: ProfileRequestNotificationInfo): AwaitingRequestsDto

    suspend fun supervisePatient(supervisePatientInfo: SupervisePatientInfo): Boolean


    suspend fun getSupervisorProfilesToAdd(availableSupervisionInfo: AvailableSupervisionInfo): AvailableProfilesToAddDto


    suspend fun sendSuperviseRequest(superviseRequestInfo: SuperviseRequestInfo): Int
}