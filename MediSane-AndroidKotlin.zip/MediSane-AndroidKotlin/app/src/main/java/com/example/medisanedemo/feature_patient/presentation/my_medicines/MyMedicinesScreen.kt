package com.example.medisanedemo.feature_patient.presentation.my_medicines

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.presentation.login.components.HeadlineTextComponent
import com.example.medisanedemo.feature_login.presentation.login.components.NormalTextComponent
import com.example.medisanedemo.feature_login.presentation.select_profile.components.ErrorScreenComponent
import com.example.medisanedemo.feature_patient.domain.model.Medicine
import com.example.medisanedemo.feature_patient.domain.model.MedicineReport
import com.example.medisanedemo.feature_patient.presentation.my_medicines.components.LazyMedicineReportColumnComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.TopAppBarComponent
import com.example.medisanedemo.feature_patient.presentation.my_medicines.components.LazyClashColumnComponent
import com.example.medisanedemo.feature_patient.presentation.my_medicines.components.LazyMedicineColumnComponent
import com.example.medisanedemo.feature_patient.presentation.my_medicines.components.MedicineInfoDialogComponent
import com.example.medisanedemo.feature_patient.presentation.my_medicines.components.SingleChoiceSegmentedButtonComponent
import com.example.medisanedemo.feature_patient.presentation.util.PatientUiUtils.getMedicineMap
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState
import com.example.medisanedemo.ui.theme.MyTheme
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

@Composable
fun MyMedicinesScreen(
    responseEvents: Flow<MyMedicinesViewModel.ResponseEvent>,
    medicineList: List<Medicine>,
    medicineInfoList: List<Medicine>,
    medicineReportList: List<MedicineReport>,
    clashList: List<Triple<Medicine, Medicine, String>>,
    onMedicineClick: (List<Medicine>) -> Unit,
    onSegmentedButtonClick: (Int) -> Unit,
    onPressBackButton: () -> Unit,
    onPressLogoutButton: () -> Unit,
    onDismissMedicineInfoDialog: () -> Unit,
    onPressEditMedicine: (Medicine) -> Unit,
    onPressDeleteMedicine: (Medicine) -> Unit,
    onNavigateToEditMedicine: (String, Int, Int, String, Boolean, String) -> Unit,
    onRetry: () -> Unit,
    token: String,
    accountId: Int,
    profileId: Int,
    profileName: String,
    isSupervisor: Boolean,
    selectedIndex: Int,
    isDialogVisible: Boolean,
    screenState: ScreenState
) {

    val context = LocalContext.current

    LaunchedEffect(key1 = context) {
        responseEvents.collect {event ->

            when(event) {
                is MyMedicinesViewModel.ResponseEvent.NavigateToEditMedicine -> {
                    onNavigateToEditMedicine(token, accountId, profileId, profileName, isSupervisor, event.medicineName)
                }
            }
        }

    }

    when (screenState) {
        is ScreenState.Error -> {
            ErrorScreen(
                onRetry = onRetry,
                onPressBackButton = onPressBackButton,
                onPressLogoutButton = onPressLogoutButton,
                message = screenState.message
            )

        }
        is ScreenState.Loading -> {
            LoadingScreen(
                onPressBackButton = onPressBackButton,
                onPressLogoutButton = onPressLogoutButton
            )
        }
        is ScreenState.Success -> {
            SuccessScreen(
                medicineList = medicineList,
                medicineInfoList = medicineInfoList,
                medicineReportList = medicineReportList,
                clashList = clashList,
                onMedicineClick = onMedicineClick,
                onSegmentedButtonClick = onSegmentedButtonClick,
                onPressBackButton = onPressBackButton,
                onPressLogoutButton = onPressLogoutButton,
                onPressDeleteMedicine = onPressDeleteMedicine,
                onPressEditMedicine = onPressEditMedicine,
                onDismissMedicineInfoDialog = onDismissMedicineInfoDialog,
                selectedIndex = selectedIndex,
                isDialogVisible = isDialogVisible
            )
        }
    }

}


@Composable
fun SuccessScreen(
    medicineList: List<Medicine>,
    medicineInfoList: List<Medicine>,
    medicineReportList: List<MedicineReport>,
    clashList: List<Triple<Medicine, Medicine, String>>,
    onMedicineClick: (List<Medicine>) -> Unit,
    onSegmentedButtonClick: (Int) -> Unit,
    onPressBackButton: () -> Unit,
    onPressLogoutButton: () -> Unit,
    onDismissMedicineInfoDialog: () -> Unit,
    onPressEditMedicine: (Medicine) -> Unit,
    onPressDeleteMedicine: (Medicine) -> Unit,
    selectedIndex: Int,
    isDialogVisible: Boolean
) {

    val medicineMap = getMedicineMap(medicineList)
    Scaffold (
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.treatment),
                isHomeScreen = false,
                isSelectProfileScreen = false,
                onBackButtonPressed = onPressBackButton,
                onLogoutButtonPressed = onPressLogoutButton,
                isSelectPatientScreen = false,
                hasNotification = false,
            )
        }
    ){

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 16.dp, start = 16.dp, bottom = 48.dp)
                .padding(paddingValues = it)
        ) {

            if (selectedIndex == 0) { // if medicines option is selected
                Column {
                    HeadlineTextComponent(
                        value = stringResource(id = R.string.current_medication)
                    )

                    Spacer(modifier = Modifier.height(40.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        SingleChoiceSegmentedButtonComponent(
                            selectedIndex = selectedIndex,
                            options = listOf(
                                stringResource(id = R.string.medicines),
                                stringResource(id = R.string.clashes),
                                stringResource(id = R.string.report)
                            ),
                            onClick = onSegmentedButtonClick
                        )
                    }

                    Spacer(modifier = Modifier.height(40.dp))

                    if (medicineList.isNotEmpty()) {
                        LazyMedicineColumnComponent(
                            medicineMap = medicineMap,
                            medicineList = medicineList,
                            onMedicineClick = onMedicineClick
                        )
                    } else {
                        NormalTextComponent(
                            value = stringResource(id = R.string.no_medicine_data)
                        )
                    }
                }
            }
            else if (selectedIndex == 1){ // if clash report option is selected

                val scrollState = rememberScrollState()

                Column (
                    modifier = Modifier
                        .verticalScroll(state = scrollState)
                ){
                    HeadlineTextComponent(
                        value = stringResource(id = R.string.clash_report)
                    )

                    Spacer(modifier = Modifier.height(40.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        SingleChoiceSegmentedButtonComponent(
                            selectedIndex = selectedIndex,
                            options = listOf(
                                stringResource(id = R.string.medicines),
                                stringResource(id = R.string.clashes),
                                stringResource(id = R.string.report)
                            ),
                            onClick = onSegmentedButtonClick
                        )
                    }

                    Spacer(modifier = Modifier.height(40.dp))

                    if (clashList.isNotEmpty()) {
                        LazyClashColumnComponent(
                            clashList = clashList
                        )
                    } else {
                        NormalTextComponent(
                            value = stringResource(id = R.string.no_clash_data)
                        )
                    }

                    Spacer(modifier = Modifier.height(80.dp))

                    Column(
                        modifier = Modifier
                            .padding(top = 8.dp, bottom = 8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.errorContainer)
                            .size(350.dp, 200.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        NormalTextComponent(
                            value = stringResource(id = R.string.disclaimer),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }

            }
            else { // if reports are shown

                Column {
                    HeadlineTextComponent(
                        value = stringResource(id = R.string.medicine_report)
                    )

                    Spacer(modifier = Modifier.height(40.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        SingleChoiceSegmentedButtonComponent(
                            selectedIndex = selectedIndex,
                            options = listOf(
                                stringResource(id = R.string.medicines),
                                stringResource(id = R.string.clashes),
                                stringResource(id = R.string.report)
                            ),
                            onClick = onSegmentedButtonClick
                        )
                    }

                    Spacer(modifier = Modifier.height(40.dp))

                    if (medicineReportList.isNotEmpty()) {
                        LazyMedicineReportColumnComponent(
                            medicineReportList = medicineReportList,
                        )
                    } else {
                        NormalTextComponent(
                            value = stringResource(id = R.string.no_medicine_report_data)
                        )
                    }
                }


            }

            if (isDialogVisible) {

                MedicineInfoDialogComponent(
                    onDismissRequest = onDismissMedicineInfoDialog,
                    onEditMedicine = onPressEditMedicine,
                    onDeleteMedicine = onPressDeleteMedicine,
                    medicineInfoList = medicineInfoList
                )

            }


        }

    }
}


@Composable
fun ErrorScreen(
    message: String,
    onRetry: () -> Unit,
    onPressBackButton: () -> Unit,
    onPressLogoutButton: () -> Unit,
) {

    Scaffold (
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.treatment),
                isHomeScreen = false,
                isSelectProfileScreen = false,
                onBackButtonPressed = onPressBackButton,
                onLogoutButtonPressed = onPressLogoutButton,
                isSelectPatientScreen = false,
                hasNotification = false,
            )
        }
    ){

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 16.dp, start = 16.dp, bottom = 48.dp)
                .padding(paddingValues = it)
        ) {


            ErrorScreenComponent(
                onRetry = onRetry,
                message = message
            )


        }

    }


}

@Composable
fun LoadingScreen(
    onPressBackButton: () -> Unit,
    onPressLogoutButton: () -> Unit,
) {

    Scaffold (
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.treatment),
                isHomeScreen = false,
                isSelectProfileScreen = false,
                onBackButtonPressed = onPressBackButton,
                onLogoutButtonPressed = onPressLogoutButton,
                isSelectPatientScreen = false,
                hasNotification = false,
            )
        }
    ){

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 16.dp, start = 16.dp, bottom = 48.dp)
                .padding(paddingValues = it)
        ) {


            Column (
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ){

                CircularProgressIndicator(
                    modifier = Modifier.width(64.dp),
                    color = MaterialTheme.colorScheme.secondary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )

            }


        }

    }

}


@Preview(showBackground = false)
@Composable
fun MedicinePreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){

            MyMedicinesScreen(
                responseEvents = flowOf<MyMedicinesViewModel.ResponseEvent>(),
                medicineList = listOf(
                ),
                medicineReportList = listOf(),
                medicineInfoList = listOf(),
                onMedicineClick = {},
                selectedIndex = 0,
                onSegmentedButtonClick = {},
                onPressBackButton = {},
                onPressLogoutButton = {},
                onPressEditMedicine = {},
                onPressDeleteMedicine = {},
                onDismissMedicineInfoDialog = {},
                onRetry = {},
                clashList = listOf(
                ),
                screenState = ScreenState.Success,
                isDialogVisible = false,
                onNavigateToEditMedicine = {str1, int1, int2, str2, bool, str3 ->},
                token = "",
                accountId = 0,
                profileId = 0,
                profileName = "",
                isSupervisor = false,

            )

        }

    }
}


@Preview(showBackground = false)
@Composable
fun ClashReportPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){

            MyMedicinesScreen(
                responseEvents = flowOf<MyMedicinesViewModel.ResponseEvent>(),
                medicineList = listOf(
                ),
                medicineReportList = listOf(),
                medicineInfoList = listOf(),
                onMedicineClick = {},
                selectedIndex = 1,
                onSegmentedButtonClick = {},
                onPressBackButton = {},
                onPressLogoutButton = {},
                onPressEditMedicine = {},
                onPressDeleteMedicine = {},
                onDismissMedicineInfoDialog = {},
                onRetry = {},
                clashList = listOf(
                ),
                screenState = ScreenState.Success,
                isDialogVisible = false,
                onNavigateToEditMedicine = {str1, int1, int2, str2, bool, str3 ->},
                token = "",
                accountId = 0,
                profileId = 0,
                profileName = "",
                isSupervisor = false,
            )

        }

    }
}


@Preview(showBackground = false)
@Composable
fun MedicineReportPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){

            MyMedicinesScreen(
                responseEvents = flowOf<MyMedicinesViewModel.ResponseEvent>(),
                medicineList = listOf(
                ),
                medicineReportList = listOf(),
                medicineInfoList = listOf(),
                onMedicineClick = {},
                selectedIndex = 2,
                onSegmentedButtonClick = {},
                onPressBackButton = {},
                onPressLogoutButton = {},
                onPressEditMedicine = {},
                onPressDeleteMedicine = {},
                onDismissMedicineInfoDialog = {},
                onRetry = {},
                clashList = listOf(
                ),
                screenState = ScreenState.Success,
                isDialogVisible = false,
                onNavigateToEditMedicine = {str1, int1, int2, str2, bool, str3 ->},
                token = "",
                accountId = 0,
                profileId = 0,
                profileName = "",
                isSupervisor = false,
            )

        }

    }
}

/*
@Preview(showBackground = false)
@Composable
fun MedicineErrorPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){

            MyMedicinesScreen(
                responseEvents = flowOf<MyMedicinesViewModel.ResponseEvent>(),
                medicineList = listOf(
                ),
                medicineReportList = listOf(),
                medicineInfoList = listOf(),
                onMedicineClick = {},
                profileId = 0,
                selectedIndex = 0,
                onSegmentedButtonClick = {},
                onPressBackButton = {},
                onPressLogoutButton = {},
                onPressEditMedicine = {},
                onPressDeleteMedicine = {},
                onDismissMedicineInfoDialog = {},
                onRetry = {},
                clashList = listOf(
                ),
                screenState = MyMedicinesScreenState.Error(message = "Internet Connection Failed"),
                isDialogVisible = false
            )

        }

    }
}
*/

/*
@Preview(showBackground = false)
@Composable
fun MedicineLoadingPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){

            MyMedicinesScreen(
                responseEvents = flowOf<MyMedicinesViewModel.ResponseEvent>(),
                medicineList = listOf(
                ),
                medicineReportList = listOf(),
                medicineInfoList = listOf(),
                onMedicineClick = {},
                profileId = 0,
                selectedIndex = 0,
                onSegmentedButtonClick = {},
                onPressBackButton = {},
                onPressLogoutButton = {},
                onPressEditMedicine = {},
                onPressDeleteMedicine = {},
                onDismissMedicineInfoDialog = {},
                onRetry = {},
                clashList = listOf(
                ),
                screenState = MyMedicinesScreenState.Loading,
                isDialogVisible = false
            )

        }

    }
}

 */

