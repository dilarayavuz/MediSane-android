package com.example.medisanedemo.feature_patient.presentation.add_medicine

import java.time.LocalDateTime
import java.time.LocalTime

data class AddMedicineState(

    val profileId: Int = 0,
    val accountId: Int = 0,
    val token: String = "",
    val profileName: String = "",
    val isSupervisor: Boolean = false,
    val isUpdate: Boolean = false,
    val errorMessage: String = "",
    val isError: Boolean = false,


    val isTimesPerDayDropdownMenuExpanded: Boolean = false,
    val isDoseAmountDropdownMenuExpanded: Boolean = false,
    val isDatePickerVisible: Boolean = false,
    val selectedTimeIndex: Int = 0,
    val isTimePickerVisible: Boolean = false,
    val isRemainingAmountVisible: Boolean = false,


    val timesPerDay: Int = 1, // how many times they take per day
    val didUserEnterInput: Boolean = false,
    val medicineName: String = "",
    val frequency: Int = 1,
    val frequencyDisplay: String = "1",
    val startDateList: List<LocalDateTime> = listOf(LocalDateTime.now()), // TODO ensure uniqueness
    val hourOfDoseList: List<LocalTime> = listOf(LocalTime.MIDNIGHT), // TODO ensure uniqueness
    val endDate: LocalDateTime? = null, // optional
    val doseAmount: Int = 1, // optional how many doses per take
    val usageDescription: String = "", // optional
    val hasNotification: Boolean = false, // optional
    val remainingAmount: Int? = null, // optional, how many pills left at home
    val remainingAmountDisplay: String = "1",


    val isUsageDescriptionVisible: Boolean = false,
    val isSetEndDateVisible: Boolean = false,
    val isSetNotificationVisible: Boolean = false,


    val selectedWeekDaysList: List<Int> = listOf(),

    val medicineList: List<String> = listOf(),





)
