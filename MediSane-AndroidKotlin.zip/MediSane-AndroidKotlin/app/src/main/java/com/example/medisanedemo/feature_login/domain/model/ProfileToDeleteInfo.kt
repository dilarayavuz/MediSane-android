package com.example.medisanedemo.feature_login.domain.model

data class ProfileToDeleteInfo(
    val profileId: Int,
    val token: String
)
