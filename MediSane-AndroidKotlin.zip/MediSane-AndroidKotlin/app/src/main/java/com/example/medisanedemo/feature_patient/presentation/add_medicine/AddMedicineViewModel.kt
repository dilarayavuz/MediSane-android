package com.example.medisanedemo.feature_patient.presentation.add_medicine

import android.util.Log
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.text.toLowerCase
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.medisanedemo.feature_patient.domain.model.MedicineInfo
import com.example.medisanedemo.feature_patient.domain.use_case.PatientUseCases
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import java.io.IOException
import java.time.LocalDateTime
import java.time.LocalTime
import javax.inject.Inject

@HiltViewModel
class AddMedicineViewModel @Inject constructor(
    private val patientUseCases: PatientUseCases,
    savedStateHandle: SavedStateHandle
): ViewModel() {


    //val TAG = "AddMedicineViewModel"

    private val _state = mutableStateOf(AddMedicineState())
    val state: State<AddMedicineState> = _state

    private val responseEventChannel = Channel<ResponseEvent>() // channel with only one observer
    val responseEvents = responseEventChannel.receiveAsFlow() // receiveAsFlow returns an immutable flow, will be observed by the ui

    private val queryInput = Channel<String>(Channel.CONFLATED)
    init {
        val accountId = savedStateHandle.get<Int>("accountId")!!
        val profileId = savedStateHandle.get<Int>("profileId")!!
        val profileName = savedStateHandle.get<String>("profileName")!!
        val token = savedStateHandle.get<String>("token")!!
        val isSupervisor = savedStateHandle.get<Boolean>("isSupervisor")!!
        val medicineName = savedStateHandle.get<String>("medicineName")

        _state.value = state.value.copy(
            profileId = profileId,
            accountId = accountId,
            profileName = profileName,
            isSupervisor = isSupervisor,
            token = token,
            medicineName = if (!medicineName.isNullOrEmpty()) {
                medicineName
            } else {
                ""
            },
            isUpdate = !medicineName.isNullOrEmpty()
        )
        /* if medicineName: String? is not null, then this is not adding a new medicine but editing
        * an already existing medicine with the name == medicineName
        */
        if (!medicineName.isNullOrEmpty()) {
            viewModelScope.launch {
                responseEventChannel.send(ResponseEvent.GoToInputColumn)
            }
        }

        retrieveMedicines()

    }

    private fun retrieveMedicines() {
        val TAG = "retrieveCharacters"
        viewModelScope.launch(Dispatchers.IO) {
            queryInput.receiveAsFlow()
                .filter { validateQuery(it) }
                .debounce(2000) //  seconds
                .collect {query: String ->


                    val medicineList = patientUseCases.sendQueryMedicineName.invoke(
                        searchString = query,
                        token = state.value.token,
                    )


                    _state.value = state.value.copy(
                        medicineList = medicineList,
                    )
                }
        }
    }

    private fun validateQuery(query: String): Boolean = query.length >= 2


    fun onEvent(event: AddMedicineUIEvent) {
        when (event) {
            is AddMedicineUIEvent.SetMedicineName -> {

                if (event.medicineName == "") {

                    _state.value = state.value.copy(
                        medicineName = event.medicineName,
                        didUserEnterInput = false
                    )
                }

                else {

                    _state.value = state.value.copy(
                        medicineName = event.medicineName,
                        didUserEnterInput = true
                    )

                    queryInput.trySend(event.medicineName)
                }

            }
            is AddMedicineUIEvent.PressedOnInputColumn -> {

                viewModelScope.launch {
                    responseEventChannel.send(ResponseEvent.GoToInputColumn)
                }
            }
            is AddMedicineUIEvent.PressedOnEverydayColumn -> {
                viewModelScope.launch {

                    _state.value = state.value.copy(
                        frequency = 1, // everyday
                    )
                    responseEventChannel.send(ResponseEvent.GoToEverydayColumn)


                }
            }
            is AddMedicineUIEvent.PressedOnEveryXDayColumn -> {
                viewModelScope.launch {
                    responseEventChannel.send(ResponseEvent.GoToEveryXDayColumn)
                }
            }
            is AddMedicineUIEvent.PressedOnSpecificDaysOfWeekColumn -> {
                viewModelScope.launch {

                    _state.value = state.value.copy(
                        frequency = 7, // every 7 days
                    )
                    responseEventChannel.send(ResponseEvent.GoToSpecificDaysOfWeekColumn)
                }
            }
            is AddMedicineUIEvent.ToggleDatePicker -> {
                _state.value = state.value.copy(
                    isDatePickerVisible = event.isVisible
                )

            }
            is AddMedicineUIEvent.SetOneStartDate -> { // call from the everyday option screen. there is only 1 startDate
                _state.value = state.value.copy(
                    startDateList = mutableStateListOf(event.date),
                    isDatePickerVisible = false
                )

            }
            is AddMedicineUIEvent.ToggleTimePicker -> {
                _state.value = state.value.copy(
                    isTimePickerVisible = event.isVisible
                )

            }
            is AddMedicineUIEvent.SetHourValue -> {
                val newHourList = state.value.hourOfDoseList.toMutableStateList()
                newHourList[state.value.selectedTimeIndex] = event.hour
                _state.value = state.value.copy(
                    hourOfDoseList = newHourList.sortedDescending().toMutableStateList(),
                    isTimePickerVisible = false
                )

            }
            is AddMedicineUIEvent.ToggleTimesPerDayDropdown -> {
                _state.value = state.value.copy(
                    isTimesPerDayDropdownMenuExpanded = event.isExpanded
                )

            }
            is AddMedicineUIEvent.SetDoseAmount -> {
                _state.value = state.value.copy(
                    doseAmount = event.doseAmount,
                    isDoseAmountDropdownMenuExpanded = false

                )

            }

            is AddMedicineUIEvent.PressedOnTimeColumn -> {
                _state.value = state.value.copy(
                    selectedTimeIndex = event.selectedTimeIndex,
                    isTimePickerVisible = true

                )
            }

            is AddMedicineUIEvent.SetTimesPerDay -> {

                val hourList = mutableStateListOf<LocalTime>()

                for (i in 1..event.timesPerDay) { // returns a list with resetted values
                    hourList.add(LocalTime.MIDNIGHT)
                }

                _state.value = state.value.copy(
                    timesPerDay = event.timesPerDay,
                    hourOfDoseList = hourList,
                    isTimesPerDayDropdownMenuExpanded = false

                )
            }

            is AddMedicineUIEvent.ToggleDoseAmountDropdown -> {
                _state.value = state.value.copy(
                    isDoseAmountDropdownMenuExpanded = event.isExpanded
                )

            }

            is AddMedicineUIEvent.PressedOnSubmit -> {

                if (state.value.endDate != null && state.value.startDateList[0] > state.value.endDate) {
                    _state.value = state.value.copy(
                        errorMessage = "Treatment end date cannot come before treatment start date",
                        isError = true
                    )
                }
                else {
                    val medicineInfoToSend = MedicineInfo(
                        profileId = state.value.profileId,
                        medicineName = state.value.medicineName.lowercase(),
                        frequency = state.value.frequency,
                        startDateList = convertDates(
                            dateList = state.value.startDateList,
                            hourOfDoseList = state.value.hourOfDoseList
                        ),
                        endDate = if (state.value.endDate == null) {
                            null
                        } else {
                            convertDates(listOf(state.value.endDate!!), listOf(LocalTime.MIDNIGHT))[0]
                        },
                        doseAmount = state.value.doseAmount,
                        usageDescription = state.value.usageDescription,
                        hasNotification = state.value.hasNotification,
                        remainingAmount = state.value.remainingAmount,
                        token = state.value.token,
                        isUpdate = state.value.isUpdate,
                    )

                    viewModelScope.launch{

                        try {
                            patientUseCases.addMedicine.invoke(medicineInfoToSend) // submit

                            if (state.value.hasNotification) {
                                patientUseCases.sendPushNotification.invoke(
                                    medicineName = state.value.medicineName,
                                    startDateList = medicineInfoToSend.startDateList,
                                )
                            }

                            responseEventChannel.send(ResponseEvent.GoToHomeScreen) // navigate to home
                        } catch(e: IOException) {

                            _state.value = state.value.copy(
                                isError = true,
                                errorMessage = "Internet Connection Failed"
                            )
                        }
                    }
                }

            }

            is AddMedicineUIEvent.SetFrequency -> {

                val frequencyInt: Int = if (event.frequencyDisplay == ""){
                    1
                }
                else if (event.frequencyDisplay.toInt() < 0) {
                    1
                }
                else {
                    event.frequencyDisplay.toInt()
                }

                _state.value = state.value.copy(
                    frequency = frequencyInt,
                    frequencyDisplay = event.frequencyDisplay
                )
            }

            is AddMedicineUIEvent.SetRemainingAmount -> {

                val remainingAmountInt: Int = if (event.remainingAmountDisplay == "") {
                    1
                }
                else if (event.remainingAmountDisplay.toInt() < 0) {
                    1
                }
                else {
                    event.remainingAmountDisplay.toInt()
                }

                _state.value = state.value.copy(
                    remainingAmount = remainingAmountInt,
                    remainingAmountDisplay = event.remainingAmountDisplay
                )

            }

            is AddMedicineUIEvent.ToggleAddUsageDescriptionDialog -> {
                _state.value = state.value.copy(
                    isUsageDescriptionVisible = event.isVisible
                )
            }

            is AddMedicineUIEvent.SetUsageDescription -> {
                _state.value = state.value.copy(
                    usageDescription = event.usageDescription
                )
            }

            is AddMedicineUIEvent.ToggleEndDatePicker -> {
                _state.value = state.value.copy(
                    isSetEndDateVisible = event.isVisible
                )
            }
            is AddMedicineUIEvent.ToggleRemainingAmountDialog -> {
                _state.value = state.value.copy(
                    isRemainingAmountVisible = event.isVisible
                )
            }

            is AddMedicineUIEvent.SetEndDate -> {
                _state.value = state.value.copy(
                    endDate = event.endDate,
                    isSetEndDateVisible = false
                )
            }

            AddMedicineUIEvent.CloseAlertDialog -> {
                _state.value = state.value.copy(
                    errorMessage = "",
                    isError = false
                )
            }

            AddMedicineUIEvent.PressedOnSubmitWithSpecificWeekdays -> {

                val newStartDateList = state.value.startDateList.toMutableList()

                state.value.selectedWeekDaysList.forEach { weekDay: Int ->
                    val selectedStartDate = findWeekDay(weekDay, state.value.startDateList[0])

                    newStartDateList.add(selectedStartDate)
                }
                newStartDateList.sort()

                if (newStartDateList.size > 1) {
                    newStartDateList.removeAt(0)
                }

                _state.value = state.value.copy(
                    startDateList = newStartDateList.toList()
                )

                viewModelScope.launch {
                    responseEventChannel.send(ResponseEvent.GoToAdditionalOptionsScreen)
                }

            }

            is AddMedicineUIEvent.AddRemoveWeekDay -> {
                val newWeekDaysList = state.value.selectedWeekDaysList.toMutableList()

                if (newWeekDaysList.contains(event.weekDay)) {
                    newWeekDaysList.remove(event.weekDay)
                }
                else {
                    newWeekDaysList.add(event.weekDay)
                }

                _state.value = state.value.copy(
                    selectedWeekDaysList = newWeekDaysList.toList()
                )

            }

            AddMedicineUIEvent.PressedOnNavigateBack -> {
                viewModelScope.launch {
                    if (state.value.isUpdate) { // editing an existing medicine, navigate back to medicine info
                        responseEventChannel.send(
                            ResponseEvent.GoBackToMedicineInfoScreen(
                                token = state.value.token,
                                accountId = state.value.accountId,
                                profileId = state.value.profileId,
                                profileName = state.value.profileName,
                                isSupervisor = state.value.isSupervisor,
                                medicineName = state.value.medicineName
                                )
                        )
                    }
                    else { // adding a new medicine, navigate back to add medicine screen (i.e. the first screen of the graph
                        responseEventChannel.send(ResponseEvent.GoBackToAddMedicineScreen)
                    }
                }
            }

            is AddMedicineUIEvent.PressedOnQueryMedicineColumn -> {

                _state.value = state.value.copy(
                    medicineName = event.medicineName,
                )

                viewModelScope.launch {
                    responseEventChannel.send(ResponseEvent.GoToInputColumn)
                }
            }

            is AddMedicineUIEvent.SetHasNotification -> {

                _state.value = state.value.copy(
                    hasNotification = event.hasNotification,
                )

            }
            is AddMedicineUIEvent.ToggleSetRemindersDialog -> {

                _state.value = state.value.copy(
                    isSetNotificationVisible = event.isVisible,
                )

            }
        }
    }
    fun findWeekDay(weekDay: Int, startDate: LocalDateTime): LocalDateTime {

        val startDateDayOfWeek = startDate.dayOfWeek.value
        if (startDateDayOfWeek > weekDay) { // weekDay is in the past
            val dayDiff = startDateDayOfWeek - weekDay
            val daysToAdd = 7 - dayDiff

            return startDate.plusDays(daysToAdd.toLong())
        }
        else if (startDateDayOfWeek < weekDay) { // weekDay is in the future

            val dayDiff = weekDay - startDateDayOfWeek

            return startDate.plusDays(dayDiff.toLong())

        }
        else { // weekDay is startDate
            return startDate
        }


    }

    fun convertDates(
        dateList: List<LocalDateTime>,
        hourOfDoseList: List<LocalTime>
    ): List<String> {


        val listOfDateStrings = mutableListOf<String>()
        dateList.forEach { date: LocalDateTime ->

            hourOfDoseList.forEach { time: LocalTime ->

                val localDateTime = LocalDateTime.of(date.year, date.month, date.dayOfMonth, time.hour, time.minute)

                listOfDateStrings.add(localDateTime.toString())
            }
        }

        return listOfDateStrings
    }



    /* one time events that ViewModel sends, and the UI reads
    * we do not want to hold onto these events unlike states that are persistent
    */
    sealed class ResponseEvent {
        object GoToInputColumn: ResponseEvent()
        object GoToEverydayColumn: ResponseEvent()
        object GoToEveryXDayColumn: ResponseEvent()
        object GoToSpecificDaysOfWeekColumn: ResponseEvent()
        object GoToHomeScreen: ResponseEvent()
        object GoToAdditionalOptionsScreen: ResponseEvent()

        /* these two are for selectFrequencyscreen
        *  when editing an existing medicine, backbutton should go back to the medicine info dialog
        *  when adding a new medicine, backbutton should go back to the add medicine screen
        * */
        object GoBackToAddMedicineScreen: ResponseEvent()
        data class GoBackToMedicineInfoScreen(
            val token: String,
            val accountId: Int,
            val profileId: Int,
            val profileName: String,
            val isSupervisor: Boolean,
            val medicineName: String
        ): ResponseEvent()
    }

}