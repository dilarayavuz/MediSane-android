package com.example.medisanedemo.feature_login.domain.model

data class TokenDto(
    val token: String,
)
