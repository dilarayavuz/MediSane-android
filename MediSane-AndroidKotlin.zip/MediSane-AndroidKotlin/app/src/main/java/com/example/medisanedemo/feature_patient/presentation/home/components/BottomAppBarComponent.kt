package com.example.medisanedemo.feature_patient.presentation.home.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.R

@Composable
fun BottomAppBarComponent(
    isHomeScreen: Boolean,
    onProfileClick: () -> Unit = {},
    onFloatingButtonPressed: () -> Unit = {},
    onAddProfileButtonPressed: () -> Unit = {},
    onMedicationClick: () -> Unit = {}
) {
    if (isHomeScreen) {

        BottomAppBar(
            actions = {
                IconButton(
                    onClick = onProfileClick,
                    modifier = Modifier
                        .size(70.dp)
                        .padding(horizontal = 6.dp)
                ) {

                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "Go to your profiles",
                        modifier = Modifier
                            .size(48.dp)
                    )
                }
                IconButton(
                    onClick = onMedicationClick,
                    modifier = Modifier
                        .size(70.dp)
                        .padding(horizontal = 6.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.medication),
                        contentDescription = "See your medicines",
                        modifier = Modifier
                            .size(48.dp)
                    )
                }
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = onFloatingButtonPressed,
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                ) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = "Add new dose",
                        modifier = Modifier
                            .size(56.dp)
                    )

                }
            }
        )

    }

    else {

        BottomAppBar(
            actions = {},
            floatingActionButton = {
                FloatingActionButton(
                    onClick = onAddProfileButtonPressed,
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ) {

                    Icon(
                        painter = painterResource(id = R.drawable.add_profile),
                        contentDescription = "Add new profile",
                        modifier = Modifier
                            .size(48.dp)
                    )

                }
            }
        )

    }

}