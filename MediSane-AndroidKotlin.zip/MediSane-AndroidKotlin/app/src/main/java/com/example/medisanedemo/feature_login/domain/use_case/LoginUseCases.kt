package com.example.medisanedemo.feature_login.domain.use_case

data class LoginUseCases(
    val logUserIn: LogUserInUseCase,
    val signUserUp: SignUserUpUseCase,
    val getAllProfiles: GetAllProfilesUseCase,
    val addNewProfile: AddNewProfileUseCase,
    val deleteProfile: DeleteProfileUseCase
)