package com.example.medisanedemo.feature_patient.domain.model

import com.google.gson.annotations.SerializedName

data class AllMedicinesPayload(
    @SerializedName("medicines")
    val medicineList: List<MedicineDto>?,
    @SerializedName("clashes")
    val clashList: List<List<String>>?
)

