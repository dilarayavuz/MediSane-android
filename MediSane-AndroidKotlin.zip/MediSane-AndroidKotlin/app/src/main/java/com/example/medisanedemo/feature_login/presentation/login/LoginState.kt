package com.example.medisanedemo.feature_login.presentation.login

data class LoginState(
    val isPasswordVisible: Boolean = false,
    val isError: Boolean = false,
    val username: String = "",
    val password: String = "",
    val errorMessage: String = ""
)