package com.example.medisanedemo.feature_patient.domain.use_case


import com.example.medisanedemo.feature_patient.domain.model.AllMedicineReportPayload
import com.example.medisanedemo.feature_patient.domain.model.ProfileInfo
import com.example.medisanedemo.feature_patient.domain.repository_interface.IMedicineRepository
import javax.inject.Inject

class GetMedicineReportUseCase @Inject constructor(
    private val repository: IMedicineRepository
){

    /*
    * allows us to call this class as a function
    * */
    suspend operator fun invoke(
        token: String,
        profileId: Int
    ): AllMedicineReportPayload {
        return repository.getMedicineReport(
            ProfileInfo(
                profileId = profileId,
                token = token
            )
        )
    }
}