package com.example.medisanedemo.feature_patient.presentation.notification


import androidx.compose.material3.SnackbarHostState
import com.example.medisanedemo.feature_patient.domain.model.SuperviseRequestDto
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState
import com.example.medisanedemo.feature_supervisor.domain.model.ProfileToAddDto

data class NotificationState(
    val screenState: ScreenState = ScreenState.Loading,
    val awaitingRequestList: List<SuperviseRequestDto> = listOf(),
    val token: String = "",
    val profileId: Int = -1,
    val isError: Boolean = false,
    val errorMessage: String = "",
    val snackbarHostState: SnackbarHostState = SnackbarHostState(),
    val profilesToAddList: List<ProfileToAddDto> = listOf(),
    val isAddSupervisionDialogVisible: Boolean = false,
    val isAddSupervisionError: Boolean = false,
    val isSupervisor: Boolean = false,
    val supervisionToAddName: String = "",
    val addSupervisionErrorMessage: String = "",

    )
