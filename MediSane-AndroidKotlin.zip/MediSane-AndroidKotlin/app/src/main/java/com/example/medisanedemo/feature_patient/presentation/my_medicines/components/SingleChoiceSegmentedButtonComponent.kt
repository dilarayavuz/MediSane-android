package com.example.medisanedemo.feature_patient.presentation.my_medicines.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SingleChoiceSegmentedButtonComponent(
    selectedIndex: Int,
    options: List<String>,
    onClick: (Int) -> Unit

) {

    SingleChoiceSegmentedButtonRow(
        modifier = Modifier
            .fillMaxWidth()
    ) {
        options.forEachIndexed { index, optionLabel ->

            SegmentedButton(
                selected = selectedIndex == index,
                onClick = {
                    onClick(index)
                          },
                shape = SegmentedButtonDefaults.itemShape(
                    index = index,
                    count = options.size
                ),
                colors = SegmentedButtonDefaults.colors(
                    activeContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                    activeContentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    activeBorderColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    inactiveContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    inactiveContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    inactiveBorderColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
            ) {
                Text(
                    text = optionLabel
                )
                
            }
        }

    }

}