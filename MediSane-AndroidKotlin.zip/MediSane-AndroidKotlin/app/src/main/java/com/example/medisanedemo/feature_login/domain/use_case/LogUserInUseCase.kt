package com.example.medisanedemo.feature_login.domain.use_case

import android.util.Log
import androidx.compose.ui.res.stringResource
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.domain.model.Account
import com.example.medisanedemo.feature_login.domain.model.InvalidUserException
import com.example.medisanedemo.feature_login.domain.repository_interface.ILoginRepository
import javax.inject.Inject



class LogUserInUseCase @Inject constructor(
    private val repository: ILoginRepository
) {

    /*
    * allows us to call this class as a function
    * */
    @Throws (InvalidUserException::class)
    suspend operator fun invoke(pwd: String, username: String): Account {

        val TAG = "LogUserInUseCase"

        if (pwd.isBlank()) {
            throw InvalidUserException(
                message = "The password cannot remain empty."
            )
        }
        if (username.isBlank()) {
            throw InvalidUserException(
                message = "The username cannot remain empty."
            )
        }
        val account: Account = repository.getUserAccount(pwd, username)
        //Log.d(TAG, "accountId=" + accountInfo.id)

        return account
    }
}