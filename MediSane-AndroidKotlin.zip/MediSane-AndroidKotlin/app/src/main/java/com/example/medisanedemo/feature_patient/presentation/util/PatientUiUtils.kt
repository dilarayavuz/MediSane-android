package com.example.medisanedemo.feature_patient.presentation.util


import com.example.medisanedemo.feature_patient.domain.model.Medicine
import com.example.medisanedemo.feature_patient.domain.model.MedicineDto
import com.example.medisanedemo.feature_patient.domain.model.MedicineReport
import com.example.medisanedemo.feature_patient.domain.model.MedicineReportDto
import com.example.medisanedemo.feature_patient.domain.model.toMedicine
import com.example.medisanedemo.feature_patient.domain.model.toMedicineReport
import com.example.medisanedemo.feature_patient.presentation.my_medicines.components.Frequency
import java.time.DayOfWeek
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

object PatientUiUtils {

    fun getMedicineMap(medicineList: List<Medicine>): Map<String, List<Medicine>> {
        return medicineList.groupBy { medicine: Medicine ->
            medicine.name
        }
    }

    /* medicineInfoList: same medicine, different frequency and startDate
    *
    * */
    fun getFrequency(medicineInfoList: List<Medicine>): Frequency {

        return if (medicineInfoList[0].frequency == 7) { // check if SpecificDaysOfWeek

            Frequency.SPECIFICDAYS

        }
        else if (medicineInfoList[0].frequency == 1){ // check if everyday

            Frequency.EVERYDAY

        }
        else { // every x day

            Frequency.EVERYXDAY

        }
    }

    fun getDoseTimes(medicineInfoList: List<Medicine>): List<LocalTime> {

        val timeList: MutableList<LocalTime> = mutableListOf()

        val dict = medicineInfoList.groupBy { medicine: Medicine ->

            medicine.startDate.dayOfWeek
        }

        val values: List<List<Medicine>> = dict.values.toList()

        values[0].forEach { medicine: Medicine ->

            timeList.add(medicine.startDate.toLocalTime())
        }

        return timeList.toList()
    }

    fun getStartDate(medicineInfoList: List<Medicine>): LocalDate {

        val sortedList = medicineInfoList.sortedBy { medicine: Medicine ->

            medicine.startDate

        }

        return sortedList[0].startDate.toLocalDate()

    }

    fun getDaysOfWeek(medicineInfoList: List<Medicine>): List<DayOfWeek> {

        val groupedList = medicineInfoList.groupBy { medicine: Medicine ->

            medicine.startDate.dayOfWeek

        }

        return groupedList.keys.toList()

    }


    fun getMedicinesOfDay(medicineList: List<Medicine>, selectedDate: LocalDateTime): List<Medicine> {

        val medicinesOfDay = medicineList
            .filter { medicine: Medicine ->
                medicine.startDate.isBefore(selectedDate)
                        && (medicine.isEndDateNull || medicine.endDate.isAfter(selectedDate))
                        && (Duration.between(selectedDate, medicine.startDate).toDays().mod(medicine.frequency) == 0)
            }
            .sortedBy {medicine: Medicine ->
                medicine.startDate.toLocalTime()
            }

        return medicinesOfDay

    }

    fun convertMedicineReportDtoList(dtoList: List<MedicineReportDto>?, medicineList: List<Medicine>): List<MedicineReport> {
        return if (dtoList == null) {
            listOf()
        } else {
            val medicineReportList = mutableListOf<MedicineReport>()
            dtoList.forEach { dto: MedicineReportDto ->
                medicineReportList.add(dto.toMedicineReport(medicineList))
            }
            medicineReportList.toList()
        }
    }

    fun convertMedicineDtoList(dtoList: List<MedicineDto>?): List<Medicine> {
        return if (dtoList == null) {
            listOf()
        } else {
            val medicineList = mutableListOf<Medicine>()
            dtoList.forEach { dto: MedicineDto ->
                medicineList.add(dto.toMedicine())
            }
            medicineList.toList()
        }
    }



    fun convertClashList(stringList: List<List<String>>?): List<Triple<Medicine, Medicine, String>> {
        return if (stringList == null) {
            listOf()
        } else {
            val clashList = mutableListOf<Triple<Medicine, Medicine, String>>()
            stringList.forEach { list: List<String> ->
                clashList.add(
                    Triple(
                        Medicine(
                            name = list[0],
                            frequency = -1,
                            startDate = LocalDateTime.now(),
                            remainingAmount = 1,
                            doseAmount = 1,
                            endDate = LocalDateTime.now().plusYears(1),
                            hasNotification = false,
                            usageDescription = "",
                            isEndDateNull = true,
                        ),
                        Medicine(
                            name = list[1],
                            frequency = -1,
                            startDate = LocalDateTime.now(),
                            remainingAmount = 1,
                            doseAmount = 1,
                            endDate = LocalDateTime.now().plusYears(1),
                            hasNotification = false,
                            usageDescription = "",
                            isEndDateNull = true,
                        ),
                        list[2]
                    )
                )
            }
            clashList.toList()

        }
    }

    /*
    *  boolean key can be considered as isFutureMedicine: Boolean. If false, past medicine, if true, future medicine
    * */
    fun groupMedicinesByPastOrFuture(
        medicineList: List<Medicine>,
        selectedDate: LocalDateTime
    ): Map<Boolean, List<Medicine>> {
        return if (medicineList.isEmpty()) {
            mapOf()
        } else {
            val falseList = mutableListOf<Medicine>()
            val trueList = mutableListOf<Medicine>()
            medicineList.forEach { medicine:Medicine ->

                val medicineDosageTime = LocalDateTime.of(
                    selectedDate.year,
                    selectedDate.month,
                    selectedDate.dayOfMonth,
                    medicine.startDate.hour,
                    medicine.startDate.minute
                )

                if (selectedDate.toLocalDate().isBefore(LocalDate.now())) { // all are past medicine

                    falseList.add(medicine)

                } else if (selectedDate.toLocalDate().isAfter(LocalDate.now())) { // all are future medicine

                    trueList.add(medicine)

                } else { // today, need to check time

                    if (medicineDosageTime.toLocalTime().isBefore(LocalTime.now())) { // past medicine

                        falseList.add(medicine)
                    } else { // future medicine

                        trueList.add(medicine)
                    }
                }
            }

            mapOf(
                Pair(false, falseList.toList()),
                Pair(true, trueList.toList())
            )
        }
    }






}

