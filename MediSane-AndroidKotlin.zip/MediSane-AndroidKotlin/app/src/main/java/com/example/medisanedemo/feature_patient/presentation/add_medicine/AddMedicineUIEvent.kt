package com.example.medisanedemo.feature_patient.presentation.add_medicine

import java.time.LocalDateTime
import java.time.LocalTime

sealed class AddMedicineUIEvent {

    data class SetMedicineName(val medicineName: String): AddMedicineUIEvent()
    data class ToggleDatePicker(val isVisible: Boolean): AddMedicineUIEvent()
    data class SetOneStartDate(val date: LocalDateTime): AddMedicineUIEvent()
    data class ToggleTimesPerDayDropdown(val isExpanded: Boolean): AddMedicineUIEvent()
    data class ToggleDoseAmountDropdown(val isExpanded: Boolean): AddMedicineUIEvent()
    data class SetDoseAmount(val doseAmount: Int): AddMedicineUIEvent()
    data class PressedOnTimeColumn(val selectedTimeIndex: Int): AddMedicineUIEvent()
    data class SetTimesPerDay(val timesPerDay: Int): AddMedicineUIEvent()
    data class ToggleTimePicker(val isVisible: Boolean): AddMedicineUIEvent()
    data class SetHourValue(val hour: LocalTime): AddMedicineUIEvent()
    data class SetFrequency(val frequencyDisplay: String): AddMedicineUIEvent() // takes frequency as string, need to convert to int
    data class SetRemainingAmount(val remainingAmountDisplay: String): AddMedicineUIEvent() // takes frequency as string, need to convert to int
    data class ToggleAddUsageDescriptionDialog(val isVisible: Boolean): AddMedicineUIEvent()
    data class ToggleRemainingAmountDialog(val isVisible: Boolean): AddMedicineUIEvent()
    data class SetUsageDescription(val usageDescription: String): AddMedicineUIEvent()
    data class ToggleEndDatePicker(val isVisible: Boolean): AddMedicineUIEvent()
    data class SetEndDate(val endDate: LocalDateTime): AddMedicineUIEvent()
    data class SetHasNotification(val hasNotification: Boolean): AddMedicineUIEvent()
    data class AddRemoveWeekDay(val weekDay: Int): AddMedicineUIEvent()
    data class PressedOnQueryMedicineColumn(val medicineName: String): AddMedicineUIEvent()
    data class ToggleSetRemindersDialog(val isVisible: Boolean): AddMedicineUIEvent()


    object PressedOnInputColumn: AddMedicineUIEvent()
    object PressedOnEverydayColumn: AddMedicineUIEvent()
    object PressedOnEveryXDayColumn: AddMedicineUIEvent()
    object PressedOnSpecificDaysOfWeekColumn: AddMedicineUIEvent()
    object PressedOnSubmit: AddMedicineUIEvent()
    object CloseAlertDialog: AddMedicineUIEvent()
    object PressedOnSubmitWithSpecificWeekdays: AddMedicineUIEvent()
    object PressedOnNavigateBack: AddMedicineUIEvent()
}