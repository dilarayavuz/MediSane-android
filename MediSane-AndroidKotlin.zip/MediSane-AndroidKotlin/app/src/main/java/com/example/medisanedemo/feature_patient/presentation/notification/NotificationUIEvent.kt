package com.example.medisanedemo.feature_patient.presentation.notification

import com.example.medisanedemo.feature_patient.domain.model.SuperviseRequestDto

sealed class NotificationUIEvent {
    data class DenyRequest(val deniedRequest: SuperviseRequestDto): NotificationUIEvent()
    data class AcceptRequest(val acceptedRequest: SuperviseRequestDto): NotificationUIEvent()

    data class ToggleAddSupervisionDialog(val isVisible: Boolean): NotificationUIEvent()
    data class SetSupervisionToAddName(val username: String): NotificationUIEvent()
    data class AddSupervision(val supervisionId: Int): NotificationUIEvent()

    object GetSupervisionProfilesToAdd: NotificationUIEvent()
    object Retry: NotificationUIEvent()
}
