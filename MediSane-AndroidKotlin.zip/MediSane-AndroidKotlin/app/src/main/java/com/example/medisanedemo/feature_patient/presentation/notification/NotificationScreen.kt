package com.example.medisanedemo.feature_patient.presentation.notification

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.presentation.login.components.NormalTextComponent
import com.example.medisanedemo.feature_login.presentation.select_profile.components.ErrorScreenComponent
import com.example.medisanedemo.feature_patient.domain.model.SuperviseRequestDto
import com.example.medisanedemo.feature_patient.presentation.home.components.BottomAppBarComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.TopAppBarComponent
import com.example.medisanedemo.feature_patient.presentation.notification.components.AddSuperviseDialog
import com.example.medisanedemo.feature_patient.presentation.notification.components.LazyNotificationRequestColumnComponent
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState
import com.example.medisanedemo.feature_supervisor.domain.model.ProfileToAddDto
import com.example.medisanedemo.ui.theme.MyTheme

@Composable
fun NotificationScreen (
    screenState: ScreenState,
    awaitingRequestList: List<SuperviseRequestDto>,
    onBackButtonPressed: () -> Unit,
    onAddSupervisionPressed: () -> Unit,
    onRetry: () -> Unit,
    onDenyRequest: (SuperviseRequestDto) -> Unit,
    onAcceptRequest: (SuperviseRequestDto) -> Unit,
    snackbarHostState: SnackbarHostState,
    profilesToAddList: List<ProfileToAddDto>,
    isAddSupervisorDialogVisible: Boolean,
    isAddSupervisionError: Boolean,
    isSupervisor: Boolean,
    supervisionToAddName: String,
    addSupervisionErrorMessage: String,
    onDismissAddSupervision: () -> Unit,
    onConfirmGetSupervisions: () -> Unit,
    onSupervisionNameChange: (String) -> Unit,
    onPressedProfileToSupervise: (ProfileToAddDto) -> Unit,
) {

    when (screenState) {
        is ScreenState.Error -> {
            ErrorScreen(
                onRetry = onRetry,
                message = screenState.message
            )
        }
        is ScreenState.Loading -> {
            LoadingScreen()
        }
        is ScreenState.Success -> {
            SuccessScreen(
                onPressBackButton = onBackButtonPressed,
                awaitingRequestList = awaitingRequestList,
                onDenyRequest = onDenyRequest,
                onAcceptRequest = onAcceptRequest,
                snackbarHostState = snackbarHostState,
                onPressedAddPatient = onAddSupervisionPressed,
                profilesToAddList = profilesToAddList,
                isAddSupervisorDialogVisible = isAddSupervisorDialogVisible,
                isAddSupervisionError = isAddSupervisionError,
                supervisionToAddName = supervisionToAddName,
                addSupervisionErrorMessage = addSupervisionErrorMessage,
                onDismissAddSupervision = onDismissAddSupervision,
                onConfirmGetSupervisions = onConfirmGetSupervisions,
                onSupervisionNameChange = onSupervisionNameChange,
                onPressedProfileToSupervise = onPressedProfileToSupervise,
                isSupervisor = isSupervisor,
            )
        }
    }

}

@Composable
fun SuccessScreen(
    onPressBackButton: () -> Unit,
    onPressedAddPatient: () -> Unit,
    onDenyRequest: (SuperviseRequestDto) -> Unit,
    onAcceptRequest: (SuperviseRequestDto) -> Unit,
    snackbarHostState: SnackbarHostState,
    awaitingRequestList: List<SuperviseRequestDto>,
    profilesToAddList: List<ProfileToAddDto>,
    isAddSupervisorDialogVisible: Boolean,
    isAddSupervisionError: Boolean,
    supervisionToAddName: String,
    isSupervisor: Boolean,
    addSupervisionErrorMessage: String,
    onDismissAddSupervision: () -> Unit,
    onConfirmGetSupervisions: () -> Unit,
    onSupervisionNameChange: (String) -> Unit,
    onPressedProfileToSupervise: (ProfileToAddDto) -> Unit,


    ) {

    Scaffold (
        snackbarHost = {
                       SnackbarHost (hostState = snackbarHostState)
        },
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.notifications),
                isHomeScreen = false,
                isSelectProfileScreen = false,
                onBackButtonPressed = onPressBackButton,
                isSelectPatientScreen = false,
                hasNotification = false,
            )
        },
        bottomBar = {
            BottomAppBarComponent(
                isHomeScreen = false,
                onAddProfileButtonPressed = onPressedAddPatient,
            )
        }
    ) {

        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(it)
        ) {

            if (awaitingRequestList.isNotEmpty()){
                LazyNotificationRequestColumnComponent(
                    awaitingRequestList = awaitingRequestList,
                    onDenyRequest = onDenyRequest,
                    onAcceptRequest = onAcceptRequest,
                )
            }
            else {
                Column (
                    modifier = Modifier
                        .fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ){

                    NormalTextComponent(
                        value = stringResource(id = R.string.no_requests)
                    )

                }
            }

            if (isAddSupervisorDialogVisible) {
                AddSuperviseDialog(
                    onDismissRequest = onDismissAddSupervision,
                    onConfirmRequest = onConfirmGetSupervisions,
                    onSuperviseNameChange = onSupervisionNameChange,
                    onPressedProfileToSupervise = onPressedProfileToSupervise,
                    superviseName = supervisionToAddName,
                    addSuperviseErrorMessage = addSupervisionErrorMessage,
                    isAddSuperviseError = isAddSupervisionError,
                    profilesToAddList = profilesToAddList,
                    isSupervisor = isSupervisor
                )
            }

        }

    }

}


@Composable
fun ErrorScreen(
    onRetry: () -> Unit,
    message: String
) {

    Scaffold (
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.notifications),
                isHomeScreen = false,
                isSelectProfileScreen = false,
                isSelectPatientScreen = false,
                hasNotification = false,
                isSupervisor = false,
            )
        },
        bottomBar = {
            BottomAppBarComponent(
                isHomeScreen = false,
            )
        }
    ){
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(it)
        ) {

            ErrorScreenComponent (
                message = message,
                onRetry = onRetry
            )

        }
    }

}


@Composable
fun LoadingScreen() {

    Scaffold (
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.notifications),
                isHomeScreen = false,
                isSelectProfileScreen = false,
                isSelectPatientScreen = false,
                hasNotification = false,
                isSupervisor = false,
            )
        },
        bottomBar = {
            BottomAppBarComponent(
                isHomeScreen = false,
            )
        }
    ){
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(it)
        ) {

            Column (
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ){

                CircularProgressIndicator(
                    modifier = Modifier.width(64.dp),
                    color = MaterialTheme.colorScheme.secondary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )

            }

        }
    }
}

@Preview(showBackground = true)
@Composable
fun NotifScreenPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){
            NotificationScreen(
                awaitingRequestList = listOf(),
                onAcceptRequest = {},
                onDenyRequest = {},
                onBackButtonPressed = {},
                onRetry = {},
                screenState = ScreenState.Success,
                snackbarHostState = SnackbarHostState(),
                onAddSupervisionPressed = {},
                profilesToAddList = listOf(),
                isAddSupervisorDialogVisible = true,
                isAddSupervisionError = false,
                supervisionToAddName = "",
                addSupervisionErrorMessage = "",
                onDismissAddSupervision = {},
                onConfirmGetSupervisions = {},
                onSupervisionNameChange = {str ->},
                onPressedProfileToSupervise = {prf ->},
                isSupervisor = true,
            )
        }

    }
}

/*
@Preview(showBackground = true)
@Composable
fun NotifScreenPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){
            NotificationScreen(
                awaitingRequestList = listOf(
                    SuperviseRequestDto(
                        username ="Mehmet",
                        profileId = 1,
                        profileName = "MemoPro1"
                    ),
                    SuperviseRequestDto(
                        username ="Ahmet",
                        profileId = 2,
                        profileName = "Ahmet2"
                    ),
                    SuperviseRequestDto(
                        username ="Derya",
                        profileId = 3,
                        profileName = "Deropro"
                    ),
                ),
                onAcceptRequest = {},
                onDenyRequest = {},
                onBackButtonPressed = {},
                onRetry = {},
                screenState = ScreenState.Success,
                snackbarHostState = SnackbarHostState(),
            )
        }

    }
}

* */
