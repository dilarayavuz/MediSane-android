package com.example.medisanedemo.feature_patient.presentation.add_medicine.every_day_screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.presentation.login.components.HeadlineTextComponent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.AddMedicineState
import com.example.medisanedemo.feature_patient.presentation.add_medicine.components.ClickableColumnComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.DatePickerComponent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.components.ExposedDropdownMenuComponent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.components.LazyRowComponent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.components.SubmitButtonComponent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.components.TimePickerComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.TopAppBarComponent
import com.example.medisanedemo.ui.theme.MyTheme
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter

@Composable
fun EveryDayOptionScreen(
    state: AddMedicineState,
    onDismissDatePicker: () -> Unit,
    onConfirmDatePicker: (LocalDateTime) -> Unit,
    onDismissTimePicker: () -> Unit,
    onConfirmTimePicker: (LocalTime) -> Unit,
    onDatePickerToggle: () -> Unit,
    onTimePerDayDropdownExpandedStateChange: (Boolean) -> Unit,
    onTimePerDayDropdownDismissRequest: () -> Unit,
    onDoseAmountDropdownExpandedStateChange: (Boolean) -> Unit,
    onDoseAmountDropdownDismissRequest: () -> Unit,
    onPressTimeColumn: (Int) -> Unit,
    onTimesPerDayChange: (Int) -> Unit,
    onDoseAmountValueChange: (Int) -> Unit,
    onPressBackButton: () -> Unit,
    onPressLogoutButton: () -> Unit,
    onPressSubmitButton: () -> Unit

) {


    Scaffold(
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.everyday),
                isHomeScreen = false,
                isSelectProfileScreen = false,
                onBackButtonPressed = onPressBackButton,
                onLogoutButtonPressed = onPressLogoutButton,
                isSelectPatientScreen = false,
                hasNotification = false,
            )
        }
    ) {
        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
                .padding(paddingValues = it)
        ) {
            val scrollState = rememberScrollState()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(state = scrollState),
            ) {


                HeadlineTextComponent(
                    value = stringResource(id = R.string.select_medicine_start_date),
                    fontSize = 24,
                    textAlign = TextAlign.Center
                )
                if (state.isDatePickerVisible){
                    DatePickerComponent(
                        modifier = Modifier,
                        selectedDate = state.startDateList[0],
                        onDismiss = onDismissDatePicker,
                        onConfirm = onConfirmDatePicker
                    )
                }
                ClickableColumnComponent(
                    onClick = onDatePickerToggle,
                    textValue = state.startDateList[0].format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))
                )

                Spacer(modifier = Modifier.height(40.dp))

                HeadlineTextComponent(
                    value = stringResource(id = R.string.select_times_per_day),
                    fontSize = 24,
                    textAlign = TextAlign.Center
                )

                ExposedDropdownMenuComponent(
                    isExpanded = state.isTimesPerDayDropdownMenuExpanded,
                    textFieldValue = state.timesPerDay.toString(),
                    placeHolderVal = stringResource(id = R.string.select_times_per_day),
                    onExpandedStateChange = onTimePerDayDropdownExpandedStateChange,
                    onDismissRequest = onTimePerDayDropdownDismissRequest,
                    onSelectedValueChange = onTimesPerDayChange
                )

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth(),
                ) {
                    LazyRowComponent(
                        state = state,
                        onTimeClick = onPressTimeColumn
                    )
                }

                if (state.isTimePickerVisible) {
                    TimePickerComponent(
                        state = state,
                        onDismiss = onDismissTimePicker,
                        onConfirm = onConfirmTimePicker // take selectedHourIndex, change its value
                    )
                }

                Spacer(modifier = Modifier.height(40.dp))

                HeadlineTextComponent(
                    value = stringResource(id = R.string.select_dose_amount),
                    fontSize = 24,
                    textAlign = TextAlign.Center
                )

                ExposedDropdownMenuComponent(
                    isExpanded = state.isDoseAmountDropdownMenuExpanded,
                    textFieldValue = state.doseAmount.toString(),
                    placeHolderVal = stringResource(id = R.string.select_dose_amount),
                    onExpandedStateChange = onDoseAmountDropdownExpandedStateChange,
                    onDismissRequest = onDoseAmountDropdownDismissRequest,
                    onSelectedValueChange = onDoseAmountValueChange
                )

                Spacer(modifier = Modifier.height(40.dp))

                Column (
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ){
                    SubmitButtonComponent(
                        textValue = stringResource(id = R.string.add_medicine),
                        onButtonClick = onPressSubmitButton
                    )
                }


            }


        }

    }
}


@Preview(showBackground = true)
@Composable
fun SubmitButtonPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){
            EveryDayOptionScreen(
                state = AddMedicineState(),
                onDismissDatePicker = {  },
                onConfirmDatePicker = {},
                onDismissTimePicker = { },
                onConfirmTimePicker = {},
                onDatePickerToggle = {  },
                onTimePerDayDropdownExpandedStateChange = {},
                onTimePerDayDropdownDismissRequest = {  },
                onDoseAmountDropdownExpandedStateChange = {},
                onDoseAmountDropdownDismissRequest = { },
                onPressTimeColumn = {},
                onTimesPerDayChange = {},
                onDoseAmountValueChange = {},
                onPressBackButton = {},
                onPressLogoutButton = {}
            ) {

            }
        }

    }
}
