package com.example.medisanedemo.feature_patient.domain.use_case


import com.example.medisanedemo.feature_patient.domain.model.AllMedicineReportPayload
import com.example.medisanedemo.feature_patient.domain.model.AwaitingRequestsDto
import com.example.medisanedemo.feature_patient.domain.model.ProfileInfo
import com.example.medisanedemo.feature_patient.domain.model.ProfileRequestNotificationInfo
import com.example.medisanedemo.feature_patient.domain.model.SuperviseRequestDto
import com.example.medisanedemo.feature_patient.domain.repository_interface.IPatientRepository
import javax.inject.Inject

class GetSupervisionRequestsUseCase @Inject constructor(
    private val repository: IPatientRepository
) {
    /*
    * allows us to call this class as a function
    * */
    suspend operator fun invoke(
        token: String,
        profileId: Int
    ): AwaitingRequestsDto {
        return repository.getSupervisionRequests(
            ProfileRequestNotificationInfo(
                profileId = profileId,
                token = token
            )
        )
    }
}