package com.example.medisanedemo.feature_patient.presentation.notification.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.presentation.login.components.ErrorText
import com.example.medisanedemo.feature_login.presentation.login.components.NormalTextComponent
import com.example.medisanedemo.feature_supervisor.domain.model.ProfileToAddDto
import com.example.medisanedemo.feature_supervisor.presentation.patient_list.components.LazyAvailableToSupervisionProfiles

@Composable
fun AddSuperviseDialog(
    onDismissRequest: () -> Unit,
    onConfirmRequest: () -> Unit,
    onSuperviseNameChange: (String) -> Unit,
    onPressedProfileToSupervise: (ProfileToAddDto) -> Unit,
    superviseName: String,
    profilesToAddList: List<ProfileToAddDto>,
    isAddSuperviseError: Boolean,
    isSupervisor: Boolean,
    addSuperviseErrorMessage: String
) {

    Dialog(
        onDismissRequest = onDismissRequest
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(
                    if (profilesToAddList.isNotEmpty()) {
                        400.dp
                    } else {
                        260.dp
                    }
                )
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.background,
                contentColor = MaterialTheme.colorScheme.onBackground
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceEvenly,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.padding(top = 8.dp)
                ){
                    NormalTextComponent(
                        value = if (isSupervisor) {
                            stringResource(id = R.string.add_new_patient)
                        } else {
                            stringResource(id = R.string.add_new_supervisor)
                        }
                    )
                }

                OutlinedTextField(
                    modifier = Modifier
                        .onKeyEvent { event: KeyEvent ->
                            if (event.key == Key.Enter) {
                                /* do nothing */
                                true
                            }
                            false
                        },
                    label = {
                        Text(
                            text = if (isSupervisor) {
                                stringResource(id = R.string.patient_name)
                            } else {
                                stringResource(id = R.string.supervisor_name)
                            }
                        )
                            },
                    value = superviseName,
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        cursorColor = MaterialTheme.colorScheme.primary,
                    ),
                    onValueChange = { patientName: String ->
                        onSuperviseNameChange(patientName)
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )

                if (profilesToAddList.isNotEmpty()) {

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = stringResource(id = R.string.choose_a_profile),
                        modifier = Modifier
                            .fillMaxWidth(),
                        style = TextStyle(
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Normal,
                            fontStyle = FontStyle.Normal,
                        ),
                        color = MaterialTheme.colorScheme.onBackground,
                        textAlign = TextAlign.Center
                    )

                    HorizontalDivider(
                        thickness = 1.dp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    if (isAddSuperviseError) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                        ){
                            ErrorText(
                                errorMessage = addSuperviseErrorMessage
                            )
                        }
                    }

                    LazyAvailableToSupervisionProfiles(
                        profilesToAddList = profilesToAddList,
                        onProfileClick = onPressedProfileToSupervise
                    )
                }

                Row (
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ){

                    TextButton(
                        onClick = onDismissRequest,
                        modifier = Modifier.padding(8.dp),
                    ) {
                        Text(stringResource(id = R.string.dismiss))
                    }

                    TextButton(
                        onClick = onConfirmRequest,
                        modifier = Modifier.padding(8.dp),
                    ) {
                        Text(stringResource(id = R.string.list_profiles))
                    }


                }


            }

        }
    }

}