package com.example.medisanedemo.feature_login.domain.model

data class Profile(
    val profileId: Int,
    val profileName: String,
    val type: ProfileType
)

fun profileDefault(): Profile {
    return Profile(
        profileId = -1,
        profileName = "Default",
        type = ProfileType.PATIENT
        )
}

enum class ProfileType {
    PATIENT, SUPERVISOR
}


