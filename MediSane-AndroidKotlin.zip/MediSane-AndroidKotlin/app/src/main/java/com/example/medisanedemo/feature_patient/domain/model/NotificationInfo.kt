package com.example.medisanedemo.feature_patient.domain.model

import com.google.gson.annotations.SerializedName


data class NotificationInfo(
    @SerializedName("start_date")
    val startDateList: List<String>,
    @SerializedName("medicine_name")
    val medicineName: String,
)
