package com.example.medisanedemo.feature_login.presentation.login

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.domain.model.Account
import com.example.medisanedemo.feature_login.presentation.login.components.ButtonComponent
import com.example.medisanedemo.feature_login.presentation.login.components.ErrorText
import com.example.medisanedemo.feature_login.presentation.login.components.HeadlineTextComponent
import com.example.medisanedemo.feature_login.presentation.login.components.NormalTextComponent
import com.example.medisanedemo.feature_login.presentation.login.components.TextFieldComponent
import com.example.medisanedemo.feature_login.presentation.login.components.PasswordTextFieldComponent
import com.example.medisanedemo.ui.theme.MyTheme
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf


@Composable
fun LoginScreen(
    state: LoginState,
    responseEvents: Flow<LoginViewModel.ResponseEvent>,
    onUserLoggedIn: (Account) -> Unit,
    onUsernameValueChange: (String) -> Unit,
    onPasswordValueChange: (String) -> Unit,
    onVisibilityButtonPressed: () -> Unit,
    onSignupButtonPressed: () -> Unit,
    onLoginButtonPressed: () -> Unit,
    onNavigateToSignup: () -> Unit,
) {

    //val TAG = "LoginScreen" //DEBUG

    val context = LocalContext.current

    LaunchedEffect(key1 = context) {// LaunchedEffect(key = context) --> when context changes, this affect will be relaunched
        responseEvents.collect {event ->
            when (event) {
                is LoginViewModel.ResponseEvent.GoToProfilesFromLogin -> {
                    onUserLoggedIn(event.account)
                }
                is LoginViewModel.ResponseEvent.GoToSignupFromLogin -> {
                    onNavigateToSignup()
                }
            }

        }
    }

    val scrollState = rememberScrollState()

    Surface (
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
    ){

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(state = scrollState),
            verticalArrangement = Arrangement.Center
        ) {

            Column(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(id = R.drawable.medisane_logo_medium),
                    contentDescription = "logo",
                )

            }
            HeadlineTextComponent(value = stringResource(id = R.string.welcome_back))
            NormalTextComponent(value = stringResource(id = R.string.enter_credentials))
            Spacer(modifier = Modifier.height(20.dp))
            TextFieldComponent(
                labelValue = stringResource(id = R.string.username),
                imageVector = Icons.Outlined.Person,
                onValueChange = onUsernameValueChange,
                isError = state.isError,
                textValue = state.username,
                contentDescription = "enter username"
            )
            PasswordTextFieldComponent(
                labelValue = stringResource(id = R.string.password),
                imageVector = Icons.Outlined.Lock,
                onValueChange = onPasswordValueChange,
                onIconClick = onVisibilityButtonPressed,
                isError = state.isError,
                isPasswordVisible = state.isPasswordVisible,
                textValue = state.password
            )

            Spacer(modifier = Modifier.height(20.dp))
            ButtonComponent(
                textValue = stringResource(id = R.string.log_in),
                onButtonClick = onLoginButtonPressed
            )

            Spacer(modifier = Modifier.height(20.dp))

            NormalTextComponent(value = stringResource(id = R.string.or))

            ButtonComponent(
                textValue = stringResource(id = R.string.sign_up),
                onButtonClick = onSignupButtonPressed
            )

            Spacer(modifier = Modifier.height(20.dp))
            if (state.isError) {
                ErrorText(state.errorMessage)
            }
        }



    }
}



@Preview
@Composable
fun PreviewLoginScreen() {

    MyTheme (dynamicColor = false) {

        LoginScreen(
            state = LoginState(
                isError = true,
                errorMessage = "Internet Connection Lost"
            ),
            responseEvents = flowOf(),
            onUserLoggedIn = {},
            onUsernameValueChange = {},
            onPasswordValueChange = {},
            onVisibilityButtonPressed = { },
            onLoginButtonPressed = {},
            onSignupButtonPressed = {},
            onNavigateToSignup = {}
        )


    }
}
