package com.example.medisanedemo.feature_login.data.data_source

import com.example.medisanedemo.feature_login.domain.model.AccountDto
import com.example.medisanedemo.feature_login.domain.model.AccountInfo
import com.example.medisanedemo.feature_login.domain.model.LoginInfo
import com.example.medisanedemo.feature_login.domain.model.ProfileDto
import com.example.medisanedemo.feature_login.domain.model.ProfileToAddInfo
import com.example.medisanedemo.feature_login.domain.model.ProfileToDeleteInfo
import com.example.medisanedemo.feature_login.domain.model.TokenDto
import retrofit2.http.Body
import retrofit2.http.HTTP
import retrofit2.http.POST
import retrofit2.http.PUT

interface LoginApiService {

    @POST("/post/login")
    suspend fun getUserAccount(@Body loginInfo: LoginInfo?): AccountDto

    @POST("/post/profiles")
    suspend fun getAllProfiles(@Body accountId: AccountInfo): List<ProfileDto>

    @PUT("/put/signup")
    suspend fun signUp(@Body loginInfo: LoginInfo): Int


    @PUT("/put/add-profile")
    suspend fun addNewProfile(@Body profileToAddInfo: ProfileToAddInfo): TokenDto

    @HTTP(method = "DELETE", path = "/delete/delete-profile", hasBody = true)
    suspend fun removeProfile(@Body profileToDeleteInfo: ProfileToDeleteInfo): TokenDto



}