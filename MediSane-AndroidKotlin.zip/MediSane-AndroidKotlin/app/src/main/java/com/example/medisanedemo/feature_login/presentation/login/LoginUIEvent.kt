package com.example.medisanedemo.feature_login.presentation.login

import com.example.medisanedemo.feature_patient.presentation.home.HomeUiEvent
import java.time.LocalDateTime

sealed class LoginUIEvent {

    data class SetUsername(val username: String): LoginUIEvent()
    data class SetPassword(val password: String): LoginUIEvent()

    object TogglePasswordVisibility: LoginUIEvent()
    object LoginButtonPressed: LoginUIEvent()
    object SignupButtonPressed: LoginUIEvent()
}