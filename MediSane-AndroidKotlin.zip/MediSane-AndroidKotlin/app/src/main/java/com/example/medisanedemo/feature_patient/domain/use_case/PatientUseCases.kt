package com.example.medisanedemo.feature_patient.domain.use_case

data class PatientUseCases(
    val addMedicine: AddMedicineUseCase,
    val getAllMedicines: GetAllMedicinesUseCase,
    val getMedicineReport: GetMedicineReportUseCase,
    val addMedicineReport: AddMedicineReportUseCase,
    val getSupervisionRequests: GetSupervisionRequestsUseCase,
    val supervisePatient: SupervisePatientUseCase,
    val getAvailableSupervisorsToAdd: GetAvailableSupervisorsToAddUseCase,
    val sendSuperviseRequestFromPatient: SendSuperviseRequestFromPatientUseCase,
    val sendQueryMedicineName: SendQueryMedicineNameUseCase,
    val sendPushNotification: SendPushNotificationUseCase,
)
