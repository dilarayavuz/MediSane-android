package com.example.medisanedemo.feature_supervisor.presentation.patient_list


import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_login.domain.model.ProfileType
import com.example.medisanedemo.feature_patient.domain.model.SuperviseRequestDto
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState
import com.example.medisanedemo.feature_supervisor.domain.use_case.SupervisorUseCases
import com.example.medisanedemo.feature_supervisor.presentation.util.SupervisorUiUtils.convertPatientDtoList
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject

@HiltViewModel
class SelectPatientViewModel @Inject constructor(
    private val supervisorUseCases: SupervisorUseCases,
    savedStateHandle: SavedStateHandle
): ViewModel() {

    private val _state = mutableStateOf(SelectPatientState())
    val state: State<SelectPatientState> = _state

    private val responseEventChannel = Channel<ResponseEvent>() // channel with only one observer
    val responseEvents = responseEventChannel.receiveAsFlow() // receiveAsFlow returns an immutable flow, will be observed by the ui

    init {
        val accountId = savedStateHandle.get<Int>("accountId")!!
        val profileId = savedStateHandle.get<Int>("profileId")!!
        val token = savedStateHandle.get<String>("token")!!
        val profileName = savedStateHandle.get<String>("profileName")!!

        _state.value = state.value.copy(
            profile = Profile(
                profileId = profileId,
                profileName = profileName,
                type = ProfileType.SUPERVISOR
            ),
            accountId = accountId,
            token = token
        )

        setSelectPatientContent()
    }

    fun setSelectPatientContent() {
        val TAG = "SelectPatientViewModel"

        viewModelScope.launch {

            try {
                val payload = supervisorUseCases.getAllPatients.invoke(
                    token = state.value.token,
                    supervisorId = state.value.profile.profileId
                )
                val patientProfileList = convertPatientDtoList(payload)

                val awaitingRequests: List<SuperviseRequestDto> =
                    supervisorUseCases.getSuperviseRequestsUseCase.invoke(
                        token = state.value.token,
                        profileId = state.value.profile.profileId
                    ).awaitingRequests

                _state.value = state.value.copy(
                    patientProfileList = patientProfileList,
                    screenState = ScreenState.Success,
                    hasNotification = awaitingRequests.isNotEmpty(),
                    isFirstCall = false
                )


            } catch(e: IOException) {

                _state.value = state.value.copy(
                    screenState = ScreenState.Error(message = "Internet Connection Failed")
                )

            } catch(e: HttpException) {

                _state.value = state.value.copy(
                    screenState = ScreenState.Error(
                        message = "Http Error: " + e.message
                    )
                )
            }
        }
    }

    fun onEvent(event: SelectPatientUIEvent) {

        when (event) {

            is SelectPatientUIEvent.GoToPatient -> {
                viewModelScope.launch {
                    responseEventChannel.send(ResponseEvent.PatientSelected(event.profile))
                }
            }

            is SelectPatientUIEvent.ToggleAddPatientDialog -> {
                _state.value = state.value.copy(
                    isAddPatientDialogVisible = event.isVisible,
                    isAddPatientError = false,
                    addPatientErrorMessage = ""

                )
            }
            SelectPatientUIEvent.Retry -> {
                _state.value = state.value.copy(
                    screenState = ScreenState.Loading
                )

                setSelectPatientContent()
            }
            is SelectPatientUIEvent.GetPatientProfilesToAdd -> {
                viewModelScope.launch {

                    try {
                        val profilesToAddList =
                            supervisorUseCases.getAvailablePatientsToAddUseCase.invoke(
                                ownProfileId = state.value.profile.profileId,
                                token = state.value.token,
                                wantedUsername = state.value.patientToAddName
                            )

                        _state.value = state.value.copy(
                            profilesToAddList = profilesToAddList,
                            isAddPatientError = false,
                            addPatientErrorMessage = ""
                        )
                    } catch (e: IOException) {

                        _state.value = state.value.copy(
                            isAddPatientError = true,
                            addPatientErrorMessage = "Connection error."
                        )
                    } catch (e: HttpException) {

                        _state.value = state.value.copy(
                            isAddPatientError = true,
                            addPatientErrorMessage = e.message() ?: "Invalid name"
                        )
                    }
                }
            }
            is SelectPatientUIEvent.DeletePatient -> TODO()
            is SelectPatientUIEvent.SetPatientToAddName -> {

                _state.value = state.value.copy(
                    patientToAddName = event.profileName
                )
            }
            is SelectPatientUIEvent.AddPatient -> {

                try {
                    viewModelScope.launch {
                        val response = supervisorUseCases.sendSuperviseRequestUseCase(
                            patientId = event.patientId,
                            supervisorId = state.value.profile.profileId,
                            sentBy = true,
                            token = state.value.token,
                        )

                        _state.value = state.value.copy(
                            isAddPatientError = response != 1,
                            addPatientErrorMessage = if (response != 1) {
                                "Request could not be sent"
                            } else {
                                ""
                            },
                            isAddPatientDialogVisible = response != 1, // if no error, close the dialog
                        )

                        if (response == 1) {
                            state.value.snackbarHostState.showSnackbar(
                                message = "Request sent successfully.",
                            )
                        }
                    }
                } catch (e: IOException) {

                    _state.value = state.value.copy(
                        isAddPatientError = true,
                        addPatientErrorMessage = "Connection error."
                    )
                } catch (e: HttpException) {

                    _state.value = state.value.copy(
                        isAddPatientError = true,
                        addPatientErrorMessage = e.message() ?: "Http error."
                    )
                }
            }

            is SelectPatientUIEvent.GoToNotifications -> {

                _state.value = state.value.copy(
                    hasNotification = false,
                )

                viewModelScope.launch{
                    responseEventChannel.send(
                        ResponseEvent.GoToNoticationsFromSelectPatient(
                            profileId = event.profileId,
                        )
                    )
                }
            }
            is SelectPatientUIEvent.UpdateContent -> {
                setSelectPatientContent()
            }
        }
    }


    /* one time events that ViewModel sends, and the UI reads
    * we do not want to hold onto these events unlike states that are persistent
    */
    sealed class ResponseEvent {
        data class PatientSelected(val profile: Profile): ResponseEvent() // go to profile
        data class GoToNoticationsFromSelectPatient(val profileId: Int): ResponseEvent() // go to profile
    }
}