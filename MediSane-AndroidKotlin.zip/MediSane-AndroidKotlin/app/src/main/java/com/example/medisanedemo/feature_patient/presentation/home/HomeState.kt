package com.example.medisanedemo.feature_patient.presentation.home

import androidx.compose.foundation.lazy.LazyListState
import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_login.domain.model.profileDefault
import com.example.medisanedemo.feature_patient.domain.model.Medicine
import com.example.medisanedemo.feature_patient.domain.model.MedicineReport
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState
import java.time.LocalDateTime

data class HomeState(
    val screenState: ScreenState = ScreenState.Loading,
    val rowState: LazyListState = LazyListState(firstVisibleItemIndex = LocalDateTime.now().dayOfMonth - 1),
    val selectedDate: LocalDateTime = LocalDateTime.now(),
    val medicineList: List<Medicine> = listOf(),
    val medicineReportList: List<MedicineReport> = listOf(),
    val medicinesOfDay: List<Medicine> = listOf(),
    val token: String = "",
    var profile: Profile = profileDefault(), // returns a default profile


    var accountId: Int = -1, // Default val
    val isSupervisor: Boolean = false, // true if supervisor is looking a patient's homePage

    val hasNotification: Boolean = false,
)
