package com.example.medisanedemo

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.navigation
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.medisanedemo.feature_login.domain.model.Account
import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_login.presentation.login.LoginScreen
import com.example.medisanedemo.feature_login.presentation.login.LoginUIEvent
import com.example.medisanedemo.feature_login.presentation.login.LoginViewModel
import com.example.medisanedemo.feature_login.presentation.select_profile.SelectProfileScreen
import com.example.medisanedemo.feature_login.presentation.select_profile.SelectProfileScreenUIEvent
import com.example.medisanedemo.feature_login.presentation.select_profile.SelectProfileViewModel
import com.example.medisanedemo.feature_login.presentation.signup.SignupScreen
import com.example.medisanedemo.feature_login.presentation.signup.SignupUIEvent
import com.example.medisanedemo.feature_login.presentation.signup.SignupViewModel
import com.example.medisanedemo.feature_notification.MyFirebaseMessagingService
import com.example.medisanedemo.feature_patient.domain.model.Medicine
import com.example.medisanedemo.feature_patient.domain.model.MedicineReport
import com.example.medisanedemo.feature_patient.domain.model.SuperviseRequestDto
import com.example.medisanedemo.feature_patient.presentation.add_medicine.AddMedicineScreen
import com.example.medisanedemo.feature_patient.presentation.add_medicine.AddMedicineUIEvent
import com.example.medisanedemo.feature_patient.presentation.add_medicine.AddMedicineViewModel
import com.example.medisanedemo.feature_patient.presentation.add_medicine.additional_options_screen.AdditionalOptionsScreen
import com.example.medisanedemo.feature_patient.presentation.add_medicine.every_day_screen.EveryDayOptionScreen
import com.example.medisanedemo.feature_patient.presentation.add_medicine.every_x_day_screen.EveryXDayOptionScreen
import com.example.medisanedemo.feature_patient.presentation.home.HomeScreen
import com.example.medisanedemo.feature_patient.presentation.home.HomeUiEvent
import com.example.medisanedemo.feature_patient.presentation.home.HomeViewModel
import com.example.medisanedemo.feature_patient.presentation.add_medicine.select_frequency_screen.SelectFrequencyScreen
import com.example.medisanedemo.feature_patient.presentation.add_medicine.specific_days_of_week_screen.SpecificDaysOfWeekScreen
import com.example.medisanedemo.feature_patient.presentation.help.HelpScreen
import com.example.medisanedemo.feature_patient.presentation.home.components.Label
import com.example.medisanedemo.feature_patient.presentation.my_medicines.MyMedicinesScreen
import com.example.medisanedemo.feature_patient.presentation.my_medicines.MyMedicinesUIEvent
import com.example.medisanedemo.feature_patient.presentation.my_medicines.MyMedicinesViewModel
import com.example.medisanedemo.feature_patient.presentation.notification.NotificationScreen
import com.example.medisanedemo.feature_patient.presentation.notification.NotificationUIEvent
import com.example.medisanedemo.feature_patient.presentation.notification.NotificationViewModel
import com.example.medisanedemo.feature_supervisor.domain.model.ProfileToAddDto
import com.example.medisanedemo.feature_supervisor.presentation.patient_list.SelectPatientScreen
import com.example.medisanedemo.feature_supervisor.presentation.patient_list.SelectPatientUIEvent
import com.example.medisanedemo.feature_supervisor.presentation.patient_list.SelectPatientViewModel
import com.example.medisanedemo.navigation.util.Screen
import com.example.medisanedemo.ui.theme.MyTheme
import dagger.hilt.android.AndroidEntryPoint
import java.time.LocalDateTime
import java.time.LocalTime

//comment

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MyFirebaseMessagingService.getFCMToken()
        setContent {
            MyTheme (dynamicColor = false) {

                val navController = rememberNavController()

                NavHost(
                    navController = navController,
                    startDestination = Screen.LoginScreen.route
                ) {
                    composable(route = Screen.LoginScreen.route) {

                        val loginViewModel: LoginViewModel = hiltViewModel()
                        val loginState = loginViewModel.state.value
                        val loginResponseEvents = loginViewModel.responseEvents
                        val TAG = "LoginScreenInMain"

                        LoginScreen(
                            state = loginState,
                            responseEvents = loginResponseEvents,
                            onUserLoggedIn = { account: Account ->
                                Log.d(TAG, "accountId: " + account.id + " token: " + account.token)
                                navController.navigate(Screen.SelectProfileScreen.withArgs(account.token, account.id.toString()))
                            },
                            onUsernameValueChange = { usernameInput: String ->
                                loginViewModel.onEvent(
                                    LoginUIEvent.SetUsername(usernameInput)
                                )
                            },
                            onPasswordValueChange = { passwordInput: String ->
                                loginViewModel.onEvent(LoginUIEvent.SetPassword(passwordInput))

                            },
                            onVisibilityButtonPressed = {
                                loginViewModel.onEvent(LoginUIEvent.TogglePasswordVisibility)
                            },
                            onSignupButtonPressed = {
                                loginViewModel.onEvent(LoginUIEvent.SignupButtonPressed)
                            },
                            onLoginButtonPressed = {
                                loginViewModel.onEvent(LoginUIEvent.LoginButtonPressed)
                            },
                            onNavigateToSignup = {
                                navController.navigate(Screen.SignupScreen.route)
                            }
                        )
                    }
                    composable(
                        route = Screen.SignupScreen.route
                    ) {
                        val signupViewModel: SignupViewModel = hiltViewModel()
                        val signupState = signupViewModel.state.value
                        val signupResponseEvents = signupViewModel.responseEvents

                        SignupScreen(
                            state = signupState,
                            responseEvents = signupResponseEvents,
                            onUsernameValueChange = { usernameInput: String ->
                                signupViewModel.onEvent(SignupUIEvent.SetUsername(username = usernameInput))

                            },
                            onPasswordValueChange = { passwordInput: String ->
                                signupViewModel.onEvent(SignupUIEvent.SetPassword(password = passwordInput))

                            },
                            onVisibilityButtonPressed = {
                                signupViewModel.onEvent(SignupUIEvent.TogglePasswordVisibility)
                            },
                            onUserSignedInAndLoggedIn = { // if we decide to go to log user in
                                //navController.navigate(Screen.SelectProfileScreen.route)
                            },
                            onUserSignedIn = { // if we decide not to log user in
                                navController.navigate(Screen.LoginScreen.route)
                            },
                            onLoginButtonPressed = {
                                navController.navigate(Screen.LoginScreen.route)
                            },
                            onSignupButtonPressed = {
                                signupViewModel.onEvent(SignupUIEvent.SignupButtonPressed)
                            }
                        )
                    }
                    composable(
                        route = Screen.SelectPatientScreen.route + "/{token}" + "/{accountId}" + "/{profileId}" + "/{profileName}", // supervisor's accountId, profileId and name
                        arguments = listOf(
                            navArgument(name = "token") {
                                type = NavType.StringType
                                nullable = false
                            },
                            navArgument(name = "accountId") {
                                type = NavType.IntType
                                nullable = false
                            },
                            navArgument(name = "profileId") {
                                type = NavType.IntType
                                nullable = false
                            },
                            navArgument(name = "profileName") {
                                type = NavType.StringType
                                nullable = false
                            }
                        )
                    ) {
                        val selectPatientViewModel: SelectPatientViewModel = hiltViewModel()
                        val selectPatientState = selectPatientViewModel.state.value
                        val selectPatientResponseEvent = selectPatientViewModel.responseEvents
                        SelectPatientScreen(
                            state = selectPatientState,
                            responseEvents = selectPatientResponseEvent,
                            currentBackStackEntry = navController.currentBackStackEntryAsState().value,
                            onRetry = {
                                selectPatientViewModel.onEvent(SelectPatientUIEvent.Retry)
                                      },
                            onDismissAddPatient = {
                                selectPatientViewModel.onEvent(SelectPatientUIEvent.ToggleAddPatientDialog(isVisible = false))
                            },
                            onConfirmGetPatients = {
                                selectPatientViewModel.onEvent(SelectPatientUIEvent.GetPatientProfilesToAdd)
                                                  },
                            onPatientNameToAddChange = { patientName: String ->
                                selectPatientViewModel.onEvent(SelectPatientUIEvent.SetPatientToAddName(profileName = patientName))
                            },
                            onPressedAddPatient = {
                                selectPatientViewModel.onEvent(SelectPatientUIEvent.ToggleAddPatientDialog(isVisible = true))
                                                  },
                            onNavigateToPatientProfile = { token: String, accountId: Int, profile: Profile -> // accountId is the id of the supervisor

                                navController.navigate(Screen.PatientHomeScreen.withArgs(token, accountId.toString(), profile.profileId.toString(), profile.profileName, true.toString()))

                            },
                            onPatientClick = { clickedProfile: Profile ->
                                selectPatientViewModel.onEvent(SelectPatientUIEvent.GoToPatient(clickedProfile))

                            },
                            onPressBackButton = {
                                navController.popBackStack()
                            },
                            onPressLogoutButton = {
                                navController.popBackStack(
                                    route = Screen.LoginScreen.route,
                                    inclusive = false
                                )
                            },
                            onPressNotificationButton = { profileId: Int ->
                                selectPatientViewModel.onEvent(SelectPatientUIEvent.GoToNotifications(profileId = profileId))

                            },
                            onNavigateToNotificationScreen = { token: String, profileId: Int ->

                                navController.navigate(Screen.NotificationScreen.withArgs(token, profileId.toString(), true.toString())) // true because supervisor

                            },
                            onPressedProfileToSupervise = { profileToAddDto: ProfileToAddDto ->
                                selectPatientViewModel.onEvent(SelectPatientUIEvent.AddPatient(profileToAddDto.profileId))

                            },
                            onNavigateBack = {
                                selectPatientViewModel.onEvent(SelectPatientUIEvent.UpdateContent)

                            }
                        )
                    }
                    composable(
                        route = Screen.PatientHomeScreen.route + "/{token}"  + "/{accountId}" + "/{profileId}" + "/{profileName}" + "/{isSupervisor}",
                        arguments = listOf(
                            navArgument(name = "token") {
                                type = NavType.StringType
                                nullable = false
                            },
                            navArgument(name = "accountId") {
                                type = NavType.IntType
                                nullable = false
                            },
                            navArgument(name = "profileId") {
                                type = NavType.IntType
                                nullable = false
                            },
                            navArgument(name = "profileName") {
                                type = NavType.StringType
                                nullable = false
                            },
                            navArgument(name = "isSupervisor") {
                                type = NavType.BoolType
                                nullable = false
                            }
                        )
                    ) {
                        val homeViewModel: HomeViewModel = hiltViewModel()
                        val homeState = homeViewModel.state.value
                        val homeResponseEvents = homeViewModel.responseEvents
                        val TAG = "HomeScreen"
                        HomeScreen(
                            state = homeState,
                            responseEvents = homeResponseEvents,
                            onNavigateToProfiles = { token: String, accountId: Int ->
                                navController.navigate(Screen.SelectProfileScreen.withArgs(token, accountId.toString()))
                            },
                            onNavigateToMyMedicines = { token: String, accountId: Int, profileId: Int, profileName: String, isSupervisor: Boolean ->
                                navController.navigate(Screen.MyMedicinesScreen.withArgs(token, accountId.toString(), profileId.toString(), profileName, isSupervisor.toString()))
                            },
                            onNavigateToPatientsList = { //TODO comeback after tokenization (same with the todo below)

                            },
                            onProfileClick = { accountId: Int ->
                                homeViewModel.onEvent(HomeUiEvent.GoToProfiles(accountId))
                            },
                            onMedicationClick = { profileId: Int ->
                                homeViewModel.onEvent(HomeUiEvent.GoToMyMedicines(profileId = profileId))
                            },
                            onClickLabeledReport = { medicine: Medicine, hourOfDose: LocalDateTime, label: Label ->
                                homeViewModel.onEvent(HomeUiEvent.SetMedicineReport(medicine = medicine, hourOfDose = hourOfDose, label = label))

                            },
                            onClickUnlabeledReport = { medicineReport: MedicineReport ->

                                homeViewModel.onEvent(HomeUiEvent.ResetMedicineReport(medicineReport = medicineReport))

                            },
                            onDayOfMonthSelected = { dayOfMonth: Int ->
                                homeViewModel.onEvent(HomeUiEvent.SetDayOfMonth(dayOfMonth = dayOfMonth))

                            },
                            onPreviousMonthSelected = {
                              homeViewModel.onEvent(HomeUiEvent.SetPreviousMonth)
                            },
                            onNextMonthPressed = {
                                homeViewModel.onEvent(HomeUiEvent.SetNextMonth)
                            },
                            onFloatingButtonPressed = {token:String, accountId: Int, profileId: Int, profileName: String, isSupervisor: Boolean ->
                                navController.navigate(Screen.AddMedicineGraph.withArgs(token, accountId.toString(), profileId.toString(), profileName, isSupervisor.toString()))
                            },
                            onRetry = {
                                      homeViewModel.onEvent(HomeUiEvent.Retry)
                            },
                            onPressBackButton = {
                                navController.popBackStack()
                            },
                            onPressHelpButton = {
                                navController.navigate(Screen.HelpScreen.route)
                            },
                            onPressLogoutButton = {
                                navController.popBackStack(
                                    route = Screen.LoginScreen.route,
                                    inclusive = false
                                )
                            },
                            onPressNotificationButton = { profileId: Int ->
                                homeViewModel.onEvent(HomeUiEvent.GoToNotifications(profileId = profileId))
                            },
                            onNavigateToNotificationScreen = { token: String, profileId: Int ->

                                navController.navigate(Screen.NotificationScreen.withArgs(token, profileId.toString(), false.toString())) // false because not supervisor

                            }
                        )
                    }
                    composable(
                        route = Screen.HelpScreen.route
                    ) {
                        HelpScreen(
                            onNavigateToHomeScreen = {
                                navController.popBackStack(
                                    route = Screen.HelpScreen.route,
                                    inclusive = true
                                )
                            }
                        )
                    }
                    composable(
                        route = Screen.NotificationScreen.route + "/{token}" + "/{profileId}" + "/{isSupervisor}",
                        arguments = listOf(
                            navArgument(name = "token") {
                                type = NavType.StringType
                                nullable = false
                            },
                            navArgument(name = "profileId") {
                                type = NavType.IntType
                                nullable = false
                            },
                            navArgument(name = "isSupervisor") {
                                type = NavType.BoolType
                                nullable = false
                            },
                        )
                    ) {

                        val notificationViewModel: NotificationViewModel = hiltViewModel()
                        val notificationState = notificationViewModel.state.value
                        val notificationResponseEvents = notificationViewModel.responseEvents
                        NotificationScreen(
                            screenState = notificationState.screenState,
                            snackbarHostState = notificationState.snackbarHostState,
                            awaitingRequestList = notificationState.awaitingRequestList,
                            addSupervisionErrorMessage = notificationState.addSupervisionErrorMessage,
                            isAddSupervisorDialogVisible = notificationState.isAddSupervisionDialogVisible,
                            isAddSupervisionError = notificationState.isAddSupervisionError,
                            profilesToAddList = notificationState.profilesToAddList,
                            supervisionToAddName = notificationState.supervisionToAddName,
                            isSupervisor = notificationState.isSupervisor,
                            onAddSupervisionPressed = {
                                notificationViewModel.onEvent(NotificationUIEvent.ToggleAddSupervisionDialog(isVisible = true))
                                                      },
                            onPressedProfileToSupervise = {profileToAddDto: ProfileToAddDto ->
                                notificationViewModel.onEvent(NotificationUIEvent.AddSupervision(profileToAddDto.profileId))

                            },
                            onConfirmGetSupervisions = {
                                notificationViewModel.onEvent(NotificationUIEvent.GetSupervisionProfilesToAdd)
                            },
                            onDismissAddSupervision = {
                                notificationViewModel.onEvent(NotificationUIEvent.ToggleAddSupervisionDialog(isVisible = false))
                            },
                            onSupervisionNameChange = {supervisionName: String ->
                                notificationViewModel.onEvent(NotificationUIEvent.SetSupervisionToAddName(username = supervisionName))

                            },
                            onBackButtonPressed = {
                                navController.popBackStack()
                                                  },
                            onRetry = {
                                notificationViewModel.onEvent(NotificationUIEvent.Retry)
                                      },
                            onDenyRequest = { superviseRequestDto: SuperviseRequestDto ->

                                notificationViewModel.onEvent(NotificationUIEvent.DenyRequest(deniedRequest = superviseRequestDto))
                            },
                            onAcceptRequest = {requestDto: SuperviseRequestDto ->
                                notificationViewModel.onEvent(NotificationUIEvent.AcceptRequest(requestDto))
                            },
                        )

                    }
                    composable(
                        route = Screen.MyMedicinesScreen.route + "/{token}"  + "/{accountId}" + "/{profileId}" + "/{profileName}" + "/{isSupervisor}",
                        arguments = listOf(
                            navArgument(name = "token") {
                                type = NavType.StringType
                                nullable = false
                            },
                            navArgument(name = "accountId") {
                                type = NavType.IntType
                                nullable = false
                            },
                            navArgument(name = "profileId") {
                                type = NavType.IntType
                                nullable = false
                            },
                            navArgument(name = "profileName") {
                                type = NavType.StringType
                                nullable = false
                            },
                            navArgument(name = "isSupervisor") {
                                type = NavType.BoolType
                                nullable = false
                            }
                        )
                    ) {
                        val myMedicinesViewModel: MyMedicinesViewModel = hiltViewModel()
                        val myMedicinesState = myMedicinesViewModel.state.value
                        val myMedicinesResponseEvents = myMedicinesViewModel.responseEvents

                        MyMedicinesScreen(
                            isDialogVisible = myMedicinesState.isMedicineInfoDialogVisible,
                            responseEvents = myMedicinesResponseEvents,
                            medicineList = myMedicinesState.medicineList,
                            medicineInfoList = myMedicinesState.medicineInfoList,
                            medicineReportList = myMedicinesState.medicineReportList,
                            clashList = myMedicinesState.clashList,
                            onMedicineClick = { medicineList: List<Medicine> ->
                                myMedicinesViewModel.onEvent(MyMedicinesUIEvent.PressedOnMedicineColumn(medicineList = medicineList))

                                              },
                            onSegmentedButtonClick = {selectedIndex: Int ->
                                myMedicinesViewModel.onEvent(MyMedicinesUIEvent.PressedOnSegmentedButton(index = selectedIndex))
                                                     },
                            onPressBackButton = {
                                navController.popBackStack()
                            },
                            onPressLogoutButton = {
                                navController.popBackStack(
                                    route = Screen.LoginScreen.route,
                                    inclusive = false
                                )
                            },
                            onPressEditMedicine = { medicine: Medicine ->
                                myMedicinesViewModel.onEvent(MyMedicinesUIEvent.PressedOnEditMedicine(medicine = medicine))
                            },
                            onNavigateToEditMedicine = { token: String, accountId: Int, profileId: Int, profileName: String, isSupervisor: Boolean, medicineName: String ->
                                navController.navigate(Screen.AddMedicineGraph.withArgs(token, accountId.toString(), profileId.toString(), profileName, isSupervisor.toString()) + "?medicineName=$medicineName")
                            },
                            onPressDeleteMedicine = {medicine: Medicine ->
                                myMedicinesViewModel.onEvent(MyMedicinesUIEvent.PressedOnDeleteMedicine(medicine = medicine))

                            },
                            onDismissMedicineInfoDialog = {
                                myMedicinesViewModel.onEvent(MyMedicinesUIEvent.ToggleMedicineInfoDialog(isVisible = false))
                            },
                            onRetry ={
                                myMedicinesViewModel.onEvent(MyMedicinesUIEvent.Retry)

                            },
                            token = it.arguments!!.getString("token")!!,
                            accountId = it.arguments!!.getInt("accountId"),
                            profileId = it.arguments!!.getInt("profileId"),
                            profileName = it.arguments!!.getString("profileName")!!,
                            isSupervisor = it.arguments!!.getBoolean("isSupervisor"),
                            screenState = myMedicinesState.screenState,
                            selectedIndex = myMedicinesState.selectedButtonIndex,
                        )

                    }
                    composable(
                        route = Screen.SelectProfileScreen.route + "/{token}" + "/{accountId}",
                        arguments = listOf(
                            navArgument(name = "token") {
                                type = NavType.StringType
                                nullable = false
                            },
                            navArgument(name = "accountId") {
                                type = NavType.IntType
                                nullable = false
                            }
                        )
                        ) {
                        val selectProfileViewModel: SelectProfileViewModel = hiltViewModel()
                        val selectProfileState = selectProfileViewModel.state.value
                        val selectProfileResponseEvents = selectProfileViewModel.responseEvents
                        SelectProfileScreen(
                            state = selectProfileState,
                            responseEvents = selectProfileResponseEvents,
                            onNavigateToPatientProfile = { token: String, accountId: Int, profile: Profile ->
                                navController.navigate(Screen.PatientHomeScreen.withArgs(token, accountId.toString(), profile.profileId.toString(), profile.profileName, false.toString()))
                            },
                            onNavigateToSupervisorProfile = { token: String, accountId: Int, profile: Profile ->
                                navController.navigate(Screen.SelectPatientScreen.withArgs(token, accountId.toString(), profile.profileId.toString(), profile.profileName))
                            },
                            onProfileClick = { clickedProfile: Profile ->
                                selectProfileViewModel.onEvent(SelectProfileScreenUIEvent.GoToProfile(clickedProfile))

                            },
                            onPressedDeleteProfile = {clickedProfile: Profile ->
                                selectProfileViewModel.onEvent(SelectProfileScreenUIEvent.DeleteProfile(profile = clickedProfile))
                            },
                            onPressedAddProfile = {
                                selectProfileViewModel.onEvent(SelectProfileScreenUIEvent.ToggleAddProfileDialog(isVisible = true))
                            },
                            onDismissAddProfile = {
                                selectProfileViewModel.onEvent(SelectProfileScreenUIEvent.ToggleAddProfileDialog(isVisible = false))
                            },
                            onConfirmAddProfile = {
                                selectProfileViewModel.onEvent(SelectProfileScreenUIEvent.AddProfile)
                            },
                            onProfileNameToAddChange = {profileName: String ->
                                selectProfileViewModel.onEvent(SelectProfileScreenUIEvent.SetProfileToAddName(profileName = profileName))
                            },
                            onSegmentedButtonClick = {selectedIndex: Int ->
                                selectProfileViewModel.onEvent(SelectProfileScreenUIEvent.PressedOnSegmentedButton(index = selectedIndex))
                            },
                            onNewTokenAcquired = {token: String ->

                                selectProfileViewModel.onEvent(SelectProfileScreenUIEvent.NewTokenAcquired(token = token))

                            },
                            onRetry = {
                                selectProfileViewModel.onEvent(SelectProfileScreenUIEvent.Retry)
                            },
                        )
                    }

                    // add medicine nested navigation graph
                    navigation(
                        startDestination = Screen.AddMedicineScreen.route + "/{token}" + "/{accountId}" + "/{profileId}" + "/{profileName}" + "/{isSupervisor}"  + "?medicineName={medicineName}",
                        route = Screen.AddMedicineGraph.route + "/{token}" + "/{accountId}" + "/{profileId}" + "/{profileName}" + "/{isSupervisor}"  + "?medicineName={medicineName}",
                        arguments = listOf(
                            navArgument(name = "token") {
                                type = NavType.StringType
                                nullable = false
                            },
                            navArgument(name = "accountId") {
                                type = NavType.IntType
                                nullable = false
                            },
                            navArgument(name = "profileId") {
                                type = NavType.IntType
                                nullable = false
                            },
                            navArgument(name = "profileName") {
                                type = NavType.StringType
                                nullable = false
                            },
                            navArgument(name = "isSupervisor") {
                                type = NavType.BoolType
                                nullable = false
                            },
                            navArgument(name = "medicineName") {
                                type = NavType.StringType
                                nullable = true
                            }
                        )
                    ) {
                        composable(
                            route = Screen.AddMedicineScreen.route + "/{token}" + "/{accountId}" + "/{profileId}" + "/{profileName}" + "/{isSupervisor}" + "?medicineName={medicineName}",
                            arguments = listOf(
                                navArgument(name = "token") {
                                    type = NavType.StringType
                                    nullable = false
                                },
                                navArgument(name = "accountId") {
                                    type = NavType.IntType
                                    nullable = false
                                },
                                navArgument(name = "profileId") {
                                    type = NavType.IntType
                                    nullable = false
                                },
                                navArgument(name = "profileName") {
                                    type = NavType.StringType
                                    nullable = false
                                },
                                navArgument(name = "isSupervisor") {
                                    type = NavType.BoolType
                                    nullable = false
                                },
                                navArgument(name = "medicineName") {
                                    type = NavType.StringType
                                    nullable = true
                                }
                            )
                        ) {
                            val sharedViewModel = it.sharedViewModel<AddMedicineViewModel>(navController = navController)
                            val sharedViewModelState = sharedViewModel.state.value
                            val sharedViewModelResponseEvents = sharedViewModel.responseEvents

                            //val TAG = "AddMedicineNav"
                            AddMedicineScreen(
                                state = sharedViewModelState,
                                responseEvents = sharedViewModelResponseEvents,
                                onMedicineInputChange = {medicineName: String ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetMedicineName(medicineName = medicineName))
                                },
                                onPressInputColumn = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.PressedOnInputColumn)
                                },
                                onPressBackButton = {
                                  navController.popBackStack()
                                },
                                onPressLogoutButton = {
                                    navController.popBackStack(
                                        route = Screen.LoginScreen.route,
                                        inclusive = false
                                    )
                                },
                                onNavigateToSelectFrequencyScreen = {
                                    navController.navigate(Screen.SelectMedicineFrequencyScreen.route)
                                },
                                onMedicineClick = {medicineName: String ->
                                                  sharedViewModel.onEvent(AddMedicineUIEvent.PressedOnQueryMedicineColumn(medicineName = medicineName))

                                },

                            )

                        }
                        composable(
                            route = Screen.SelectMedicineFrequencyScreen.route
                        ) {
                            val TAG = "SelectFrequencyNav"
                            val sharedViewModel = it.sharedViewModel<AddMedicineViewModel>(navController = navController)
                            //val sharedViewModelState = sharedViewModel.state.value
                            val sharedViewModelResponseEvents = sharedViewModel.responseEvents


                            SelectFrequencyScreen(
                                responseEvents = sharedViewModelResponseEvents,
                                onPressEverydayColumn = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.PressedOnEverydayColumn)
                                },
                                onPressEveryXDayColumn = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.PressedOnEveryXDayColumn)
                                },
                                onPressSpecificDaysOfWeekColumn = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.PressedOnSpecificDaysOfWeekColumn)
                                },
                                onPressBackButton = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.PressedOnNavigateBack)

                                },
                                onPressLogoutButton = {
                                    navController.popBackStack(
                                        route = Screen.LoginScreen.route,
                                        inclusive = false
                                    )
                                },
                                onNavigateToEverydayScreen = {
                                    navController.navigate(Screen.EverydayOptionMedicineScreen.route)
                                },
                                onNavigateToEveryXDayScreen = {
                                    navController.navigate(Screen.EveryXDayOptionMedicineScreen.route)
                                },
                                onNavigateToSpecificDaysOfWeekScreen = {
                                    navController.navigate(Screen.SpecificDaysOfWeekMedicineScreen.route)
                                },
                                onNavigateBackToAddMedicineScreen = {
                                    navController.popBackStack()
                                },
                                onNavigateBackToMedicineInfo = { token: String, accountId: Int, profileId: Int, profileName: String, isSupervisor: Boolean, medicineName: String ->
                                    navController.popBackStack(
                                        route = Screen.AddMedicineGraph.withArgs(token, accountId.toString(), profileId.toString(), profileName, isSupervisor.toString()) + "?medicineName=$medicineName",
                                        inclusive = true
                                    )

                                }
                            )

                        }
                        composable(
                            route = Screen.EverydayOptionMedicineScreen.route
                        ) {
                            val sharedViewModel = it.sharedViewModel<AddMedicineViewModel>(navController = navController)
                            val sharedViewModelState = sharedViewModel.state.value

                            EveryDayOptionScreen(
                                state = sharedViewModelState,
                                onDismissDatePicker = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleDatePicker(isVisible = false))
                                                      },
                                onConfirmDatePicker = { date: LocalDateTime ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetOneStartDate(date))
                                },
                                onDismissTimePicker = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleTimePicker(isVisible = false))
                                },
                                onConfirmTimePicker = { hour: LocalTime ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetHourValue(hour))
                                },
                                onDatePickerToggle = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleDatePicker(isVisible = true))
                                                     },
                                onTimePerDayDropdownExpandedStateChange = { isExpanded: Boolean ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleTimesPerDayDropdown(isExpanded = isExpanded))
                                },
                                onTimePerDayDropdownDismissRequest = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleTimesPerDayDropdown(isExpanded = false))
                                                           },
                                onDoseAmountDropdownDismissRequest = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleDoseAmountDropdown(isExpanded = false))
                                                                     },
                                onDoseAmountDropdownExpandedStateChange = { isExpanded: Boolean ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleDoseAmountDropdown(isExpanded = isExpanded))
                                                                          },
                                onDoseAmountValueChange = { doseAmount: Int ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetDoseAmount(doseAmount = doseAmount))
                                },
                                onPressTimeColumn = { selectedTimeIndex: Int ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.PressedOnTimeColumn(selectedTimeIndex))
                                },
                                onTimesPerDayChange = { timesPerDay: Int ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetTimesPerDay(timesPerDay))
                                },
                                onPressBackButton = {
                                    navController.popBackStack()
                                },
                                onPressLogoutButton = {
                                    navController.popBackStack(
                                        route = Screen.LoginScreen.route,
                                        inclusive = false
                                    )
                                },
                                onPressSubmitButton = {
                                    navController.navigate(Screen.AdditionalOptionsScreen.route)
                                }
                            )

                        }
                        composable(
                            route = Screen.SpecificDaysOfWeekMedicineScreen.route
                        ) {
                            val sharedViewModel = it.sharedViewModel<AddMedicineViewModel>(navController = navController)
                            val sharedViewModelState = sharedViewModel.state.value
                            val sharedViewModelResponseEvents = sharedViewModel.responseEvents

                            SpecificDaysOfWeekScreen(
                                state = sharedViewModelState,
                                responseEvents = sharedViewModelResponseEvents,
                                onDismissDatePicker = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleDatePicker(isVisible = false))
                                },
                                onConfirmDatePicker = { date: LocalDateTime ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetOneStartDate(date)) },
                                onDismissTimePicker = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleTimePicker(isVisible = false))
                                                      },
                                onConfirmTimePicker = { hour: LocalTime ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetHourValue(hour)) },
                                onDatePickerToggle = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleDatePicker(isVisible = true))
                                                     },
                                onTimePerDayDropdownExpandedStateChange = { isExpanded: Boolean ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleTimesPerDayDropdown(isExpanded = isExpanded))
                                },
                                onTimePerDayDropdownDismissRequest = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleTimesPerDayDropdown(isExpanded = false))
                                },
                                onDoseAmountDropdownExpandedStateChange = { isExpanded: Boolean ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleDoseAmountDropdown(isExpanded = isExpanded))
                                },
                                onDoseAmountDropdownDismissRequest = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleDoseAmountDropdown(isExpanded = false))
                                },
                                onTimesPerDayChange = { timesPerDay: Int ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetTimesPerDay(timesPerDay))
                                },
                                onDoseAmountValueChange = { doseAmount: Int ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetDoseAmount(doseAmount = doseAmount))
                                },
                                onPressTimeColumn = { selectedTimeIndex: Int ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.PressedOnTimeColumn(selectedTimeIndex))
                                },
                                onPressBackButton = {
                                    navController.popBackStack()
                                },
                                onPressLogoutButton = {
                                    navController.popBackStack(
                                        route = Screen.LoginScreen.route,
                                        inclusive = false
                                    )
                                },
                                onPressSubmitButton = {
                                                      sharedViewModel.onEvent(AddMedicineUIEvent.PressedOnSubmitWithSpecificWeekdays)
                                                      },
                                onSelectWeekDay = { weekDay: Int ->
                                                  sharedViewModel.onEvent(AddMedicineUIEvent.AddRemoveWeekDay(weekDay = weekDay))
                                                  },
                                onNavigateToAdditionalOptionsScreen = {
                                    navController.navigate(Screen.AdditionalOptionsScreen.route)
                                }
                            )


                        }

                        composable(
                            route = Screen.AdditionalOptionsScreen.route
                        ) {
                            val sharedViewModel = it.sharedViewModel<AddMedicineViewModel>(navController = navController)
                            val sharedViewModelState = sharedViewModel.state.value
                            val sharedViewModelResponseEvents = sharedViewModel.responseEvents

                            AdditionalOptionsScreen(
                                state = sharedViewModelState,
                                responseEvents = sharedViewModelResponseEvents,
                                onSubmitMedicine = { token: String, accountId: Int, profileId: Int, profileName: String, isSupervisor: Boolean ->
                                    navController.navigate(Screen.PatientHomeScreen.withArgs(token, accountId.toString(), profileId.toString(), profileName, isSupervisor.toString()))
                                                   },
                                onPressAddUsageDescription = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleAddUsageDescriptionDialog(isVisible = true))
                                },
                                onPressSetEndDate = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleEndDatePicker(isVisible = true))
                                },
                                onPressSetRemindersDescription = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleSetRemindersDialog(isVisible = true))
                                                                 },
                                onPressSetRemainingAmount = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleRemainingAmountDialog(isVisible = true))
                                },
                                onPressedBackButton = {
                                    navController.popBackStack()
                                },
                                onPressLogoutButton = {
                                    navController.popBackStack(
                                        route = Screen.LoginScreen.route,
                                        inclusive = false
                                    )
                                },
                                onPressSubmitButton = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.PressedOnSubmit)
                                },
                                onUsageDescriptionChange = { usageDescription: String ->
                                                           sharedViewModel.onEvent(AddMedicineUIEvent.SetUsageDescription(usageDescription = usageDescription))
                                },
                                onDismissUsageDescription = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleAddUsageDescriptionDialog(isVisible = false))
                                },
                                onConfirmUsageDescription = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleAddUsageDescriptionDialog(isVisible = false))
                                },
                                onDismissEndDatePicker = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleEndDatePicker(isVisible = false))
                                },
                                onConfirmEndDatePicker = { endDate: LocalDateTime ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetEndDate(endDate = endDate))
                                },
                                onDismissRemainingAmount = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleRemainingAmountDialog(isVisible = false))
                                },
                                onConfirmRemainingAmount = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleRemainingAmountDialog(isVisible = false))
                                },
                                onRemainingAmountValueChange = { remainingAmount: String ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetRemainingAmount(remainingAmountDisplay = remainingAmount))

                                },
                                onDismissAlertDialog = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.CloseAlertDialog)
                                },
                                onDismissSetNotification = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleSetRemindersDialog(isVisible = false))
                                },
                                onNotificationValueChange = { hasNotification: Boolean ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetHasNotification(hasNotification = hasNotification))
                                }
                            )

                        }
                        composable(
                            route = Screen.EveryXDayOptionMedicineScreen.route
                        ) {
                            val sharedViewModel = it.sharedViewModel<AddMedicineViewModel>(navController = navController)
                            val sharedViewModelState = sharedViewModel.state.value
                            val sharedViewModelResponseEvents = sharedViewModel.responseEvents

                            EveryXDayOptionScreen(
                                state = sharedViewModelState,
                                onDismissDatePicker = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleDatePicker(isVisible = false))
                                                      },
                                onConfirmDatePicker = { date: LocalDateTime ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetOneStartDate(date))
                                },
                                onDismissTimePicker = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleTimePicker(isVisible = false))
                                },
                                onConfirmTimePicker = {hour: LocalTime ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetHourValue(hour))
                                },
                                onDatePickerToggle = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleDatePicker(isVisible = true))
                                },
                                onTimePerDayDropdownExpandedStateChange = { isExpanded: Boolean ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleTimesPerDayDropdown(isExpanded = isExpanded))
                                },
                                onTimePerDayDropdownDismissRequest = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleTimesPerDayDropdown(isExpanded = false))
                                },
                                onDoseAmountDropdownDismissRequest = {
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleDoseAmountDropdown(isExpanded = false))
                                },
                                onDoseAmountDropdownExpandedStateChange = { isExpanded: Boolean ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.ToggleDoseAmountDropdown(isExpanded = isExpanded))
                                                                          },
                                onDoseAmountValueChange = { doseAmount: Int ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetDoseAmount(doseAmount = doseAmount))
                                },
                                onPressTimeColumn = { selectedTimeIndex: Int ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.PressedOnTimeColumn(selectedTimeIndex))
                                },
                                onTimesPerDayChange = { timesPerDay: Int ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetTimesPerDay(timesPerDay))
                                },
                                onPressBackButton = {
                                    navController.popBackStack()
                                },
                                onPressLogoutButton = {
                                    navController.popBackStack(
                                        route = Screen.LoginScreen.route,
                                        inclusive = false
                                    )
                                },
                                onPressSubmitButton = {
                                    navController.navigate(Screen.AdditionalOptionsScreen.route)
                                },
                                onFrequencyChange = {frequency: String ->
                                    sharedViewModel.onEvent(AddMedicineUIEvent.SetFrequency(frequencyDisplay = frequency))
                                }
                            )

                        }
                    }
                }


            }
        }
    }
}

// extend NavBackStackEntry to use a shared viewModel
@Composable
inline fun <reified T: ViewModel> NavBackStackEntry.sharedViewModel(navController: NavController): T {
    val navGraphRoute = destination.parent?.route ?: return hiltViewModel()
    val parentEntry = remember(this) {
        navController.getBackStackEntry(navGraphRoute)
    }

    return hiltViewModel(parentEntry)
}