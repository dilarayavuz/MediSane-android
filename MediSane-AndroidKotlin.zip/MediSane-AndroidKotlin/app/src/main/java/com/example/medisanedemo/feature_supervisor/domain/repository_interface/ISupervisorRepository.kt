package com.example.medisanedemo.feature_supervisor.domain.repository_interface


import com.example.medisanedemo.feature_patient.domain.model.AwaitingRequestsDto
import com.example.medisanedemo.feature_patient.domain.model.ProfileRequestNotificationInfo
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableProfilesToAddDto
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableSupervisionInfo
import com.example.medisanedemo.feature_supervisor.domain.model.PatientDto
import com.example.medisanedemo.feature_supervisor.domain.model.SuperviseRequestInfo
import com.example.medisanedemo.feature_supervisor.domain.model.SupervisorInfo

interface ISupervisorRepository {

    suspend fun getPatients(supervisorInfo: SupervisorInfo): List<PatientDto>

    suspend fun getPatientProfilesToAdd(availableSupervisionInfo: AvailableSupervisionInfo): AvailableProfilesToAddDto

    suspend fun sendSuperviseRequest(superviseRequestInfo: SuperviseRequestInfo): Int

    suspend fun getSupervisionRequests(profileRequestNotificationInfo: ProfileRequestNotificationInfo): AwaitingRequestsDto
}