package com.example.medisanedemo.feature_notification

import android.text.TextUtils
import android.util.Log
import com.google.android.gms.tasks.Task
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage


class MyFirebaseMessagingService : FirebaseMessagingService()  {
    val tag:String="FCMToken"
    override fun onNewToken(token: String) {
        Log.d(tag, "FCMToken: $token")
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {

        // Check if message contains a data payload.
        if (remoteMessage.data.isNotEmpty()) {
            Log.d("MessagePayload", "Message data payload: ${remoteMessage.data}")
            val notish = MyNotification(applicationContext, remoteMessage.data["title"].toString(), remoteMessage.data["body"].toString(), remoteMessage.data["scheduledTime"].toString())
            val isScheduled = remoteMessage.data["isScheduled"].toBoolean()

            // Check whether notification is scheduled or not
            if (isScheduled) {
                notish.scheduleNotification()
            } else {
                notish.showNotification()
            }

        }
    }

    companion object {
        fun getFCMToken() {
            FirebaseMessaging.getInstance().token.addOnSuccessListener { token: String ->
                if (!TextUtils.isEmpty(token)) {
                    Log.d(
                        "phoneFCMTOKEN",
                        "retrieve token successful : $token"
                    )
                } else {
                    Log.w("phoneFCMTOKEN", "token should not be null...")
                }
            }.addOnFailureListener { e: Exception? -> }.addOnCanceledListener {}
                .addOnCompleteListener { task: Task<String> ->
                    Log.v(
                        "phoneFCMTOKEN",
                        "This is the token : " + task.result
                    )
                }
        }
    }
}