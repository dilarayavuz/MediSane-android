package com.example.medisanedemo.feature_patient.domain.use_case

import com.example.medisanedemo.feature_patient.domain.model.NotificationInfo
import com.example.medisanedemo.feature_patient.domain.repository_interface.IMedicineRepository
import javax.inject.Inject

class SendPushNotificationUseCase @Inject constructor(
    private val repository: IMedicineRepository
) {

    /*
  * allows us to call this class as a function
  * */
    suspend operator fun invoke(
        medicineName: String,
        startDateList: List<String>,
    ) {
        repository.sendPushNotification(
            NotificationInfo(
                startDateList = startDateList,
                medicineName = medicineName,
            )
        )
    }
}