package com.example.medisanedemo.feature_patient.domain.use_case


import com.example.medisanedemo.feature_patient.domain.model.MedicineReportInfo
import com.example.medisanedemo.feature_patient.domain.repository_interface.IMedicineRepository
import javax.inject.Inject

class AddMedicineReportUseCase @Inject constructor(
    private val repository: IMedicineRepository
) {

    /*
    * allows us to call this class as a function
    * */
    suspend operator fun invoke(
        medicineReportInfo: MedicineReportInfo
    ) {
        repository.addMedicineReport(medicineReportInfo)
    }
}