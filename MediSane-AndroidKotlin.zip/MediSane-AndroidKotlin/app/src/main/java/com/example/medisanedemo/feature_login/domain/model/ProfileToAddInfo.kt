package com.example.medisanedemo.feature_login.domain.model

data class ProfileToAddInfo(
    val token: String,
    val profileName: String,
    val type: Boolean // if supervisor --> true
)
