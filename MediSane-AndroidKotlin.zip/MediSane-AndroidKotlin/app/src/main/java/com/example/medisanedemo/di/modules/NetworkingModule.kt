package com.example.medisanedemo.di.modules


import com.example.medisanedemo.di.util.Consts.BASE_URL_EMULATOR
import com.example.medisanedemo.feature_login.data.data_source.LoginApiService
import com.example.medisanedemo.feature_login.data.repository_implementation.LoginRepositoryImpl
import com.example.medisanedemo.feature_login.domain.repository_interface.ILoginRepository
import com.example.medisanedemo.feature_login.domain.use_case.AddNewProfileUseCase
import com.example.medisanedemo.feature_login.domain.use_case.DeleteProfileUseCase
import com.example.medisanedemo.feature_login.domain.use_case.GetAllProfilesUseCase
import com.example.medisanedemo.feature_login.domain.use_case.LogUserInUseCase
import com.example.medisanedemo.feature_login.domain.use_case.LoginUseCases
import com.example.medisanedemo.feature_login.domain.use_case.SignUserUpUseCase
import com.example.medisanedemo.feature_patient.data.data_source.PatientApiService
import com.example.medisanedemo.feature_patient.data.repository_implementation.MedicineRepositoryImpl
import com.example.medisanedemo.feature_patient.data.repository_implementation.PatientRepositoryImpl
import com.example.medisanedemo.feature_patient.domain.repository_interface.IMedicineRepository
import com.example.medisanedemo.feature_patient.domain.repository_interface.IPatientRepository
import com.example.medisanedemo.feature_patient.domain.use_case.AddMedicineReportUseCase
import com.example.medisanedemo.feature_patient.domain.use_case.AddMedicineUseCase
import com.example.medisanedemo.feature_patient.domain.use_case.GetAllMedicinesUseCase
import com.example.medisanedemo.feature_patient.domain.use_case.GetAvailableSupervisorsToAddUseCase
import com.example.medisanedemo.feature_patient.domain.use_case.GetMedicineReportUseCase
import com.example.medisanedemo.feature_patient.domain.use_case.GetSupervisionRequestsUseCase
import com.example.medisanedemo.feature_patient.domain.use_case.PatientUseCases
import com.example.medisanedemo.feature_patient.domain.use_case.SendPushNotificationUseCase
import com.example.medisanedemo.feature_patient.domain.use_case.SendQueryMedicineNameUseCase
import com.example.medisanedemo.feature_patient.domain.use_case.SendSuperviseRequestFromPatientUseCase
import com.example.medisanedemo.feature_patient.domain.use_case.SupervisePatientUseCase
import com.example.medisanedemo.feature_supervisor.data.data_source.SupervisorApiService
import com.example.medisanedemo.feature_supervisor.data.repository_implementation.SupervisorRepositoryImpl
import com.example.medisanedemo.feature_supervisor.domain.repository_interface.ISupervisorRepository
import com.example.medisanedemo.feature_supervisor.domain.use_case.GetAllPatientsUseCase
import com.example.medisanedemo.feature_supervisor.domain.use_case.GetAvailablePatientsToAddUseCase
import com.example.medisanedemo.feature_supervisor.domain.use_case.GetSuperviseRequestsUseCase
import com.example.medisanedemo.feature_supervisor.domain.use_case.SendSuperviseRequestUseCase
import com.example.medisanedemo.feature_supervisor.domain.use_case.SupervisorUseCases
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import javax.inject.Singleton
import retrofit2.converter.gson.GsonConverterFactory


@Module
@InstallIn(SingletonComponent::class)
class NetworkingModule {

    @Provides
    fun provideSupervisorApiService(): SupervisorApiService {
        return Retrofit.Builder()
            .baseUrl(BASE_URL_EMULATOR) // FOR NOW
            .addConverterFactory(GsonConverterFactory.create()) // converts json to kotlin
            .build()
            .create(SupervisorApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideSupervisorRepository(api: SupervisorApiService): ISupervisorRepository {
        return SupervisorRepositoryImpl(api)
    }

    @Provides
    fun providePatientApiService(): PatientApiService {
        return Retrofit.Builder()
            .baseUrl(BASE_URL_EMULATOR) // FOR NOW
            .addConverterFactory(GsonConverterFactory.create()) // converts json to kotlin
            .build()
            .create(PatientApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideMedicineRepository(api: PatientApiService): IMedicineRepository {
        return MedicineRepositoryImpl(api)
    }

    @Provides
    @Singleton
    fun providePatientRepository(api: PatientApiService): IPatientRepository {
        return PatientRepositoryImpl(api)
    }



    @Provides
    fun provideLoginApiService(): LoginApiService {

        return Retrofit.Builder()
            .baseUrl(BASE_URL_EMULATOR)
            .addConverterFactory(GsonConverterFactory.create()) // converts json to kotlin
            .build()
            .create(LoginApiService::class.java)

    }

    @Provides
    @Singleton
    fun provideLoginRepository(api: LoginApiService): ILoginRepository {
        return LoginRepositoryImpl(api)
    }

    @Provides
    @Singleton
    fun provideLoginUseCases(repository: ILoginRepository): LoginUseCases {
        return LoginUseCases(
            logUserIn = LogUserInUseCase(repository),
            signUserUp = SignUserUpUseCase(repository),
            getAllProfiles = GetAllProfilesUseCase(repository),
            addNewProfile = AddNewProfileUseCase(repository),
            deleteProfile = DeleteProfileUseCase(repository)
        )
    }

    @Provides
    @Singleton
    fun providePatientUseCases(medicineRepository: IMedicineRepository, patientRepository: IPatientRepository): PatientUseCases {
        return PatientUseCases(
            addMedicine = AddMedicineUseCase(medicineRepository),
            getAllMedicines = GetAllMedicinesUseCase(medicineRepository),
            getMedicineReport = GetMedicineReportUseCase(medicineRepository),
            addMedicineReport = AddMedicineReportUseCase(medicineRepository),
            getSupervisionRequests = GetSupervisionRequestsUseCase(patientRepository),
            supervisePatient = SupervisePatientUseCase(patientRepository),
            getAvailableSupervisorsToAdd = GetAvailableSupervisorsToAddUseCase(patientRepository),
            sendSuperviseRequestFromPatient = SendSuperviseRequestFromPatientUseCase(patientRepository),
            sendQueryMedicineName = SendQueryMedicineNameUseCase(medicineRepository),
            sendPushNotification = SendPushNotificationUseCase(medicineRepository),
        )
    }

    @Provides
    @Singleton
    fun provideSupervisorUseCases(repository: ISupervisorRepository): SupervisorUseCases {
        return SupervisorUseCases(
            getAllPatients = GetAllPatientsUseCase(repository),
            getAvailablePatientsToAddUseCase = GetAvailablePatientsToAddUseCase(repository),
            sendSuperviseRequestUseCase = SendSuperviseRequestUseCase(repository),
            getSuperviseRequestsUseCase = GetSuperviseRequestsUseCase(repository),
        )
    }


}