package com.example.medisanedemo.di.util

object Consts {

    val BASE_URL_EMULATOR = "http://10.0.2.2:8000/"
}