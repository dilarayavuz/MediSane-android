package com.example.medisanedemo.feature_supervisor.domain.model

import com.google.gson.annotations.SerializedName

data class AvailableProfilesToAddDto(
    @SerializedName("available_profiles")
    val availableProfiles: List<ProfileToAddDto>
)
