package com.example.medisanedemo.feature_supervisor.domain.model

import com.google.gson.annotations.SerializedName

data class AvailableSupervisionInfo(
    val token: String,
    @SerializedName("wanted_username")
    val wantedUsername: String,
    @SerializedName("own_profile_id")
    val ownProfileId: Int,
    @SerializedName("own_profile_type")
    val ownProfileType: Boolean // 1 supervisor, 0 patient
)
