package com.example.medisanedemo.feature_patient.domain.use_case

import com.example.medisanedemo.feature_patient.domain.model.AwaitingRequestsDto
import com.example.medisanedemo.feature_patient.domain.model.ProfileRequestNotificationInfo
import com.example.medisanedemo.feature_patient.domain.model.SupervisePatientInfo
import com.example.medisanedemo.feature_patient.domain.repository_interface.IPatientRepository
import javax.inject.Inject

class SupervisePatientUseCase @Inject constructor(
    private val repository: IPatientRepository
) {

    /*
    * allows us to call this class as a function
    * */
    suspend operator fun invoke(
        token: String,
        supervisorId: Int,
        patientId: Int,
        isAccepted: Boolean,
    ): Boolean {
        return repository.supervisePatient(
            SupervisePatientInfo(
                token = token,
                supervisorId = supervisorId,
                patientId = patientId,
                isAccepted = isAccepted,
            )
        )
    }
}