package com.example.medisanedemo.feature_patient.presentation.my_medicines

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.medisanedemo.feature_patient.domain.model.MedicineReport
import com.example.medisanedemo.feature_patient.domain.use_case.PatientUseCases
import com.example.medisanedemo.feature_patient.presentation.util.PatientUiUtils
import com.example.medisanedemo.feature_patient.presentation.util.PatientUiUtils.convertClashList
import com.example.medisanedemo.feature_patient.presentation.util.PatientUiUtils.convertMedicineDtoList
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import java.io.IOException
import javax.inject.Inject

@HiltViewModel
class MyMedicinesViewModel @Inject constructor(
    private val patientUseCases: PatientUseCases,
    savedStateHandle: SavedStateHandle
): ViewModel() {

    val TAG = "MyMedicinesViewModel"

    private val _state = mutableStateOf(MyMedicinesState())
    val state: State<MyMedicinesState> = _state

    private val responseEventChannel = Channel<ResponseEvent>() // channel with only one observer
    val responseEvents = responseEventChannel.receiveAsFlow() // receiveAsFlow returns an immutable flow, will be observed by the ui


    init {
        val token = savedStateHandle.get<String>("token")!!
        val accountId = savedStateHandle.get<Int>("accountId")!!
        val profileId = savedStateHandle.get<Int>("profileId")!!
        val profileName = savedStateHandle.get<String>("profileName")!!
        val isSupervisor = savedStateHandle.get<Boolean>("isSupervisor")!!



        _state.value = state.value.copy(
            token = token,
            accountId = accountId,
            profileId = profileId,
            profileName = profileName,
            isSupervisor = isSupervisor,
        )
        setMyMedicineContent()
    }

    private fun setMyMedicineContent() {
        viewModelScope.launch {


            try {
                val payload = patientUseCases.getAllMedicines.invoke(
                    profileId = state.value.profileId,
                    token = state.value.token
                )

                val medicineList = convertMedicineDtoList(payload.medicineList)
                val clashList = convertClashList(payload.clashList)

                val medicineReportPayload = patientUseCases.getMedicineReport.invoke(
                    token = state.value.token,
                    profileId = state.value.profileId
                )

                val medicineReportList = PatientUiUtils.convertMedicineReportDtoList(
                    medicineReportPayload.medicineReportList,
                    medicineList
                ).sortedBy { medicineReport: MedicineReport ->
                    medicineReport.hourOfDose
                }

                _state.value = state.value.copy(
                    medicineList = medicineList,
                    clashList = clashList,
                    profileId = state.value.profileId,
                    screenState = ScreenState.Success,
                    medicineReportList = medicineReportList
                )
            } catch (e: IOException) {

                _state.value = state.value.copy(
                    screenState = ScreenState.Error(
                        message = "Internet Connection Failed",
                    ),
                    profileId = state.value.profileId
                )

            }
        }
    }

    fun onEvent(event: MyMedicinesUIEvent) {

        when (event) {

            is MyMedicinesUIEvent.PressedOnSegmentedButton -> {
                _state.value = state.value.copy(
                    selectedButtonIndex = event.index
                )
            }
            is MyMedicinesUIEvent.PressedOnMedicineColumn -> {
                _state.value = state.value.copy(
                    isMedicineInfoDialogVisible = true,
                    medicineInfoList = event.medicineList
                )
            }
            is MyMedicinesUIEvent.Retry -> {

                setMyMedicineContent()

            }

            is MyMedicinesUIEvent.PressedOnEditMedicine -> {

                viewModelScope.launch {
                    responseEventChannel.send(ResponseEvent.NavigateToEditMedicine(medicineName = event.medicine.name))
                }
            }

            is MyMedicinesUIEvent.PressedOnDeleteMedicine -> TODO()

            is MyMedicinesUIEvent.ToggleMedicineInfoDialog -> {

                _state.value = state.value.copy(
                    isMedicineInfoDialogVisible = event.isVisible
                )

            }
        }
    }






    /* one time events that ViewModel sends, and the UI reads
    * we do not want to hold onto these events unlike states that are persistent
    */
    sealed class ResponseEvent {

        data class NavigateToEditMedicine(val medicineName: String): ResponseEvent()

        //object GoToSelectedMedicine: ResponseEvent() // maybe a dataClass that holds the medicine name?

    }
}