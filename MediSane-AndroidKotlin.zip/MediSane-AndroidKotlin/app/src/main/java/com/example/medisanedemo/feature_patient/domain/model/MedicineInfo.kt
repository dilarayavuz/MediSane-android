package com.example.medisanedemo.feature_patient.domain.model

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import com.google.gson.annotations.SerializedName
import java.time.LocalDateTime
import java.time.LocalTime

data class MedicineInfo(
    @SerializedName("patient_id")
    val profileId: Int,
    val token: String,
    @SerializedName("medicine_name")
    val medicineName: String,
    val frequency: Int,
    @SerializedName("start_dates")
    val startDateList: List<String>,

    /* optionals */
    @SerializedName("end_date")
    val endDate: String? = null,
    @SerializedName("dose_amount")
    val doseAmount: Int = 1,
    @SerializedName("usage_description")
    val usageDescription: String = "",
    @SerializedName("has_notif")
    val hasNotification: Boolean = false,
    @SerializedName("remaining_amount")
    val remainingAmount: Int? = null,

    @SerializedName("is_update")
    val isUpdate: Boolean,
)
