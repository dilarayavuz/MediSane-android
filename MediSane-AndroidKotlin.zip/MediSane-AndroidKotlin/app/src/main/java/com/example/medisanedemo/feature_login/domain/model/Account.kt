package com.example.medisanedemo.feature_login.domain.model

data class Account(
    val id: Int,
    val token: String
)
