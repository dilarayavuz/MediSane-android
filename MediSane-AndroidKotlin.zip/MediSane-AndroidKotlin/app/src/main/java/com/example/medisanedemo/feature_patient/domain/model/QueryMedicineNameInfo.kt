package com.example.medisanedemo.feature_patient.domain.model

import com.google.gson.annotations.SerializedName

data class QueryMedicineNameInfo(
    val token: String,
    @SerializedName("search_string")
    val searchString: String,
)
