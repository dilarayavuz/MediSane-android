package com.example.medisanedemo.navigation.util

sealed class Screen(val route: String) {
    object LoginScreen: Screen("login_screen")
    object SignupScreen: Screen("signup_screen")
    object SelectPatientScreen: Screen("select_patient")
    object PatientHomeScreen: Screen("patient_home_screen")
    object SelectProfileScreen: Screen("select_profile_screen")
    object MyMedicinesScreen: Screen("my_medicine_screen")

    object AddMedicineGraph: Screen("add_medicine")
    object AddMedicineScreen: Screen("add_medicine_screen")
    object SelectMedicineFrequencyScreen: Screen("select_medicine_frequency_screen")
    object EverydayOptionMedicineScreen: Screen("everyday_opt_medicine_screen")
    object EveryXDayOptionMedicineScreen: Screen("every_x_day_opt_medicine_screen")
    object SpecificDaysOfWeekMedicineScreen: Screen("specific_days_of_week_opt_medicine_screen")
    object AdditionalOptionsScreen: Screen("additional_options_medicine_screen")


    object HelpScreen: Screen("help_screen")
    object NotificationScreen: Screen("notification_screen")



    /* builds route */
    fun withArgs(vararg args: String): String { //varargs allows us to pass a variable amount of arguments (i.e. we can pass multiple Strings here)
        return buildString {
            append(route)
            args.forEach { arg ->
                append("/$arg")
            }
        }

    }
}

