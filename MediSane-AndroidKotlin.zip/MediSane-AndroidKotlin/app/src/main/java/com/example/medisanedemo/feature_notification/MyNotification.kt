package com.example.medisanedemo.feature_notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.medisanedemo.MainActivity
import com.example.medisanedemo.R
import java.util.Locale
import kotlin.random.Random

//
import android.util.Log
import androidx.work.Data
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkManager
import com.example.medisanedemo.feature_notification.ScheduledWorker.Companion.NOTIFICATION_DATE
import com.example.medisanedemo.feature_notification.ScheduledWorker.Companion.NOTIFICATION_MESSAGE
import com.example.medisanedemo.feature_notification.ScheduledWorker.Companion.NOTIFICATION_TITLE
import java.util.concurrent.TimeUnit


class MyNotification(var context: Context, var title: String, var msg: String, var scheduledTimeString: String) {
    val channelID: String = "FCM100"
    val channelName: String = "FCMMessage"
    val notificationManager = context.applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    lateinit var notificationChannel: NotificationChannel
    lateinit var notificationBuilder: NotificationCompat.Builder

    fun showNotification(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationChannel = NotificationChannel(channelID, channelName, NotificationManager.IMPORTANCE_HIGH)
            notificationManager.createNotificationChannel(notificationChannel)
        }

        val intent = Intent(context, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pendingIntent = PendingIntent.getActivity(context, 0, intent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE)

        notificationBuilder = NotificationCompat.Builder(context, channelID)
            .setSmallIcon(R.drawable.ic_stat_ic_notification)
            .setContentTitle(title)
            .setContentText(msg)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
        notificationManager.notify(Random.nextInt(), notificationBuilder.build())

    }

    fun scheduleNotification() {
        val notificationData = Data.Builder()
            .putString(NOTIFICATION_TITLE, title)
            .putString(NOTIFICATION_MESSAGE, msg)
            .putString(NOTIFICATION_DATE, scheduledTimeString)
            .build()

        val delay = calculateDelay(scheduledTimeString)

        val work = OneTimeWorkRequest.Builder(ScheduledWorker::class.java)
            .setInputData(notificationData)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()

        WorkManager.getInstance(context).enqueue(work)
        Log.d(javaClass.name, "WorkManager is Enqueued.")
    }

    private fun calculateDelay(scheduledTimeString: String): Long {
        val scheduledTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            .parse(scheduledTimeString)

        return scheduledTime.time - System.currentTimeMillis()
    }

}