package com.example.medisanedemo.feature_login.presentation.select_profile

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.BottomAppBarState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_login.domain.model.ProfileType
import com.example.medisanedemo.feature_login.domain.model.profileDefault
import com.example.medisanedemo.feature_login.presentation.select_profile.components.AddProfileDialog
import com.example.medisanedemo.feature_login.presentation.select_profile.components.ErrorScreenComponent
import com.example.medisanedemo.feature_login.presentation.select_profile.components.LazyProfileColumnComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.BottomAppBarComponent
import com.example.medisanedemo.feature_patient.presentation.home.components.TopAppBarComponent
import com.example.medisanedemo.feature_patient.presentation.util.ScreenState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf


@Composable
fun SelectProfileScreen(
    state: SelectProfileState,
    responseEvents: Flow<SelectProfileViewModel.ResponseEvent>,
    onNewTokenAcquired: (String) -> Unit,
    onNavigateToPatientProfile: (String, Int, Profile) -> Unit,
    onNavigateToSupervisorProfile: (String, Int, Profile) -> Unit,
    onPressedDeleteProfile: (Profile) -> Unit,
    onProfileClick: (Profile) -> Unit,
    onPressedAddProfile: () -> Unit,
    onDismissAddProfile: () -> Unit,
    onConfirmAddProfile: () -> Unit,
    onRetry: () -> Unit,
    onProfileNameToAddChange: (String) -> Unit,
    onSegmentedButtonClick: (Int) -> Unit
) {

    val TAG = "SelectProfileScreen"
    val context = LocalContext.current
    var tokenVar: String = ""

    LaunchedEffect(key1 = context) {// LaunchedEffect(key = context) --> when context changes, this affect will be relaunched
        responseEvents.collect {event ->
            when (event) {
                is SelectProfileViewModel.ResponseEvent.ProfileSelected -> {
                    if (event.profile.type == ProfileType.PATIENT) { // navigate according to the type value!

                        Log.d(TAG, "tokenVar: $tokenVar")

                        if (tokenVar.isEmpty()) {
                            tokenVar = state.token
                        }
                        onNavigateToPatientProfile(tokenVar, state.accountId, event.profile)
                    }
                    else if (event.profile.type == ProfileType.SUPERVISOR) {

                        Log.d(TAG, "tokenVal: $tokenVar")

                        if (tokenVar.isEmpty()) {
                            tokenVar = state.token
                        }
                        onNavigateToSupervisorProfile(tokenVar, state.accountId, event.profile)
                    }

                }

                is SelectProfileViewModel.ResponseEvent.TokenAcquired -> {

                    Log.d(TAG, "token sent to screen: ${event.token}")
                    tokenVar = event.token
                    //onNewTokenAcquired(event.token)
                }

            }

        }
    }

    when (state.screenState) {
        is ScreenState.Error -> {
            ErrorScreen(
                message = state.screenState.message,
                onRetry = onRetry
            )
        }
        is ScreenState.Loading -> {
            LoadingScreen()
        }
        is ScreenState.Success -> {
            SuccessScreen(
                state = state,
                onProfileClick = onProfileClick,
                onPressedAddProfile = onPressedAddProfile,
                onDismissAddProfile = onDismissAddProfile,
                onConfirmAddProfile = onConfirmAddProfile,
                onProfileNameToAddChange = onProfileNameToAddChange,
                onSegmentedButtonClick = onSegmentedButtonClick,
                onPressedDeleteProfile = onPressedDeleteProfile
            )
        }
    }


}

@Composable
fun SuccessScreen(
    state: SelectProfileState,
    onProfileClick: (Profile) -> Unit,
    onPressedDeleteProfile: (Profile) -> Unit,
    onPressedAddProfile: () -> Unit,
    onDismissAddProfile: () -> Unit,
    onConfirmAddProfile: () -> Unit,
    onProfileNameToAddChange: (String) -> Unit,
    onSegmentedButtonClick: (Int) -> Unit,
) {

    Scaffold (
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.select_profile),
                isHomeScreen = false,
                isSelectProfileScreen = true,
                isSelectPatientScreen = false,
                hasNotification = false
            )
        },
        bottomBar = {
            BottomAppBarComponent(
                isHomeScreen = false,
                onAddProfileButtonPressed = onPressedAddProfile
            )
        }
    ){
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(it)
        ) {

            LazyProfileColumnComponent(
                groupedProfileList = state.groupedProfileList,
                onProfileClick = onProfileClick,
                onPressDeleteProfile = onPressedDeleteProfile
            )

            if (state.isAddProfileDialogVisible) {
                AddProfileDialog(
                    onDismissRequest = onDismissAddProfile,
                    onConfirmRequest = onConfirmAddProfile,
                    onSegmentedButtonClick = onSegmentedButtonClick,
                    onProfileNameChange = onProfileNameToAddChange,
                    profileName = state.profileToAddName,
                    selectedIndex = state.selectedIndex
                )
            }

        }
    }
}

@Composable
fun ErrorScreen(
    message: String,
    onRetry: () -> Unit,
) {

    Scaffold (
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.select_profile),
                isHomeScreen = false,
                isSelectProfileScreen = true,
                isSelectPatientScreen = false,
                hasNotification = false,
            )
        },
        bottomBar = {
            BottomAppBarComponent(
                isHomeScreen = false,
                onAddProfileButtonPressed = { }
            )
        }
    ){
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(it)
        ) {

            ErrorScreenComponent(
                message = message,
                onRetry = onRetry
            )



        }
    }

}

@Composable
fun LoadingScreen() {

    Scaffold (
        topBar = {
            TopAppBarComponent(
                title = stringResource(id = R.string.select_profile),
                isHomeScreen = false,
                isSelectProfileScreen = true,
                isSelectPatientScreen = false,
                hasNotification = false,
            )
        },
        bottomBar = {
            BottomAppBarComponent(
                isHomeScreen = false,
                onAddProfileButtonPressed = { }
            )
        }
    ){
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(it)
        ) {

            Column (
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ){

                CircularProgressIndicator(
                    modifier = Modifier.width(64.dp),
                    color = MaterialTheme.colorScheme.secondary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )

            }



        }
    }

}

/*
@Preview(showBackground = true)
@Composable
fun SelectProfileSuccessPrev() {
    SelectProfileScreen(
        state = SelectProfileState(
            groupedProfileList = mapOf(
                Pair(
                    ProfileType.PATIENT,
                    listOf(
                        profileDefault()
                    )
                )
            ),
            screenState = ScreenState.Success
        ),
        responseEvents = flowOf(),
        onNavigateToPatientProfile = {str, int, profile ->

        },
        onNavigateToSupervisorProfile = { str, int, profile ->

        },
        onProfileClick = {},
        onPressedAddProfile = {},
        onSegmentedButtonClick = {},
        onConfirmAddProfile = {},
        onDismissAddProfile = {},
        onProfileNameToAddChange = {},
        onRetry = {},
        onPressedDeleteProfile = {},
        onNewTokenAcquired = {},
    )
}

 */


/*
@Preview(showBackground = true)
@Composable
fun SelectProfileErrorPrev() {
    SelectProfileScreen(
        state = SelectProfileState(
            groupedProfileList = mapOf(
                Pair(
                    ProfileType.PATIENT,
                    listOf(
                        profileDefault()
                    )
                )
            ),
            screenState = ScreenState.Error(message = "Internet Connection Failed")
        ),
        responseEvents = flowOf(),
        onNavigateToPatientProfile = {str,  int, profile ->

        },
        onNavigateToSupervisorProfile = { str, int, profile ->

        },
        onProfileClick = {},
        onPressedAddProfile = {},
        onSegmentedButtonClick = {},
        onConfirmAddProfile = {},
        onDismissAddProfile = {},
        onProfileNameToAddChange = {},
        onRetry = {},
        onPressedDeleteProfile = {},
        onNewTokenAcquired = {},
    )
}

 */

/*
@Preview(showBackground = true)
@Composable
fun SelectProfileLoadingPrev() {
    SelectProfileScreen(
        state = SelectProfileState(
            groupedProfileList = mapOf(
                Pair(
                    ProfileType.PATIENT,
                    listOf(
                        profileDefault()
                    )
                )
            ),
            screenState = ScreenState.Loading
        ),
        responseEvents = flowOf(),
        onNavigateToPatientProfile = { str, int, profile ->

        },
        onNavigateToSupervisorProfile = { str, int, profile ->

        },
        onProfileClick = {},
        onPressedAddProfile = {},
        onSegmentedButtonClick = {},
        onConfirmAddProfile = {},
        onDismissAddProfile = {},
        onProfileNameToAddChange = {},
        onRetry = {},
        onPressedDeleteProfile = {},
        onNewTokenAcquired = {},
    )
}

 */


