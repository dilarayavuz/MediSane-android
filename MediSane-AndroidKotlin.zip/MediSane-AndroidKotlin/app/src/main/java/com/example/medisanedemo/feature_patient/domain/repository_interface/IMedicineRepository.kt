package com.example.medisanedemo.feature_patient.domain.repository_interface

import com.example.medisanedemo.feature_patient.domain.model.AllMedicinesPayload
import com.example.medisanedemo.feature_patient.domain.model.MedicineInfo
import com.example.medisanedemo.feature_patient.domain.model.AllMedicineReportPayload
import com.example.medisanedemo.feature_patient.domain.model.MatchingQueryMedicinesDto
import com.example.medisanedemo.feature_patient.domain.model.MedicineReportInfo
import com.example.medisanedemo.feature_patient.domain.model.NotificationInfo
import com.example.medisanedemo.feature_patient.domain.model.ProfileInfo
import com.example.medisanedemo.feature_patient.domain.model.QueryMedicineNameInfo

interface IMedicineRepository {

    suspend fun getAllMedicines(profileInfo: ProfileInfo): AllMedicinesPayload

    suspend fun addMedicine(medicineInfo: MedicineInfo)

    suspend fun getMedicineReport(profileInfo: ProfileInfo): AllMedicineReportPayload
    suspend fun addMedicineReport(medicineReportInfo: MedicineReportInfo): Int
    suspend fun getQueryMedicineName(queryMedicineNameInfo: QueryMedicineNameInfo): MatchingQueryMedicinesDto
    suspend fun sendPushNotification(notificationInfo: NotificationInfo)
}