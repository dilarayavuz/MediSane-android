package com.example.medisanedemo.feature_patient.presentation.add_medicine.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.presentation.login.components.NormalTextComponent
import com.example.medisanedemo.ui.theme.MyTheme

@Composable
fun SetNotificationDialog(
    onDismissRequest: () -> Unit,
    onSetNotificationChange: (Boolean) -> Unit,
    hasNotification: Boolean
) {

    Dialog(
        onDismissRequest = onDismissRequest
    ) {

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.background,
                contentColor = MaterialTheme.colorScheme.onBackground
            )
        ) {

            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {

                Row(
                    modifier = Modifier
                        .padding(top = 8.dp),

                ){
                    NormalTextComponent(
                        value = stringResource(id = R.string.set_notification)
                    )
                }

                Switch(
                    checked = hasNotification,
                    onCheckedChange = onSetNotificationChange,
                    colors = SwitchDefaults.colors(
                        checkedBorderColor = MaterialTheme.colorScheme.primary,
                    )
                )

                Row (
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    TextButton(
                        onClick = { onDismissRequest() },
                        modifier = Modifier.padding(8.dp),
                    ) {
                        Text(stringResource(id = R.string.dismiss))
                    }
                }

            }

        }

    }

}



@Preview(showBackground = true)
@Composable
fun SetNotifPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 36.dp, start = 36.dp, bottom = 48.dp)
        ){
            SetNotificationDialog(
                onDismissRequest = { },
                onSetNotificationChange = {},
                hasNotification = false,
            )
        }

    }
}
