package com.example.medisanedemo.feature_notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.medisanedemo.R
import kotlin.random.Random

class ScheduledWorker(appContext: Context, workerParams: WorkerParameters) :

    Worker(appContext, workerParams) {
    override fun doWork(): Result {
        Log.d(TAG, "Work START")

        val title = inputData.getString(NOTIFICATION_TITLE)
        val body = inputData.getString(NOTIFICATION_MESSAGE)

        val notificationManager =
            applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channelID: String = "FCM100"
        val channelName: String = "FCMMessage"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Create the NotificationChannel if the API level is 26 or higher
            val channel = NotificationChannel(
                channelID,
                channelName,
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        val notificationBuilder = NotificationCompat.Builder(applicationContext, channelID)
            .setSmallIcon(R.drawable.ic_stat_ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)

        notificationManager.notify(Random.nextInt(), notificationBuilder.build())

        Log.d(TAG, "Work DONE")
        return Result.success()
    }


    companion object {
        private const val TAG = "ScheduledWorker"
        const val NOTIFICATION_TITLE = "notification_title"
        const val NOTIFICATION_MESSAGE = "notification_message"
        const val NOTIFICATION_DATE = "notification_date"
    }

    }