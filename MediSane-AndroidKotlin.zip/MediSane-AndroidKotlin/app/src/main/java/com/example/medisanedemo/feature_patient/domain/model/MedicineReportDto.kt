package com.example.medisanedemo.feature_patient.domain.model

import com.example.medisanedemo.feature_patient.presentation.home.components.Label
import com.google.gson.annotations.SerializedName
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

data class MedicineReportDto(
    val label: Int,
    @SerializedName("patient_id")
    val profileId: Int,
    @SerializedName("medicine_name")
    val medicineName: String,
    @SerializedName("hour_of_dose")
    val hourOfDose: String
)

fun MedicineReportDto.toMedicineReport(medicineList: List<Medicine>): MedicineReport {

    var selectedMedicine: Medicine = medicineList[0]
    for (medicine in medicineList) {
        if (this.medicineName == medicine.name) {
            selectedMedicine = medicine
            break
        }
    }
    return MedicineReport(
        profileId = this.profileId,
        label = if (this.label == 1) {
            Label.TAKEN
        } else {
            Label.MISSED
        },
        hourOfDose = LocalDateTime.parse(this.hourOfDose),
        medicine = selectedMedicine
    )
}
