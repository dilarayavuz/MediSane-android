package com.example.medisanedemo.feature_patient.domain.model

import com.google.gson.annotations.SerializedName


data class AllMedicineReportPayload(
    @SerializedName("medicine_report")
    val medicineReportList: List<MedicineReportDto>?
)