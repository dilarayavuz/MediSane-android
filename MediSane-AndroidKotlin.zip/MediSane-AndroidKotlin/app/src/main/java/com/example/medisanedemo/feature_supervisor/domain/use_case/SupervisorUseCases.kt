package com.example.medisanedemo.feature_supervisor.domain.use_case

data class SupervisorUseCases(
    val getAllPatients: GetAllPatientsUseCase,
    val getAvailablePatientsToAddUseCase: GetAvailablePatientsToAddUseCase,
    val sendSuperviseRequestUseCase: SendSuperviseRequestUseCase,
    val getSuperviseRequestsUseCase: GetSuperviseRequestsUseCase
)
