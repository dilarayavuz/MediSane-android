package com.example.medisanedemo.feature_patient.presentation.home.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.medisanedemo.ui.theme.MyTheme
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.util.Locale
import kotlin.math.abs

@Composable
fun CustomDatePickerComponent(
    modifier: Modifier = Modifier,
    selectedDate: LocalDateTime,
    rowState: LazyListState,
    onDayOfMonthSelected: (Int) -> Unit,
    onPreviousMonthPressed: () -> Unit,
    onNextMonthPressed: () -> Unit,
) {

    Column(modifier = modifier.fillMaxWidth()){
        Header(
            selectedDate = selectedDate,
            onPreviousMonthPressed = onPreviousMonthPressed,
            onNextMonthPressed = onNextMonthPressed
        )


        Content(
            selectedDate = selectedDate,
            onDateBoxClick = onDayOfMonthSelected,
            rowState = rowState
        )
    }
}



@Composable
fun DateBox(
    date: String,
    weekDay: String,
    isFocused: Boolean,
    onClick: (Int) -> Unit
) {
    Card(
        modifier = Modifier
            .wrapContentSize()
            .padding(4.dp)
            .clip(RoundedCornerShape(8.dp))
            .fillMaxWidth()
            .clickable(
                onClick = {
                    onClick(date.toInt())
                }
            ),
        colors = if (isFocused) {
            CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
            )
        } else {
            CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.background,
                contentColor = MaterialTheme.colorScheme.onBackground
            )
        },
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isFocused) {
                8.dp
            } else {
                0.dp
            }
        )
    ) {

        Column(
            modifier = Modifier
                .width(60.dp)
                .height(60.dp)
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            Text(
                text = weekDay,
                modifier = Modifier.align(Alignment.CenterHorizontally),
                style = MaterialTheme.typography.bodyMedium,
            )

            Text(
                text = date,
                modifier = Modifier.align(Alignment.CenterHorizontally),
                style = MaterialTheme.typography.bodyMedium,
            )

        }

    }
}

@Composable
fun Content(
    selectedDate: LocalDateTime,
    onDateBoxClick: (Int) -> Unit,
    rowState: LazyListState

) {
    val firstDayOfMonth = LocalDateTime.of(selectedDate.year, selectedDate.month, 1, selectedDate.hour, selectedDate.minute)

    val totalDaysOfMonth = selectedDate.month.length(selectedDate.year % 4 == 0)

    val startDate = 1

    val dateList = mutableListOf<Pair<Int, String>>()

    for (date in startDate..totalDaysOfMonth) {

        val day = firstDayOfMonth.plusDays((date - 1).toLong())
        dateList.add(
            Pair(
                date,
                getWeekName(day.dayOfWeek.value)
            )
        )
    }

    LazyRow (
        state = rowState
    ) {

        items(dateList) {datePair: Pair<Int, String> ->

            DateBox(
                date = datePair.first.toString(),
                weekDay = datePair.second,
                isFocused = datePair.first == selectedDate.dayOfMonth,
                onClick = onDateBoxClick
            )

        }
    }
}


@Composable
fun Header(
    selectedDate: LocalDateTime,
    onPreviousMonthPressed: () -> Unit,
    onNextMonthPressed: () -> Unit
) {
    Row (
        verticalAlignment = Alignment.CenterVertically
    ){
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = selectedDate.month.toString().lowercase(Locale.ROOT) + " " + selectedDate.dayOfMonth.toString() + ", " + selectedDate.year.toString(),
            style = TextStyle(
                fontSize = 16.sp,
                fontWeight = FontWeight.Normal,
                fontStyle = FontStyle.Normal,
            ),
            modifier = Modifier
                .weight(1f)
                .align(Alignment.CenterVertically)
        )
        IconButton(
            onClick = onPreviousMonthPressed
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                contentDescription = "Previous"
            )
        }
        IconButton(
            onClick = onNextMonthPressed
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Next"
            )
        }
    }
}



@Preview(showBackground = true)
@Composable
fun DatePickerCustomPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){
            CustomDatePickerComponent(
                selectedDate = LocalDateTime.now(),
                onDayOfMonthSelected = {},
                onPreviousMonthPressed = {},
                onNextMonthPressed = {},
                rowState = LazyListState()
            )
        }

    }
}



fun getWeekName(dayOfWeek: Int): String {

    when (dayOfWeek) {
        1 -> {
            return "MON"
        }
        2 -> {
            return "TUE"
        }
        3 -> {
            return "WED"
        }
        4 -> {
            return "THU"
        }
        5 -> {
            return "FRI"
        }
        6 -> {
            return "SAT"
        }
        else -> {
            return "SUN"
        }
    }

}




