package com.example.medisanedemo.feature_patient.presentation.my_medicines.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_login.presentation.login.components.HeadlineTextComponent
import com.example.medisanedemo.feature_login.presentation.login.components.NormalTextComponent
import com.example.medisanedemo.feature_login.presentation.select_profile.components.AddProfileDialog
import com.example.medisanedemo.feature_patient.domain.model.Medicine
import com.example.medisanedemo.feature_patient.presentation.util.PatientUiUtils.getDaysOfWeek
import com.example.medisanedemo.feature_patient.presentation.util.PatientUiUtils.getDoseTimes
import com.example.medisanedemo.feature_patient.presentation.util.PatientUiUtils.getFrequency
import com.example.medisanedemo.feature_patient.presentation.util.PatientUiUtils.getStartDate
import com.example.medisanedemo.ui.theme.MyTheme
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun MedicineInfoDialogComponent(
    onDismissRequest: () -> Unit,
    onEditMedicine: (Medicine) -> Unit,
    onDeleteMedicine: (Medicine) -> Unit,
    /* same medicine different info */
    medicineInfoList: List<Medicine>
    ) {

    val medicineName = medicineInfoList[0].name
    /*
    *  if Frequency.Everyday,
    *        bir gün içinde alınan saatleri göster: List<LocalTime> +
    *        startdate göster: LocalDate +
    *  if Frequency.EveryXDay,
    *        frequency: Int +
    *        bir gün içinde alınan saatleri göster: List<LocalTime> +
    *        startdate göster: LocalDate +
    *  if Frequency.Specific,
    *       günleri göster: List<DayOfWeek>
    *       bir gün içinde alınan saatleri göster: List<LocalTime> +
    *       startdate göster: LocalDate +
    *
    *  ekstralar:
    *       remaining amount (if not -1)
    *       has notif++
    *       dose amount (if not -1)++
    *       usage description (if notEmpty() )++
    *       end date (if isEndDateNull is false)++
    *
    * */
    val frequency: Frequency = getFrequency(medicineInfoList)
    val doseTimes: List<LocalTime> = getDoseTimes(medicineInfoList)
    val startDate: LocalDate = getStartDate(medicineInfoList)
    val days: List<DayOfWeek> = getDaysOfWeek(medicineInfoList)
    val endDate: LocalDate = medicineInfoList[0].endDate.toLocalDate()
    val isEndDateNull: Boolean = medicineInfoList[0].isEndDateNull
    val usageDescription: String = medicineInfoList[0].usageDescription
    val hasNotification: String = if (medicineInfoList[0].hasNotification) {
        "True"
    } else {
        "False"
    }
    val doseAmount: Int = medicineInfoList[0].doseAmount
    val remainingAmount: Int = medicineInfoList[0].remainingAmount

    val frequenctStr: String = when (frequency) {
        Frequency.EVERYDAY -> {
            "Everyday"
        }
        Frequency.EVERYXDAY -> {
            "Once Every ${medicineInfoList[0].frequency} Days"
        }
        Frequency.SPECIFICDAYS -> {
            "Specific Days of the Week"
        }
    }



    Dialog(
        onDismissRequest = onDismissRequest
    ) {

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(400.dp)
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.background,
                contentColor = MaterialTheme.colorScheme.onBackground
            )
        ) {

            val scrollState = rememberScrollState()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
                    .verticalScroll(state = scrollState),
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .padding(top = 8.dp, bottom = 8.dp)
                ) {
                    HeadlineTextComponent(
                        value = medicineName
                    )
                }
                /*
                HorizontalDivider(
                    modifier = Modifier.padding(2.dp),
                    thickness = 1.dp,
                    color = MaterialTheme.colorScheme.onBackground
                )

                 */



                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    NormalTextComponent(
                        value = "How Often: $frequenctStr"
                    )
                }

                if (frequency == Frequency.SPECIFICDAYS) {

                    LazyRow {
                        items(days){ dayOfWeek: DayOfWeek ->

                            Column(
                                modifier = Modifier
                                    .padding(4.dp)
                                    .padding(bottom = 8.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.secondaryContainer)
                                    .size(width = 88.dp, height = 46.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = dayOfWeek.getDisplayName(
                                        TextStyle.SHORT,
                                        Locale.ENGLISH
                                    )
                                )
                            }

                        }
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(2.dp),
                    thickness = 1.dp,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Row(
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    NormalTextComponent(
                        value = "Start Date: ${startDate.format(DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.ENGLISH))}"
                    )
                }

                if (!isEndDateNull) {
                    HorizontalDivider(
                        modifier = Modifier.padding(2.dp),
                        thickness = 1.dp,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Row(
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        NormalTextComponent(
                            value = "End Date: ${endDate.format(DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.ENGLISH))}"
                        )
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(2.dp),
                    thickness = 1.dp,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Row(
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    NormalTextComponent(
                        value = "Is Notification Set?: $hasNotification"
                    )
                }


                HorizontalDivider(
                    modifier = Modifier.padding(2.dp),
                    thickness = 1.dp,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Row(
                    modifier = Modifier.padding(top = 8.dp)
                ){
                    NormalTextComponent(
                        value = "Dose Hours:"
                    )
                }

                LazyRow {

                    items(doseTimes) { doseTime: LocalTime ->

                        Column(
                            modifier = Modifier
                                .padding(4.dp)
                                .padding(bottom = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.secondaryContainer)
                                .size(width = 88.dp, height = 46.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {

                            Text(
                                text = doseTime.format(DateTimeFormatter.ofPattern("HH:mm"))
                            )
                        }

                    }
                }

                if (usageDescription.isNotEmpty()) {

                    HorizontalDivider(
                        modifier = Modifier.padding(2.dp),
                        thickness = 1.dp,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Row(
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    ) {
                        NormalTextComponent(
                            value = "Usage Description: $usageDescription"
                        )
                    }
                }

                if (doseAmount > 0) {

                    HorizontalDivider(
                        modifier = Modifier.padding(2.dp),
                        thickness = 1.dp,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Row(
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        NormalTextComponent(
                            value = "Dose Per Take: $doseAmount"
                        )
                    }
                }

                if (remainingAmount >= 0) {

                    HorizontalDivider(
                        modifier = Modifier.padding(2.dp),
                        thickness = 1.dp,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Row(
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        NormalTextComponent(
                            value = "Remaining Amount: $doseAmount"
                        )
                    }

                }

                /* BUTTONS */
                Row (
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ){

                    IconButton(
                        onClick = { onEditMedicine(medicineInfoList[0]) },
                        modifier = Modifier
                            .size(52.dp)
                    ) {

                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit medicine",
                            modifier = Modifier
                                .size(32.dp)
                        )


                    }

                    IconButton(
                        onClick = { onDeleteMedicine(medicineInfoList[0]) },
                        modifier = Modifier
                            .size(52.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete medicine",
                            modifier = Modifier
                                .size(32.dp)
                        )
                    }
                }
            }
        }
    }
}

enum class Frequency {
    EVERYDAY, EVERYXDAY, SPECIFICDAYS
}



@Preview(showBackground = true)
@Composable
fun MedicineInfoDialogEverydayPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 36.dp, start = 36.dp, bottom = 48.dp)
        ){
            MedicineInfoDialogComponent(
                onDismissRequest = {},
                onEditMedicine = {},
                onDeleteMedicine = {},
                medicineInfoList = listOf(
                    Medicine(
                        name = "Agumentin",
                        frequency = 1,
                        startDate = LocalDateTime.now(),
                        remainingAmount = 1,
                        doseAmount = 1,
                        endDate = LocalDateTime.now().plusYears(1),
                        hasNotification = false,
                        usageDescription = "bla bla bla bla blalbalbalbal bla bla bla",
                        isEndDateNull = false,
                    ),
                    Medicine(
                        name = "Agumentin",
                        frequency = 1,
                        startDate = LocalDateTime.now().minusHours(1),
                        remainingAmount = 1,
                        doseAmount = 1,
                        endDate = LocalDateTime.now().plusYears(1),
                        hasNotification = false,
                        usageDescription = "bla bla bla bla blalbalbalbal bla bla bla",
                        isEndDateNull = false,
                    )
                )
            )

        }

    }
}



@Preview(showBackground = true)
@Composable
fun MedicineInfoDialogEveryXDayPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 36.dp, start = 36.dp, bottom = 48.dp)
        ){
            MedicineInfoDialogComponent(
                onDismissRequest = {},
                onEditMedicine = {},
                onDeleteMedicine = {},
                medicineInfoList = listOf(
                    Medicine(
                        name = "Agumentin",
                        frequency = 3,
                        startDate = LocalDateTime.now(),
                        remainingAmount = 1,
                        doseAmount = 1,
                        endDate = LocalDateTime.now().plusYears(1),
                        hasNotification = false,
                        usageDescription = "",
                        isEndDateNull = true,
                    ),
                    Medicine(
                        name = "Agumentin",
                        frequency = 1,
                        startDate = LocalDateTime.now().minusHours(1),
                        remainingAmount = 1,
                        doseAmount = 1,
                        endDate = LocalDateTime.now().plusYears(1),
                        hasNotification = false,
                        usageDescription = "",
                        isEndDateNull = true,
                    ),
                    Medicine(
                        name = "Agumentin",
                        frequency = 1,
                        startDate = LocalDateTime.now().plusHours(4),
                        remainingAmount = 1,
                        doseAmount = 1,
                        endDate = LocalDateTime.now().plusYears(1),
                        hasNotification = false,
                        usageDescription = "",
                        isEndDateNull = true,
                    )
                )
            )

        }

    }
}



@Preview(showBackground = true)
@Composable
fun MedicineInfoDialogSpecificDayOfWeekPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 36.dp, start = 36.dp, bottom = 48.dp)
        ){
            MedicineInfoDialogComponent(
                onDismissRequest = {},
                onEditMedicine = {},
                onDeleteMedicine = {},
                medicineInfoList = listOf(
                    Medicine(
                        name = "Agumentin",
                        frequency = 7,
                        startDate = LocalDateTime.now(),
                        remainingAmount = 1,
                        doseAmount = 1,
                        endDate = LocalDateTime.now().plusYears(1),
                        hasNotification = false,
                        usageDescription = "",
                        isEndDateNull = true,
                    ),
                    Medicine(
                        name = "Agumentin",
                        frequency = 7,
                        startDate = LocalDateTime.now().minusHours(1),
                        remainingAmount = 1,
                        doseAmount = 1,
                        endDate = LocalDateTime.now().plusYears(1),
                        hasNotification = false,
                        usageDescription = "",
                        isEndDateNull = true,
                    ),
                    Medicine(
                        name = "Agumentin",
                        frequency = 7,
                        startDate = LocalDateTime.now().minusDays(1),
                        remainingAmount = 1,
                        doseAmount = 1,
                        endDate = LocalDateTime.now().plusYears(1),
                        hasNotification = false,
                        usageDescription = "",
                        isEndDateNull = true,
                    ),
                    Medicine(
                        name = "Agumentin",
                        frequency = 7,
                        startDate = LocalDateTime.now().minusDays(1).minusHours(1),
                        remainingAmount = 1,
                        doseAmount = 1,
                        endDate = LocalDateTime.now().plusYears(1),
                        hasNotification = false,
                        usageDescription = "",
                        isEndDateNull = true,
                    ),
                )
            )

        }

    }
}
