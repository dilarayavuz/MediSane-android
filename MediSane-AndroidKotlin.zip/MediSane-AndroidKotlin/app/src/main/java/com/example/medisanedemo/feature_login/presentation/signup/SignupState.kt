package com.example.medisanedemo.feature_login.presentation.signup

data class SignupState(
    val isPasswordVisible: Boolean = false,
    val isError: Boolean = false,
    val username: String = "",
    val password: String = "",
    val errorMessage: String = ""
)
