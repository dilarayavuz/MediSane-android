package com.example.medisanedemo.feature_patient.domain.use_case

import com.example.medisanedemo.feature_patient.domain.repository_interface.IPatientRepository
import com.example.medisanedemo.feature_supervisor.domain.model.SuperviseRequestInfo
import javax.inject.Inject

class SendSuperviseRequestFromPatientUseCase @Inject constructor(
    private val repository: IPatientRepository
) {

    /*
  * allows us to call this class as a function
  * */
    suspend operator fun invoke(
        patientId: Int,
        supervisorId: Int,
        token: String,
        sentBy: Boolean
    ): Int {

        val response = repository.sendSuperviseRequest(
            SuperviseRequestInfo(
                token = token,
                patientId = patientId,
                supervisorId = supervisorId,
                sentBy = sentBy,
            )
        )

        return response
    }
}