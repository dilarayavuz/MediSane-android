package com.example.medisanedemo.feature_patient.domain.model

import com.google.gson.annotations.SerializedName

data class SupervisePatientInfo(
    val token: String,
    @SerializedName("supervisor_id")
    val supervisorId: Int,
    @SerializedName("patient_id")
    val patientId: Int,
    @SerializedName("is_accepted")
    val isAccepted: Boolean,
)
