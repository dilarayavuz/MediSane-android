package com.example.medisanedemo.feature_patient.presentation.my_medicines

import com.example.medisanedemo.feature_patient.domain.model.Medicine

sealed class MyMedicinesUIEvent {

    data class PressedOnSegmentedButton(val index: Int): MyMedicinesUIEvent()
    data class PressedOnMedicineColumn(val medicineList: List<Medicine>): MyMedicinesUIEvent()
    data class PressedOnDeleteMedicine(val medicine: Medicine): MyMedicinesUIEvent() // TODO
    data class PressedOnEditMedicine(val medicine: Medicine): MyMedicinesUIEvent()
    data class ToggleMedicineInfoDialog(val isVisible: Boolean): MyMedicinesUIEvent()

    object Retry: MyMedicinesUIEvent()
}
