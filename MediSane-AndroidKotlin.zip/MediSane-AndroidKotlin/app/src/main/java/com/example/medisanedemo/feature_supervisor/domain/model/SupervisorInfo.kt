package com.example.medisanedemo.feature_supervisor.domain.model

import com.google.gson.annotations.SerializedName

data class SupervisorInfo(
    @SerializedName("supervisor_id")
    val profileId: Int,
    val token: String
)
