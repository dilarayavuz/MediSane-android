package com.example.medisanedemo.feature_patient.data.data_source

import com.example.medisanedemo.feature_patient.domain.model.AllMedicinesPayload
import com.example.medisanedemo.feature_patient.domain.model.MedicineInfo
import com.example.medisanedemo.feature_patient.domain.model.AllMedicineReportPayload
import com.example.medisanedemo.feature_patient.domain.model.AwaitingRequestsDto
import com.example.medisanedemo.feature_patient.domain.model.MatchingQueryMedicinesDto
import com.example.medisanedemo.feature_patient.domain.model.MedicineReportInfo
import com.example.medisanedemo.feature_patient.domain.model.NotificationInfo
import com.example.medisanedemo.feature_patient.domain.model.ProfileInfo
import com.example.medisanedemo.feature_patient.domain.model.ProfileRequestNotificationInfo
import com.example.medisanedemo.feature_patient.domain.model.QueryMedicineNameInfo
import com.example.medisanedemo.feature_patient.domain.model.SupervisePatientInfo
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableProfilesToAddDto
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableSupervisionInfo
import com.example.medisanedemo.feature_supervisor.domain.model.SuperviseRequestInfo
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.PUT

interface PatientApiService {

    @POST("/post/get-all-medicines")
    suspend fun getAllMedicines(@Body profileInfo: ProfileInfo): AllMedicinesPayload


    @PUT("/put/schedule-medicine")
    suspend fun addMedicine(@Body medicineInfo: MedicineInfo)

    @POST("/post/get-medicine-report")
    suspend fun getMedicineReport(@Body profileInfo: ProfileInfo): AllMedicineReportPayload

    @PUT("/put/add-medicine-report")
    suspend fun addMedicineReport(@Body medicineReportInfo: MedicineReportInfo): Int

    @POST("/post/send-push-notification")
    suspend fun sendPushNotification(@Body notificationInfo: NotificationInfo)

    @POST("/post/get-supervision-requests")
    suspend fun getSupervisionRequests(@Body profileRequestNotificationInfo: ProfileRequestNotificationInfo): AwaitingRequestsDto

    @PUT("/put/supervise-patient")
    suspend fun supervisePatient(@Body supervisePatientInfo: SupervisePatientInfo): Boolean

    @POST("/post/available-supervision-profiles")
    suspend fun getSupervisorProfilesToAdd(@Body availableSupervisionInfo: AvailableSupervisionInfo): AvailableProfilesToAddDto

    @PUT("/put/supervise-patient-request")
    suspend fun sendSuperviseRequest(@Body superviseRequestInfo: SuperviseRequestInfo): Int

    @POST("/post/search-medicine")
    suspend fun getQueryMedicineName(@Body queryMedicineNameInfo: QueryMedicineNameInfo): MatchingQueryMedicinesDto

}