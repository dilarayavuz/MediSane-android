package com.example.medisanedemo.feature_patient.domain.use_case

import com.example.medisanedemo.feature_patient.domain.model.QueryMedicineNameInfo
import com.example.medisanedemo.feature_patient.domain.repository_interface.IMedicineRepository
import javax.inject.Inject

class SendQueryMedicineNameUseCase @Inject constructor(
    private val repository: IMedicineRepository
) {
    /*
  * allows us to call this class as a function
  * */
    suspend operator fun invoke(
        token: String,
        searchString: String,
    ): List<String> {

        val response = repository.getQueryMedicineName(
            QueryMedicineNameInfo(
                token = token,
                searchString = searchString
            )
        )

        val medicineNameList: MutableList<String> = mutableListOf()

        response.medList.forEach {  queryMedicine: String ->
            medicineNameList.add(queryMedicine)
        }

        return medicineNameList.toList()

    }
}