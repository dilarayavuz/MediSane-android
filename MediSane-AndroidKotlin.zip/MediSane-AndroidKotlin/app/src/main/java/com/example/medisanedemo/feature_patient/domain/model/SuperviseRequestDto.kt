package com.example.medisanedemo.feature_patient.domain.model

import com.google.gson.annotations.SerializedName

data class SuperviseRequestDto(
    val username: String,
    @SerializedName("profile_name")
    val profileName: String,
    @SerializedName("profile_id")
    val profileId: Int,

)
