package com.example.medisanedemo.feature_patient.domain.use_case

import com.example.medisanedemo.feature_patient.domain.model.AllMedicinesPayload
import com.example.medisanedemo.feature_patient.domain.model.ProfileInfo
import com.example.medisanedemo.feature_patient.domain.repository_interface.IMedicineRepository
import javax.inject.Inject

class GetAllMedicinesUseCase @Inject constructor(
    private val repository: IMedicineRepository
){

    /*
    * allows us to call this class as a function
    * */
    suspend operator fun invoke(
        token: String,
        profileId: Int
    ): AllMedicinesPayload {
        return repository.getAllMedicines(
            ProfileInfo(
                profileId = profileId,
                token = token
            )
        )
    }


}