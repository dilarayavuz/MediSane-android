package com.example.medisanedemo.feature_patient.data.repository_implementation

import com.example.medisanedemo.feature_patient.data.data_source.PatientApiService
import com.example.medisanedemo.feature_patient.domain.model.AwaitingRequestsDto
import com.example.medisanedemo.feature_patient.domain.model.ProfileRequestNotificationInfo
import com.example.medisanedemo.feature_patient.domain.model.SupervisePatientInfo
import com.example.medisanedemo.feature_patient.domain.repository_interface.IPatientRepository
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableProfilesToAddDto
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableSupervisionInfo
import com.example.medisanedemo.feature_supervisor.domain.model.SuperviseRequestInfo

class PatientRepositoryImpl (
    private val api: PatientApiService
): IPatientRepository {
    override suspend fun getSupervisionRequests(profileRequestNotificationInfo: ProfileRequestNotificationInfo): AwaitingRequestsDto {

        val payload = api.getSupervisionRequests(profileRequestNotificationInfo)
        return payload
    }

    override suspend fun supervisePatient(supervisePatientInfo: SupervisePatientInfo): Boolean {
        val payload = api.supervisePatient(supervisePatientInfo)

        return payload
    }

    override suspend fun getSupervisorProfilesToAdd(availableSupervisionInfo: AvailableSupervisionInfo): AvailableProfilesToAddDto {
        val payload = api.getSupervisorProfilesToAdd(availableSupervisionInfo)

        return payload
    }

    override suspend fun sendSuperviseRequest(superviseRequestInfo: SuperviseRequestInfo): Int {
        val payload = api.sendSuperviseRequest(superviseRequestInfo)

        return payload
    }
}