package com.example.medisanedemo.feature_patient.domain.use_case

import com.example.medisanedemo.feature_patient.domain.repository_interface.IPatientRepository
import com.example.medisanedemo.feature_supervisor.domain.model.AvailableSupervisionInfo
import com.example.medisanedemo.feature_supervisor.domain.model.ProfileToAddDto
import javax.inject.Inject

class GetAvailableSupervisorsToAddUseCase @Inject constructor(
    private val repository: IPatientRepository
) {

    /*
   * allows us to call this class as a function
   * */
    suspend operator fun invoke(
        ownProfileId: Int,
        wantedUsername: String,
        ownProfileType: Boolean,

        token: String
    ): List<ProfileToAddDto> {

        val availableProfilesToAddDto = repository.getSupervisorProfilesToAdd(
            AvailableSupervisionInfo(
                token = token,
                wantedUsername = wantedUsername,
                ownProfileId = ownProfileId,
                ownProfileType = ownProfileType,
            )
        )

        return availableProfilesToAddDto.availableProfiles
    }
}