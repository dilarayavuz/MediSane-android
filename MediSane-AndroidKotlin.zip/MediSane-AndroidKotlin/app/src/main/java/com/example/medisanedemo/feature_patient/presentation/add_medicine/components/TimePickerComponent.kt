package com.example.medisanedemo.feature_patient.presentation.add_medicine.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimeInput
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.medisanedemo.R
import com.example.medisanedemo.feature_patient.presentation.add_medicine.AddMedicineState
import com.example.medisanedemo.ui.theme.MyTheme
import java.time.LocalTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimePickerComponent(
    state: AddMedicineState,
    onDismiss: () -> Unit,
    onConfirm: (LocalTime) -> Unit
) {
    val currentSelectedTime = state.hourOfDoseList[state.selectedTimeIndex]

    val timePickerState = rememberTimePickerState(
        initialHour = currentSelectedTime.hour,
        initialMinute = currentSelectedTime.minute,
        is24Hour = true
    )

    BasicAlertDialog(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(size = 12.dp)
            ),
        onDismissRequest = onDismiss
    ) {
        
        Column (
            modifier = Modifier
                .padding(20.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ){
            TimeInput(state = timePickerState)
            
            Row(
                modifier = Modifier
                    .padding(12.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = onDismiss
                ) {
                    Text(
                        text = stringResource(id = R.string.dismiss)
                    )
                }
                TextButton(
                    onClick = {
                        onConfirm(
                            LocalTime.of(timePickerState.hour, timePickerState.minute)
                        )
                    }
                ) {
                    Text(
                        text = stringResource(id = R.string.confirm)
                    )
                }
                
            }
            
        }

    }
}


/*
@Preview(showBackground = true)
@Composable
fun TimePickerComponentPreview() {
    MyTheme (dynamicColor = false) {

        Surface (
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 48.dp, end = 28.dp, start = 28.dp, bottom = 48.dp)
        ){
            TimePickerComponent(
                state = AddMedicineState()
            )
        }

    }
}

 */
