package com.example.medisanedemo.feature_supervisor.presentation.util

import com.example.medisanedemo.feature_login.domain.model.Profile
import com.example.medisanedemo.feature_supervisor.domain.model.PatientDto
import com.example.medisanedemo.feature_supervisor.domain.model.toProfile

object SupervisorUiUtils {

    fun convertPatientDtoList(dtoList: List<PatientDto>?): List<Profile> {

        return if (dtoList == null) {
            listOf()
        } else {
            val patientProfileList = mutableListOf<Profile>()
            dtoList.forEach { patientDto ->
                patientProfileList.add(patientDto.toProfile())
            }
            patientProfileList.toList()
        }
    }
}